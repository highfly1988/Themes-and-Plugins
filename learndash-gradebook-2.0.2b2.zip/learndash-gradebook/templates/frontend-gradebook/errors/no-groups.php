<?php
/**
 * Template when no Groups are shown
 *
 * @since 2.0.0
 *
 * @var integer         $user_id
 */

defined( 'ABSPATH' ) || die();
?>

<div class="ld-gb-frontend-gradebook-group-dropdown-container" style="display: none;">

    <select id="ld-gb-frontend-gradebook-group-dropdown">
        <option value="0" selected></option>
    </select>

</div>