<?php
/**
 * Dashboard widget HTML for no Gradebooks.
 *
 * @since 1.2.0
 */

defined( 'ABSPATH' ) || die();
?>

<?php _e( 'There are no Gradebooks to view yet.', 'learndash-gradebook' ); ?>