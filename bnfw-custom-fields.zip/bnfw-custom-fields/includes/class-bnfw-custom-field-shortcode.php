<?php
/**
 * BNFW Custom Field Shortcode handler.
 */
class BNFW_Custom_Field_Shortcode {
	/**
	 * Constructor.
	 *
	 * @since 1.0
	 */
	function __construct() {
		$this->hooks();
	}

	/**
	 * Factory method to return the instance of the class.
	 *
	 * Makes sure that only one instance is created.
	 *
	 * @return object Instance of the class
	 */
	public static function factory() {
		static $instance = false;
		if ( ! $instance  ) {
			$instance = new self();
		}
		return $instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @since 1.0
	 */
	public function hooks() {
		add_filter( 'bnfw_shortcodes_post', array( $this, 'post_custom_fields_shortcode' ), 10, 2 );
		add_filter( 'bnfw_shortcodes_post_meta', array( $this, 'post_custom_fields_shortcode' ), 10, 2 );

		add_filter( 'bnfw_shortcodes_user', array( $this, 'user_custom_fields_shortcode' ), 10, 3 );
	}

	/**
	 * Handle post custom fields shortcode.
	 *
	 * @since 1.0
	 */
	public function post_custom_fields_shortcode( $message, $id ) {
		add_shortcode( 'custom_field', array( $this, 'custom_field_shortcode_handler' ) );
		$message = str_replace( '[custom_field', '[custom_field id="' . $id . '"', $message );
		$message = do_shortcode( $message );
		remove_shortcode( 'custom_field', array( $this, 'custom_field_shortcode_handler' ) );

		$message = strip_shortcodes( $message );

		return $message;
	}

	/**
	 * Custom fields shortcode handler.
	 *
	 * @since 1.0
	 */
	public function custom_field_shortcode_handler( $atts ) {
		$atts = shortcode_atts( array(
			'field' => '',
			'id'    => 0,
		), $atts );

		$post_id = absint( $atts['id'] );
		$value   = '';

		if ( $post_id > 0 ) {
			$value = get_post_meta( $post_id, $atts['field'], true );
		}

		if ( is_array( $value ) ) {
			return implode( ', ', $value );
		}

		return $value;
	}

	/**
	 * Handle user custom fields shortcode.
	 *
	 * @since 1.1
	 */
	public function user_custom_fields_shortcode( $message, $id, $prefix ) {
		add_shortcode( $prefix . 'user_custom_field', array( $this, 'user_custom_field_shortcode_handler' ) );
		$message = str_replace( '[' . $prefix . 'user_custom_field', '[' . $prefix . 'user_custom_field id="' . $id . '"', $message );
		$message = do_shortcode( $message );
		remove_shortcode( $prefix . 'user_custom_field', array( $this, 'user_custom_field_shortcode_handler' ) );

		$message = strip_shortcodes( $message );

		return $message;
	}

	/**
	 * User custom fields shortcode handler.
	 *
	 * @since 1.1
	 */
	public function user_custom_field_shortcode_handler( $atts ) {
		$atts = shortcode_atts( array(
			'field' => '',
			'id'    => 0,
		), $atts );

		$user_id = absint( $atts['id'] );
		$value   = '';

		if ( $user_id > 0 ) {
			$value = get_user_meta( $user_id, $atts['field'], true );
		}

		if ( is_array( $value ) ) {
			return implode( ', ', $value );
		}

		return $value;
	}
}
