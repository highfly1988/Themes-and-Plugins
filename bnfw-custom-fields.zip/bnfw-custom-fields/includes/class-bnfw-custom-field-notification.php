<?php

/**
 * BNFW Custom Field Notification
 */
class BNFW_Custom_Field_Notification {
	/**
	 * Constructor.
	 *
	 * @since 1.0
	 */
	function __construct() {
		$this->hooks();
	}

	/**
	 * Factory method to return the instance of the class.
	 *
	 * Makes sure that only one instance is created.
	 *
	 * @return object Instance of the class
	 */
	public static function factory() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @since 1.0
	 */
	public function hooks() {
		add_action( 'bnfw_after_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'bnfw_after_notification_options', array( $this, 'add_notification_option' ), 10, 3 );
		add_action( 'bnfw_after_notification_dropdown', array( $this, 'add_custom_field_select' ) );

		add_filter( 'bnfw_notification_setting_fields', array( $this, 'add_notification_setting_field' ) );
		add_filter( 'bnfw_notification_setting', array( $this, 'save_notification_setting' ) );
		add_filter( 'bnfw_notification_name', array( $this, 'set_notification_name' ), 10, 2 );
		add_filter( 'bnfw_post_notifications', array( $this, 'add_to_post_notification' ), 10, 2 );
		add_filter( 'bnfw_notification_post_type', array( $this, 'get_notification_post_type' ), 10, 2 );

		add_filter( 'bnfw_non_wp_emails', array( $this, 'append_non_wp_emails' ), 10, 3 );

		add_action( 'updated_post_meta', array( $this, 'after_post_meta_update' ), 10, 4 );
		add_action( 'shutdown', array( $this, 'on_shutdown' ) );

		add_filter( 'bnfw_shortcodes', array( $this, 'handle_shortcodes' ), 10, 4 );
	}

	/**
	 * Enqueue additional scripts.
	 *
	 * @since 1.0
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'bnfw-custom-field-notification', plugins_url( 'assets/js/bnfw-custom-field-notification.js', dirname( __FILE__ ) ), array( 'jquery' ), '1.0', true );
	}

	/**
	 * Add Notification to the list.
	 *
	 * @since 1.0
	 *
	 * @param string $post_type Post type for which notification should be added.
	 * @param string $label     CPT Label.
	 * @param string $setting   Notification Settings.
	 */
	public function add_notification_option( $post_type, $label, $setting ) {
		switch ( $post_type ) {
			case 'post':
				?>
                <option
                        value="customfield-<?php echo $post_type; ?>" <?php selected( 'customfield-' . $post_type, $setting['notification'] ); ?>><?php _e( 'Post - Custom Field Updated', 'bnfw' ); ?></option>
				<?php
				break;
			case 'page':
				?>
                <option
                        value="customfield-<?php echo $post_type; ?>" <?php selected( 'customfield-' . $post_type, $setting['notification'] ); ?>><?php _e( 'Page - Custom Field Updated', 'bnfw' ); ?></option>
				<?php
				break;
			default:
				?>
                <option
                        value="customfield-<?php echo $post_type; ?>" <?php selected( 'customfield-' . $post_type, $setting['notification'] ); ?>><?php echo "'$label' ", __( 'Custom Field Updated', 'bnfw' ); ?></option>
				<?php
				break;
		}
	}

	/**
	 * Add custom field select dropdown.
	 *
	 * @since 1.0
	 *
	 * @param array $setting Settings array.
	 */
	public function add_custom_field_select( $setting ) {
		$meta_keys = $this->get_unique_post_meta_keys();
		?>
		<tr valign="top" id="bnfw-custom-field">
			<th scope="row">
				<label><?php _e( 'Send when these Custom Fields are Updated', 'bnfw' ); ?></label>
				<div class="bnfw-help-tip"><p><?php esc_html_e( 'Only send this notification if any of these custom fields are updated. Usable custom fields are those that don\'t start with an underscore.', 'bnfw' ); ?></p></div>
			</th>
			<td>
				<select class="bnfw-select2" name="custom-field[]" data-placeholder="Select Custom Field(s)"
				        style="width:75%" multiple>
					<?php foreach ( $meta_keys as $meta_key ) { ?>
						<option
							value="<?php echo $meta_key; ?>" <?php selected( true, in_array( $meta_key, $setting['custom-field'] ) ); ?>><?php echo $meta_key; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
		<?php
	}

	/**
	 * Add new fields to notification settings.
	 *
	 * @since 1.0
	 *
	 * @param array $fields List of existing fields.
	 *
	 * @return array New list of fields.
	 */
	public function add_notification_setting_field( $fields ) {
		$fields['custom-field'] = array();

		return $fields;
	}

	/**
	 * Save Notification setting.
	 *
	 * @since 1.0
	 *
	 * @param array $setting Notification setting
	 *
	 * @return array Modified Notification setting
	 */
	public function save_notification_setting( $setting ) {
		if ( isset( $_POST['custom-field'] ) ) {
			$tmp                     = $_POST['custom-field'];
			$setting['custom-field'] = $_POST['custom-field'];
		}

		return $setting;
	}

	/**
	 * Set the name of the notification.
	 *
	 * @since 1.0
	 */
	public function set_notification_name( $name, $slug ) {
		$bnfw = BNFW::Factory();
		if ( $bnfw->notifier->starts_with( $slug, 'customfield-' ) ) {
			$splited  = explode( '-', $slug, 2 );
			$label    = $splited[1];
			$post_obj = get_post_type_object( $splited[1] );

			if ( null != $post_obj ) {
				$label = $post_obj->labels->singular_name;
			}

			$name = $label . ' - ' . __( 'Custom Field Updated', 'bnfw' );
		}

		return $name;
	}

	/**
	 * Add this notification to the list of post notifications.
	 *
	 * @since 1.0
	 */
	public function add_to_post_notification( $notifications, $post_type ) {
		$notifications[] = $this->get_notification_details( $post_type );

		return $notifications;
	}

	/**
	 * Filter notification post type.
	 *
	 * @param string $post_type    Post type.
	 * @param string $notification Notification name.
	 *
	 * @return string Notification post type.
	 */
	public function get_notification_post_type( $post_type, $notification ) {
		$splits = explode( '-', $notification );

		if ( count( $splits ) == 2 ) {
			if ( 'customfield' == $splits[0] ) {
				return $splits[1];
			}
		}

		return $post_type;
	}

	/**
	 * When the metadata is updated.
	 *
	 * @since 1.0
	 *
	 * @param int    $meta_id    ID of updated metadata entry.
	 * @param int    $object_id  Object ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 */
	public function after_post_meta_update( $meta_id, $post_id, $meta_key, $meta_value ) {
		if ( '_edit_lock' != $meta_key ) {
			$this->send_notification( $post_id, $meta_key );
		}
	}

	/**
	 * Send notification for custom field.
	 *
	 * @since 1.0
	 *
	 * @param int    $post_id  Post Id
	 * @param string $meta_key Meta key that got changed
	 */
	public function send_notification( $post_id, $meta_key ) {
		$bnfw          = BNFW::factory();
		$notifications = $bnfw->notifier->get_notifications( $this->get_notification_details( get_post_type( $post_id ) ) );

		foreach ( $notifications as $notification ) {
			/**
			 * BNFW - Whether notification is disabled?
			 *
			 * @since 1.3.6
			 */
			$setting = $bnfw->notifier->read_settings( $notification->ID );
			$notification_disabled = apply_filters( 'bnfw_notification_disabled', false, $post_id, $setting );

			if ( ! $notification_disabled ) {
				if ( ! empty( $setting['custom-field'] ) && in_array( $meta_key, $setting['custom-field'] ) ) {
					$transient = get_transient( 'bnfw-cf-notifications' );
					if ( ! is_array( $transient ) ) {
						$transient = array();
					}

					$transient[] = array( 'post_id' => $post_id, 'notification_id' => $notification->ID );
					set_transient( 'bnfw-cf-notifications', $transient, 600 );
				}
			}
		}
	}

	/**
	 * Send notification emails on shutdown.
	 */
	public function on_shutdown() {
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return;
		}

		$transient = get_transient( 'bnfw-cf-notifications' );
		if ( is_array( $transient ) ) {
			foreach ( $transient as $id_pairs ) {
				$bnfw    = BNFW::Factory();
				$setting = $bnfw->notifier->read_settings( $id_pairs['notification_id'] );
				$bnfw->engine->send_notification( $setting, $id_pairs['post_id'] );
			}
			delete_transient( 'bnfw-cf-notifications' );
		}
	}

	/**
	 * Handle shortcodes.
	 *
	 * @since 1.0
	 *
	 * @param string $message      Message
	 * @param string $notification Notification name
	 * @param int    $post_id      Post id
	 * @param object $engine       BNFW Engine
	 *
	 * @return string
	 */
	public function handle_shortcodes( $message, $notification, $post_id, $engine ) {
		$bnfw = BNFW::Factory();
		if ( $bnfw->notifier->starts_with( $notification, 'customfield-' ) ) {
			$message = $engine->post_shortcodes( $message, $post_id );

			$post = get_post( $post_id );
			$message = $engine->user_shortcodes( $message, $post->post_author );
		}

		return $message;
	}

	/**
	 * Append Non WordPress emails that are specified in post meta.
	 *
	 * @param array $emails  List of emails.
	 * @param array $users   List of users.
	 * @param int   $post_id Post Id.
	 *
	 * @return array Appended list of emails.
	 */
	public function append_non_wp_emails( $emails, $users, $post_id ) {
		if ( $post_id > 0 ) {
			foreach ( $users as $user ) {
				if ( ! is_email( $user ) ) {
					$shortcode_emails = apply_filters( 'bnfw_shortcodes_post_meta', $user, $post_id );

					$shortcode_emails = explode( ',', $shortcode_emails );
					$shortcode_emails = array_map( 'trim', $shortcode_emails );

					foreach ( $shortcode_emails as $shortcode_email ) {
						if ( ! empty( $shortcode_email ) && is_email( $shortcode_email ) ) {
							$emails[] = $shortcode_email;
						}
					}
				}
			}
		}

		return $emails;
	}

	/**
	 * Get the list of unique post meta keys.
	 *
	 * @since 1.0
	 * @return array Array of meta keys.
	 */
	private function get_unique_post_meta_keys() {
		global $wpdb;

		$query     = "SELECT DISTINCT({$wpdb->postmeta}.meta_key) FROM {$wpdb->postmeta} WHERE {$wpdb->postmeta}.meta_key != ''";
		$meta_keys = $wpdb->get_col( $query );

		return $meta_keys;
	}

	/**
	 * Build notification name based on post type.
	 *
	 * @param string $post_type Post type
	 *
	 * @return string Notification Type
	 */
	protected function get_notification_details( $post_type ) {
		return 'customfield-' . $post_type;
	}
}
