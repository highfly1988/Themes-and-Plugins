<?php
/**
 * BNFW Addon Base class.
 */

// TODO: Move textodmain handling to base class
class BNFW_Addon {

	protected $addon_details = array();

	public function __construct( $args ) {

	}

}
