jQuery( document ).ready( function( $ ) {
	function bnfw_custom_field_init() {
		var value = $( '#notification' ).val();

		if ( value.lastIndexOf( 'customfield', 0 ) === 0 ) {
			$( '#bnfw-custom-field' ).show();
		} else {
			$( '#bnfw-custom-field' ).hide();
		}
	}

	bnfw_custom_field_init();

    $('#notification').on('change', function() {
    	bnfw_custom_field_init();
	} );
} );
