=== BNFW - Custom Fields Add-on ===
Contributors: voltronik
Donate link: https://betternotificationsforwp.com/donate/
Requires at least: 4.3
Tested up to: 4.9.6
Stable tag: 1.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This add-on provides a number of new shortcodes allowing you to include data from custom fields, created using Advanced Custom Fields (ACF), in both the subject and message body of your notifications. It also allows you to set one or multiple custom fields that will ‘trigger’ the notification. Both the latest versions of the Free and Pro ACF plugin are supported.

== Changelog ==

= 1.1.7 =
* Added: Support for comma-separated lists of email addresses when used in conjunction with the [Send to Any Email add-on](https://betternotificationsforwp.com/downloads/send-to-any-email/).

= 1.1.6 =
* Added: Support for the new global shortcodes.

= 1.1.5 =
* New: Shortcodes are now stripped from custom fields so as to not cause rendering issues within notifications.
* Added: Inline help tips are now available for this add-ons notification fields.

= 1.1.4 =
* Fixed: An issue where Custom Field Updated notifications weren't sending out when used in conjunction with BNFW v1.6.3.

= 1.1.3 =
* Added: Support for [Send to Any Email add-on](https://betternotificationsforwp.com/downloads/send-to-any-email/).
* Fixed: Author shortcodes weren't outputting in custom field update notifications.
* Fixed: An issue with the custom field select2 field.

= 1.1.2 =
* New: Translation file now provided.
* Fixed: A fatal error when used in conjunction with 1.6 of BNFW.

= 1.1.1 =
* Compatibility with BNFW Conditional Notifications add-on.

= 1.1 =
* Added: You can now include custom fields for user profiles created using ACF in any notification that can supports user shortcodes by using the new shortcode `[user_custom_field field="X"]`.

= 1.0 =
* Initial release.
