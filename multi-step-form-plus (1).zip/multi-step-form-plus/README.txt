=== Multi Step Form Plus ===
Contributors: mondula2016
Tags: multi, step, plus, forms, multi-step, steps, feedback, email, contact form, progress bar, form builder, dynamic, ajax, formular
Requires at least: 3.9
Tested up to: 4.9
Stable tag: 1.0.5

Plus-Extension for the free "Multi Step Form" Plugin.

== Description ==

Multi Step Form has a drag & drop enabled form builder for quick and intuitive creation of nice-looking multi step forms. Forms can be embedded on any page or post with shortcodes.

=== MULTI STEP FORM PLUS ===

**Plus features:**

*   **Up to 10 steps**- You can now divide your formular in up to 10 Steps
*   **Save form data**- The Forms will now be saved in the backend. Easily make some evaluations
*   **Conditional fields**- You want to bring more flexibility to your forms? Check out conditional fields.
*   **Export as CSV-List**- You want to use ther form data in e.g. Excel? Export your forms as CSV.


### Watch the video
[youtube http://www.youtube.com/watch?v=2hyF1SDewok]


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin zip-File 
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= I have a question. What should I do? =

Please contact us at info@mondula.com

== Screenshots ==

1. The backend's structure is simple. Even less technical users can quickly understand the plugin and start creating forms.
2. Use our customizable and animated progress bar to guide your users through your forms. Change the colors to match your CI.

== Changelog ==

= 1.0.5 =
* make Paragraphs conditional
* choose your own CSV delimiter
* make conditional logic more robust to form changes

= 1.0.4 =
* utf8 encoding for CSV export
* wrap values with commas in quotes in CSV export

= 1.0.3 =
* fix conditional fields disappearing in CSV export

= 1.0.2 =
* CSV single entry export fixed

= 1.0.0 =
* Initial release