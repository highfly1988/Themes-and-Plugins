<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @link http://mondula.com
 * @package Multi_Step_Form_Plus
 * @subpackage Multi_Step_Form_Plus/admin
 * @author Mondula GmbH <lewe.ohlsen@mondula.com>
 */
class Multi_Step_Form_Plus_Admin {

	private $plugin_name;
	private $version;
	private $service;


	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 1.0.0
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version The version of this plugin.
	 */
	public function __construct( $plugin_name, $version, $service ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->service = $service;

		add_action( 'admin_init', array( $this, 'download_entries_csv' ) );
		add_action( 'msf_submenus', array( $this, 'setup_menu' ) );
		add_action( 'msf_echopro', array( $this, 'echo_plus' ) );
		add_action( 'msfp_save', array( $this, 'save_entry' ), 10, 2 );
		add_action( 'msfp_register', array( $this, 'register_user' ), 10, 3 );
		add_action( 'wp_ajax_msfp_license_validate', array( $this, 'ajax_license_validate' ) );
		add_action( 'wp_ajax_msfp_license_deregister', array( $this, 'ajax_license_deregister' ) );
	}

	/**
	 * Hook testing.
	 */
	public function echo_plus() {
		echo 'PLUS';
	}

	/**
	 * Adds PLUS-specific submenus to the MSF-menu.
	 */
	public function setup_menu() {
		add_submenu_page( 'mondula-multistep-forms', 'Entries', 'Entries',
		'manage_options', 'multi-step-form-plus-entries', array( $this, 'entries' ));
	}

	/**
	 * AJAX - Checks if a license key is valid. The download_url is not provided for invalid licenses.
	 */
	public function ajax_license_validate() {
		global $my_update_checker;
		$_POST = stripslashes_deep( $_POST );

		$settings_plus = get_option( 'fw_settings_plus' );
		$oldkey = $settings_plus['license_key'];
		$settings_plus['license_key'] = isset( $_POST['license_key'] ) ? $_POST['license_key'] : '';

		update_option( 'fw_settings_plus', $settings_plus );
		$update = $my_update_checker->requestInfo();
		echo $update->license_error;
		/* set old key because user did not save yet */
		$settings_plus['license_key'] = $oldkey;
		update_option( 'fw_settings_plus', $settings_plus );
		wp_die();
	}

	public function ajax_license_deregister() {
		global $my_update_checker;
		$m = parse_url( $my_update_checker->metadataUrl );
		$wp = parse_url( get_site_url() );
		$settings_plus = get_option( 'fw_settings_plus' );
		$license_key = $settings_plus['license_key'];
		$q = http_build_query ( array(
			'action' => 'deregister',
			'slug' => 'multi-step-form-plus',
			'license_key' => $license_key,
			'site_url' => $wp['host'] . $wp['path'],
		));
		$curl = curl_init();
		// Set some options - we are passing in a useragent too here
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $m['scheme'] . '://' . $m['host'] . $m['path'] . '?' . $q,
		));
		// Send the request & save response to $resp
		$resp = curl_exec( $curl );
		// Close request to clear up some resources
		curl_close( $curl );
		if ( ! $resp ) {
			$settings_plus['license_key'] = '';
			update_option( 'fw_settings_plus', $settings_plus );
		}
		wp_send_json( $resp );
	}

	function msfp_filter_replace_deregister( $query_args ) {
		$query_args['action'] = 'deregister';
		return $query_args;
	}

	/**
	 * Saves a form entry to the database.
	 * @param data the form data object
	 */
	public function save_entry( $id, $data ) {
		/* If user is logged in, save form to user_meta */
		if ( get_current_user_id() > 0 && Mondula_Form_Wizard_Wizard::fw_get_option( 'registration_meta' ,'fw_settings_registration' ) === 'on' ) {
			$this->save_user_meta( $id, get_current_user_id(), $data );
		}
		/* Save the data to Entries-Table */
		if ( Mondula_Form_Wizard_Wizard::fw_get_option( 'entries_enable' ,'fw_settings_entries' ) === 'on' ) {
			$this->service->save_entry( $id, $data );
		}
	}

	/**
	 * Checks if the registration is valid before submitting.
	 */
	private function validate_registration( $reg_data ) {
		$reg_errors = new WP_Error;
		if ( empty( $reg_data['username'] ) || empty( $reg_data['email'] ) ) {
			$reg_errors->add( 'field', 'Required form field is missing' );
		}
		if ( username_exists( $reg_data['username'] ) ) {
			$reg_errors->add( 'user_name', 'Sorry, that username already exists!' );
		}
		if ( ! validate_username( $reg_data['username'] ) ) {
			$reg_errors->add( 'username_invalid', 'Sorry, the username you entered is not valid' );
		}
		if ( ! is_email( $reg_data['email'] ) ) {
			$reg_errors->add( 'email_invalid', 'Email is not valid' );
		}
		if ( email_exists( $reg_data['email'] ) ) {
			$reg_errors->add( 'email', 'Email Already in use' );
		}
		return $reg_errors;
	}

	private function save_user_meta( $form_id, $user_id, $meta_data ) {
		$meta_key = sanitize_key( 'msf' . '-' . $form_id . '_' . date( 'Ymd-His' ) );
		//$meta_value = $this->prepare_user_meta( $meta_data );
		add_user_meta( $user_id, $meta_key, $meta_data );
	}

	/**
	 * Registers a new user to this WordPress-Blog.
	 *
	 * @param reg_data the users email, username, password and stuff
	 * @param meta_data the metadata = form data
	 */
	public function register_user( $reg_data, $meta_data, $form_id ) {
		if ( Mondula_Form_Wizard_Wizard::fw_get_option( 'registration_enable' ,'fw_settings_registration' ) === 'on' ) {
			$validation = $this->validate_registration( $reg_data );
			if ( 1 > count( $validation->get_error_messages() ) ) {
				$password_generated = false;
				if ( ! isset( $reg_data['password'] ) || $reg_data['password'] === '') {
					$reg_data['password'] = wp_generate_password();
					$password_generated = true;
				}
				$userdata = array(
					'user_login'    => sanitize_user( $reg_data['username'] ),
					'user_email'    => sanitize_email( $reg_data['email'] ),
					'user_pass'     => esc_attr( $reg_data['password'] ),
					'user_url'      => isset( $reg_data['website'] ) ? esc_url( $reg_data['website'] ) : '',
					'first_name'    => isset( $reg_data['firstname'] ) ? sanitize_text_field( $reg_data['firstname'] ) : '',
					'last_name'     => isset( $reg_data['lastname'] ) ? sanitize_text_field( $reg_data['lastname'] ) : '',
					'nickname'      => sanitize_text_field( $reg_data['username'] ),
					'description'   => isset( $reg_data['bio'] ) ? esc_textarea( $reg_data['bio'] ) : '',
				);

				$user_id = wp_insert_user( $userdata );

				/* Save Form Data as user_meta */
				if ( $user_id && Mondula_Form_Wizard_Wizard::fw_get_option( 'registration_meta' ,'fw_settings_registration' ) === 'on' ) {
					$this->save_user_meta( $form_id, $user_id, $meta_data );
				}

				if ( Mondula_Form_Wizard_Wizard::fw_get_option( 'registration_notification' ,'fw_settings_registration' ) === 'on' || $password_generated ) {
					wp_new_user_notification( $user_id, null, 'user' );
				}
			}
		}
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Multi_Step_Form_Plus_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Multi_Step_Form_Plus_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/multi-step-form-plus-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Multi_Step_Form_Plus_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Multi_Step_Form_Plus_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/multi-step-form-plus-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function download_entries_csv() {
		if ( current_user_can( 'editor' ) || current_user_can( 'administrator' ) ) {
			if ( isset( $_GET['page'] ) && $_GET['page'] === 'multi-step-form-plus-entries'
			&& isset( $_GET['action'] ) && $_GET['action'] === 'export' ) {
				/* Get the separator or fall back to default */
				$separator = Mondula_Form_Wizard_Wizard::fw_get_option( 'entries_csvseparator' ,'fw_settings_entries' );
				if ( !$separator || $separator === '' ) {
					$separator = ',';
				}
				/* Generate CSV for all entries */
				$entries = $this->service->get_entries( $_GET['entry'] );
				$filename = 'entry_form-';
				if ( is_array( $entries ) ) {
					$form = $this->service->get_form( $entries[0]->get_form_id() );
					$filename = sanitize_file_name( $filename . $entries[0]->get_form_id() . '_' . date( 'Y-m-d H:i:s' ) );
					$csv = $entries[0]->csv_header( $form, $separator ) . "\n";
					foreach ( $entries as $entry ) {
						$csv .= $entry->to_csv( $form, $separator ) . "\n";
					}
				} else {
					$form = $this->service->get_form( $entries->get_form_id() );
					$csv = $entries->csv_header( $form, $separator ) . "\n";
					$csv .= $entries->to_csv( $form, $separator );
					$filename = sanitize_file_name( $filename . $entries->get_form_id() . '_' . $entries->get_date() );
				}
				// Just setting some headers for our download
				header( 'Pragma: public' );
				header( 'Expires: 0' );
				header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
				header( 'Cache-Control: private', false );
				header( 'Content-Encoding: UTF-8' );
				header( 'Content-Type: text/csv; charset=UTF-8' );
				header( 'Content-Disposition: attachment; filename=' . $filename . '.csv;' );
				header( 'Content-Transfer-Encoding: binary' );
				echo $csv;
				exit;
			}
		}
	}

	public function entries() {
		//$form_url = esc_url( add_query_arg( array('form' => '')) );
		if ( isset( $_GET['action'] ) ) {
			switch ( $_GET['action'] ) {
				case 'delete':
					$this->service->delete_entry( $_GET['entry'] );
					break;
				default:
					# code...
					break;
			}
		}
		$this->entries_table();
	}

	public function entries_table() {
		$table = new Multi_Step_Form_Plus_Entries_Table( $this->service );
		$table->prepare_items();
		//$form_url = esc_url( add_query_arg( array( 'form' => '1' )));
		?>
		<div class="wrap">
			<h1>
				Form Entries
				<span class="title-count msfp-entries-count"><?php echo $table->_pagination_args['total_items']; ?></span>
			</h1>
			<form id="msfp-entries-table" method="get">
				<input type="hidden" name="page" value="<?php echo $_REQUEST['page']; ?>" />
				<?php $table->search_box( 'Search Entries', 'your-element-id' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}
}
