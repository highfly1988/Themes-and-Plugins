<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://mondula.com
 * @since      1.0.0
 *
 * @package    Multi_Step_Form_Plus
 * @subpackage Multi_Step_Form_Plus/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
