<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// WP_List_Table is not loaded automatically so we need to load it in our application
if ( ! class_exists( 'WP_List_Table' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}


class Multi_Step_Form_Plus_Entries_Table extends WP_LIST_TABLE {

	private $service;

	/**
	 * Constructor. This sets default arguments and filters.
	 */
	public function __construct( $service ) {
		parent::__construct(
			array(
				'screen' => get_current_screen(),
			)
		);
		$this->service = $service;
	}

	/**
	 * Returns an associative array of the list tables columns.
	 */
	function get_columns() {
		return array(
			'cb' => '<input type="checkbox" />',
			'title' => 'Entry ID',
			'form_id' => 'Form ID',
			'pct_complete' => 'Completed',
			'json' => 'JSON',
			'fields' => 'Form Fields',
			'date' => 'Date',
		);
	}

	/**
	 * Calls render-specific methods for each column. Or defaults to printing the array of data.
	 * @param item the
	 */
	function column_default( $item, $column_name ) {
		$entry = new Multi_Step_Form_Plus_Entry( (Object) $item );
		$form = $this->service->get_form( $entry->get_form_id() );		
		switch ( $column_name ) {
			case 'form_id':
				return $entry->get_form_id();
			case 'date':
				return $entry->get_date();
			case 'fields':
				return $entry->to_html();
			case 'pct_complete':
				return strval( $entry->pct_complete( $form ) ) . '%';
			default:
				return print_r( $item, true ); //Show the whole array for troubleshooting purposes
		}
	}

	/**
	 * Renders the options (Export/Delete/…) for each entry and defines query links.
	 * Calls row_actions() to render the action links.
	 */
	function column_title( $item ) {
		$actions = array(
			'export'  => sprintf( '<a target="_blank" href="?page=%s&action=%s&entry=%s">CSV-Export</a>', $_REQUEST['page'], 'export', $item['id'] ),
			'delete'  => sprintf( '<a href="?page=%s&action=%s&entry=%s">Delete</a>', $_REQUEST['page'], 'delete', $item['id'] ),
		);
		return sprintf( '%1$s %2$s', $item['id'], $this->row_actions( $actions ) );
	}

	/**
	 * Filter list entrys by form ID.
	 */
	private function filter_entries_by_formid( $data, $filter ) {
		$filtered = [];
		foreach ( $data as $entry ) {
			if ( $entry['form_id'] == $filter ) {
				array_push( $filtered, $entry );
			}
		}
		return $filtered;
	}

	/**
	 * Query and filter data before rendering.
	 */
	function prepare_items() {
		$data = null;
		$columns = $this->get_columns();
		$hidden = $this->get_hidden_columns();
		$sortable = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );

		$this->process_bulk_action();

		/* Search entries */
		$search = isset( $_GET['s'] ) ? $_GET['s'] : null;
		if ( $search == null ) {
			$data = $this->service->get_all_entries();
		} else {
			$data = $this->service->get_by_keyword( $search );
		}

		/* Filter by form */
		$filter = isset( $_GET['forms-filter'] ) ? $_GET['forms-filter'] : null;
		if ( $filter ) {
			$data = $this->filter_entries_by_formid( $data, $filter );
		}

		/* Sort entries */
		if ( $data ) {
			usort( $data, array( &$this, 'usort_order' ) );
		}

		/* Pagination */
		$per_page = Mondula_Form_Wizard_Wizard::fw_get_option( 'entries_perpage' ,'fw_settings_entries' );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$total_pages = $per_page != 0 ? ceil( $total_items / $per_page ) : 1;
		/* Trim data to current page */
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );

		$this->items = $data;

		/* Register pagination options */
		$this->set_pagination_args( array(
			'total_items' => $total_items,
			'per_page'    => $per_page,
			'total_pages' => $total_pages,
		) );
	}

	/**
	 * Determines the sort order and returns it for usort().
	 * @param a, b two items
	 */
	private function usort_order( $a, $b ) {
		// If no sort, default to title
		$orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'id';
		// If no order, default to asc
		$order = ( ! empty( $_GET['order'] ) ) ? $_GET['order'] : 'asc';
		// Determine sort order
		$result = strtotime( $a[ $orderby ] ) < strtotime( $b[ $orderby ] ) ? -1 : 1;
		// Send final sort direction to usort
		return ( 'asc' === $order ) ? $result : -$result;
	}

	/**
	 * Checks if all the entries from $this->items are belonging to the same form.
	 * @param entries the array of entries
	 */
	private function entries_from_one_form( $entries ) {
		for ( $i = 0; $i < count( $entries ) - 1; $i++ ) {
			if ( $entries[ $i ]['form_id'] != $entries[ $i + 1 ]['form_id'] ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Defines all the bulk actions for the table.
	 */
	function get_bulk_actions() {
		$bulk_actions = array(
			'delete' => 'Delete',
		);
		/* check if all the items have the same form_id */
		if ( $this->entries_from_one_form( $this->items ) ) {
			/* allow bulk export */
			$bulk_actions['export'] = 'Export';
		}
		return $bulk_actions; 
	}

	/**
	 * Define the sortable columns
	 */
	function get_sortable_columns() {
		return array(
			'date' => array( 'date', false ),
		);
	}

	/**
	 * Define which columns are hidden
	 */
	function get_hidden_columns() {
		return array( 'json' );
	}

	/**
	 * Handles the checkbox column output.
	 */
	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="entry[]" value="%s" />', $item['id']
		);
	}

	/**
	 *
	 */
	public function process_bulk_action() {

		// security check!
		if ( isset( $_GET['_wpnonce'] ) && ! empty( $_GET['_wpnonce'] ) ) {

			$nonce = filter_input( INPUT_GET, '_wpnonce', FILTER_SANITIZE_STRING );
			$action = 'bulk-' . $this->_args['plural'];

			if ( ! wp_verify_nonce( $nonce, $action ) ) {
				wp_die( 'Nope! Security check failed!' );
			}
		}

		$action = $this->current_action();

		switch ( $action ) {
			case 'delete':
				$entry_ids = $_GET['entry'];
				if ( is_array( $entry_ids )) {
					foreach ( $entry_ids as $entry_id ) {
						$this->service->delete_entry( $entry_id );
					}
				} else {
					$this->service->delete_entry( $entry_ids );
				}
				break;
			case 'save':
				wp_die( 'Save something' );
				break;
			default:
				// do nothing or something else
				return;
				break;
		}
		return;
	}

	/**
	 * Extra menu for filtering entries by form.
	 */
	function extra_tablenav( $which ) {
		global $wpdb, $tablename, $tablet;		
		if ( $which == 'top' ) {
			$forms = [];
			/* Get IDs and names of forms with entries */
			foreach ( $this->service->get_all_entries() as $item ) {
				if ( ! in_array( $item['form_id'], $forms ) ) {
					/* Get form names for dropdown */
					$formname = $this->service->get_form( $item['form_id'] )['title'];
					$forms[ $item['form_id'] ] = $formname;
				}
			}
			?>
			<div class="alignleft actions bulkactions">
			<?php
			if ( $forms ) {
				?>
				<select name="forms-filter" class="msfp-filter-forms">
					<option value="">Filter by Form</option>
					<?php
					/* render option entry for each form */
					foreach ( $forms as $formid => $formname ) {
						$selected = '';
						if ( isset( $_GET['forms-filter'] ) && $_GET['forms-filter'] == $formid ) {
							$selected = ' selected = "selected"';
						}
						?>
						<option value="<?php echo $formid; ?>" <?php echo $selected; ?>><?php echo $formname; ?></option>
						<?php
					}
					?>
					</select>
					<input id="doaction" class="button action" value="Filter" type="submit">
			<?php
			}
		}
	}
}
