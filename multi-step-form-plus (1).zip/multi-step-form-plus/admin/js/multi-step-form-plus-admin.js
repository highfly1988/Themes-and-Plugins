(function( $ ) {
	'use strict';

	function setupDeregisterListener() {
		var $licenseInput = $('#fw_settings_plus .regular-text');
		var $desc = $('#fw_settings_plus p.description');
		var licenseKey = $licenseInput.val();
		// Deregister a valid license
		$('#msfp-license-deregister').click(function(event) {
			var data = {
				'action': 'msfp_license_deregister',
				'license_key': licenseKey
			};
			jQuery.post(ajaxurl, data, function(response) {
				switch (response) {
					case "0":
						$licenseInput.val('');
						$desc.html('Your license has been deregistered. You can use the license on another WordPress instance now.');
						break;
					case "1":
						$desc.html('Your license could not be updated. Please <a href="mailto:info@mondula.com">contact us</a>.');
						break;
					case "2":
						$desc.html('Your license is currently not registeted with this site. Thus it could not be deregistered. Having trouble? <a href="mailto:info@mondula.com">Contact us</a>');
						break;
					case "3":
						$desc.html('Your license is invalid. Having trouble? <a href="mailto:info@mondula.com">Contact us</a>!');
						break;
					default:
						break;
				}
			});
		});
	}

	function setupLicenseAction() {
		var $licenseInput = $('#fw_settings_plus .regular-text');
		var $desc = $('#fw_settings_plus p.description');

		var licenseKey = $licenseInput.val();
		var data = {
			'action': 'msfp_license_validate',
			'license_key': licenseKey
		};

		if (licenseKey) {
			// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
			jQuery.post(ajaxurl, data, function(response) {
				if (response === '0') {
					$desc.html('Your license is valid! You will receive updates for MSF-PLUS. <br>You can deregister your license to use it on another WordPress-Instance.');
					// render validate button TODO translate
					$licenseInput.after('<input id="msfp-license-deregister" class="button button-secondary" value="Deregister License" name="validate-key" id="validate-key" type="button">');
					setupDeregisterListener();				
				} else if (response === '1') {
					$desc.html('The license is already in use. Please deregister the license on the active WordPress instance!<br> Having trouble? <a href="mailto:info@mondula.com">We are happy to help.</a>');					
				} else if (response === '2') {
					$desc.html('Invalid license. No updates for you :(<br> Having trouble? <a href="mailto:info@mondula.com">We are happy to help.</a>');										
				} else {
					$desc.html('Oops, error!');																			
				}
			});
		}
	}

	/**
	 * Generates a select input to choose from the preceding blocks. These blocks can be used as preconditions.
	 * @param blockIndex index of the current block
	 */
	function renderChooseBlock(blockIndex) {
		var html = '<select class="msfp-conditional-prec-block-id">';
		html += '<option value="" disabled selected>select a block</option>'; // TODO: translation && tooltip
		var blockNum = 1; // numbering for option label  		
		$('.fw-step-block').each(function (index, element) {
			var blockType = $(element).attr('data-type');
			var selection = $(element).find('.fw-block-label').val();
			if (index < blockIndex && blockType !== 'paragraph' && blockType !== 'registration') {
				html += '<option value="' + index + '">' + blockNum++ + ' – ' + selection + '</option>';
			}
		});
		html += '</select>';
		return html;
	}

	function renderBlockIs($targetBlock) {
		var targetBlockType = $targetBlock.attr('data-type');		
		var html = '<div class="msfp-conditional-is">';
		switch (targetBlockType) {
			case 'textarea':
			case 'text':
			case 'email':
				html += '<span>is</span>'; // TODO: translation
				html += '<select class="msfp-conditional-prec-op">';
				html += '	<option value="fi">filled</option>'; // TODO: translation
				html += '	<option value="eq">equal to</option>'; // TODO: translation
				html += '</select>';
				html += '<input type="text" class="msfp-conditional-prec-value msfp-hidden">';
				break;
			case 'date':
				html += '<span>is</span>'; // TODO: translation
				html += '<select class="msfp-conditional-prec-op">';
				html += '	<option value="eq">equal to</option>'; // TODO: translation
				html += '	<option value="lt">before</option>'; // TODO: translation
				html += '	<option value="gt">after</option>'; // TODO: translation	
				html += '</select>';
				html += '<input class="msfp-conditional-prec-value" placeholder="Date in format yyyy-MM-dd" value="yyyy-MM-dd" type="date">'; // TODO: translation
				break;
			case 'radio':
				html += '<span>is</span>'; // TODO: translation
				html += '<select class="msfp-conditional-prec-op">';
				html += '	<option value="fi">filled</option>'; // TODO: translation
				html += '	<option value="eq">equal to</option>'; // TODO: translation
				html += '</select>';
				html += '<select class="msfp-conditional-prec-value msfp-hidden">';
				$targetBlock.find('.fw-radio-option').each(function(index, element) {
					html += '<option value="' + $(element).val() + '">' + $(element).val() + '</option>';
				});
				html += '</select>';
				break;
			case 'select':
				html += '<span>is</span>'; // TODO: translation
				html += '<input type="hidden" class="msfp-conditional-prec-op" value="eq">';
				html += '<select class="msfp-conditional-prec-value">';
				$($targetBlock.find('.fw-select-options').val().split('\n')).each(function(index, element) {
					if (element != '') {
						html += '<option value="' + element + '">' + element + '</option>';
					}
				});
				html += '</select>';
				
				break;
			default:
				break;
		}
		html += '</div>';
		return html;

	}

	function renderConditionalSettings(index, $block) {
		var html = '';
		html += '<div class="msfp-conditional-settings">';
		html += '	<div class="msfp-conditional-if">';
		html += '		<select class="msfp-conditional-visible">';
		html += '			<option value="show">show</option>'; // TODO: translation
		html += '			<option value="hide">hide</option>'; // TODO: translation
		html += '		</select>';
		html += '		<span>if</span>'; // TODO: translation
		html += 		renderChooseBlock(index);
		html += '	</div>';
		html += '	<div class="fw-clearfix"></div>';				
		html += '</div>';
		return html;
	}

	function fillSettings($block, settings) {
		$block.find('.msfp-conditional').prop('checked', true);
		$block.find('.msfp-conditional-settings').show();
		$block.find('.msfp-conditional-visible option[value=' + settings.visible + ']').attr('selected',true);
		$block.find('.msfp-conditional-prec-block-id').val(settings.prec_block_id).trigger('change');
		$block.find('.msfp-conditional-prec-op option[value=' + settings.prec_operator + ']').attr('selected',true);
		$block.find('.msfp-conditional-prec-value').val(settings.prec_value).trigger('change');
		if (settings.prec_operator !== 'fi') {
			$block.find('.msfp-conditional-prec-value').removeClass('msfp-hidden');
		}
	}

	/**
	 * 
	 * @param {jQuery element} the block to set up 
	 * @param {*} index index of the block
	 * @param {*} bump whether to increment the block index by one
	 */
	function setupConditional($block, index, bump) {
		var blockType = $block.attr('data-type');
		if (blockType !== 'registration' && blockType !== 'file' ){
			var settings = $block.find(".msf-block-meta").length ? JSON.parse(decodeURI($block.find(".msf-block-meta").val())) : null;
			var html = renderConditionalSettings(index, $block);
			if ($block.find('.msfp-conditional').length) {
				$block.find('.msfp-conditional-settings').replaceWith(html);
			} else {
				var checkbox = '<label><input class="msfp-conditional" type="checkbox">Conditional</label>'; 	// TODO: translation && tooltip
				$block.find('input.fw-required').parent().after(checkbox + html);				
			}
			setupConditionalListeners();		
			if (settings) {
				if (bump) {
					settings.prec_block_id++;
				}
				fillSettings($block, settings);
				$block.find('.msf-block-meta').val(encodeURI(JSON.stringify(settings)));
			} else if (! $block.find('.msfp-conditional').prop('checked')) {
				$block.find('.msfp-conditional-prec-value').hide();
				$block.find('.msfp-conditional-is').hide();
				$block.find('.msfp-conditional-settings').hide();
			}
		}
	}

	/**
	 * Refreshes the Conditional fields.
	 * @param {integer} newBlockIdx index of the newly added block. -1 if none was added
	 */
	function setupConditionals(newBlockIdx) {
		// append conditional checkbox and config div
		$('.fw-step-block').each(function (index, element) {
			if (newBlockIdx != -1 && index >= newBlockIdx) {
				// increment precondition index to keep conditional dependencies working
				setupConditional($(element), index, true);
			} else {
				setupConditional($(element), index, false);
			}
		});
		setupConditionalListeners();
	}

	function setupConditionalListeners() {
		$('.msfp-conditional-prec-block-id').unbind("change").change(function(event) {
			var $block = $($(event.target).parents('.fw-step-block'));
			var $targetBlock = $($('.fw-step-block')[$(event.target).val()]);
			$block.find('.msfp-conditional-is').remove();
			$(event.target).parents('.msfp-conditional-if').after(renderBlockIs($targetBlock));
			setupConditionalListeners();			
		});
		$('.msfp-conditional-prec-op').unbind("change").change(function(event) {
			var $block = $($(event.target).parents('.fw-step-block'));
			if ($(event.target).val() === 'fi') {
				$block.find('.msfp-conditional-prec-value').hide();
			} else {
				$block.find('.msfp-conditional-prec-value').show();				
			}
		});
		$('input.msfp-conditional').unbind("change").change(function(event) {
			var $conditionalSettings = $(event.target).parent().next();
			if ($(event.target).prop('checked')) {
				$conditionalSettings.slideDown();
			} else {
				$conditionalSettings.slideUp();				
			}
		});

		// reload conditionals on label or option change
		$('.fw-block-label').unbind("change").change(function(e) {
			setupConditionals(-1);
		});
		$('.fw-radio-option').unbind("change").change(function(e) {
			setupConditionals(-1);
		});
		$('.fw-select-options').unbind("change").change(function(e) {
			setupConditionals(-1);
		});
	}

	window.msfp = true;	
	window.setupConditionals = setupConditionals;

	$( window ).on('load', function() {
		$(".msfp-toggle-entry").click(function(e) {
			$(e.target).next().toggle();
		});

		setupConditionals(-1);
		setupLicenseAction();
	});


})( jQuery );
