<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link http://mondula.com
 * @since 1.0.0
 * @package Multi_Step_Form_Plus
 *
 * @wordpress-plugin
 * Plugin Name: Multi Step Form Plus
 * Plugin URI: http://mondula.com
 * Description: Plus-Extension for the free "Multi Step Form" Plugin
 * Version: 1.0.5
 * Author: Mondula GmbH
 * Author URI: http://mondula.com
 * Text Domain: multi-step-form-plus
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require 'includes/lib/plugin-update-checker/plugin-update-checker.php';
$my_update_checker = Puc_v4_Factory::buildUpdateChecker(
	'https://msfp-update.mondula.com/?action=get_metadata&slug=multi-step-form-plus', //Metadata URL.
	__FILE__, //Full path to the main plugin file.
	'multi-step-form-plus' //Plugin slug. Usually it's the same as the name of the directory.
);

// append license key to plugin update query
$my_update_checker->addQueryArgFilter( 'msfp_filter_append_credentials' );

function msfp_filter_append_credentials( $query_args ) {
	$settings = get_option( 'fw_settings_plus' );
	if ( ! empty( $settings['license_key'] ) ) {
		$query_args['license_key'] = $settings['license_key'];
	}
	return $query_args;
}

/**
 * Checks if Multi Step Form Plus is compatible with the WordPress setup and the active base plugin.
 */
function check_compatibility() {
	$msf_base = 'multi-step-form/mondula-form-wizard.php';
	$version_to_check = '1.1.8';
	$version_error = false;

	if ( is_plugin_active( $msf_base ) ) {
		$msf_base_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $msf_base );
		$version_error = ! version_compare( $msf_base_data['Version'], $version_to_check, '>=' ) ? true : false;
	}

	if ( $version_error ) {
		$message = __( 'Please update the Multi Step Form base plugin to at least version 1.1.8 before activating the plus plugin.', 'msf-plus' );
		echo '<strong>' . $message . '</strong>';

		//Adding @ before will prevent XDebug output
		@trigger_error( $message, E_USER_ERROR );
	}
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-multi-step-form-plus-activator.php
 */
function activate_multi_step_form_plus( $network_wide = false ) {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-multi-step-form-plus-activator.php';
	check_compatibility();
	Multi_Step_Form_Plus_Activator::activate( $network_wide );
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-multi-step-form-plus-deactivator.php
 */
function deactivate_multi_step_form_plus() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-multi-step-form-plus-deactivator.php';
	Multi_Step_Form_Plus_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_multi_step_form_plus' );
register_deactivation_hook( __FILE__, 'deactivate_multi_step_form_plus' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-multi-step-form-plus.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since 1.0.0
 */
function run_multi_step_form_plus() {

	$plugin = new Multi_Step_Form_Plus();
	$plugin->run();

}

add_action( 'msf_loaded', 'run_multi_step_form_plus' );
