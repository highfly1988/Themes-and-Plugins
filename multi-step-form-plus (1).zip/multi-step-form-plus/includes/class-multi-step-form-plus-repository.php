<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Description of class-mondula-multistep-forms-wizard-repository
 *
 * @author Lewe Ohlsen <lewe.ohlsen@mondula.com>
 */
class Multi_Step_Form_Plus_Repository {

	private $_entries_table;
	private $_forms_table;

	public function __construct( $entries_table_name, $forms_table_name ) {
		global $wpdb;
		$this->_entries_table = $wpdb->prefix . $entries_table_name;
		$this->_forms_table = $wpdb->prefix . $forms_table_name;
	}

	/**
	 * Queries the database for all entries.
	 */
	 public function find() {
		global $wpdb;
		$sql = "SELECT * FROM {$this->_entries_table}";
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	/**
	 * Queries the Database for all entries with a specific form id.
	 */
	public function find_by_form_id( $form_id ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM {$this->_entries_table} WHERE form_id = %d", $form_id );
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	/**
	 * Queries the Database for an entry with id.
	 */
	public function find_entry( $entry_id ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM {$this->_entries_table} WHERE id = %d", $entry_id );
		return $wpdb->get_row( $sql );
	}

	/**
	 * Finds a form by ID and returns the row.
	 */
	public function find_form( $id ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM {$this->_forms_table} WHERE id = %d", $id );
		return $wpdb->get_row( $sql );
	}

	/**
	 * Searches for an entry that has JSON similar to the keyword.
	 */
	public function search( $keyword ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM {$this->_entries_table} WHERE json LIKE '%%%s%%'", $keyword );
		return $wpdb->get_results( $sql, ARRAY_A );
	}

	/**
	 * Updates the database table.
	 */
	public function update( $id, $data ) {
		global $wpdb;
		$wpdb->update( $this->_entries_table, $data, array( 'id' => $id ) );
		return $id;
	}

	public function save( $data ) {
			global $wpdb;

			$wpdb->insert( $this->_entries_table, $data);

			return $wpdb->insert_id;
	}

	public function delete( $id ) {
			global $wpdb;

			$wpdb->delete( $this->_entries_table, array( 'id' => $id ) );
	}
}
