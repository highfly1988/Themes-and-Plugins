<?php

/**
 * This is the class for a Form Entry. Form Entries are created when a user fills out a Multi Step Form.
 *
 * @since 1.0.0
 * @package Multi_Step_Form_Plus
 * @subpackage Multi_Step_Form_Plus/includes/lib
 * @author Mondula GmbH <lewe.ohlsen@mondula.com>
 */
class Multi_Step_Form_Plus_Entry {

	private $id;
	private $form_id;
	private $fields_struct;
	private $fields;
	private $version;
	private $date;

	/**
	 * Constructor.
	 */
	function __construct( $row ) {
		$this->id = $row->id;
		$this->form_id = $row->form_id;
		$this->fields_struct = json_decode( $row->json, true );
		$this->fields = $this->get_fields();
		$this->version = $row->version;
		$this->date = $row->date;
	}

	/**
	 * Getter for the corresponsing form ID.
	 */
	public function get_form_id() {
		return $this->form_id;
	}

	/**
	 * Getter for the corresponsing form ID.
	 */
	public function get_date() {
		return $this->date;
	}

	/**
	 * Gets all the fields of an entry.
	 * @param the entry object
	 * @return aa with field key and value
	 */
	private function get_fields() {
		$entry_fields = [];
		foreach ( $this->fields_struct as $section => $fields ) {
			foreach ( $fields as $field ) {
				$entry_fields[ key( $field ) ] = $field[ key( $field ) ];
			}
		}
		return $entry_fields;
	}

	/**
	 * Generates the first line of CSV for an entry.
	 */
	public function csv_header( $form, $separator ) {
		$csv = '';
		foreach ( $this->labels( $form ) as $label ) {
			$csv .= $label . $separator;
		}
		return substr( $csv, 0, -1 );
	}

	/**
	 * Returns the CSV for this entry.
	 */
	public function to_csv( $form, $separator ) {
		$labels = $this->labels( $form );
		$csv = '';

		foreach ( $labels as $label ) {
			if ( array_key_exists( $label, $this->fields ) ) {
				$value = $this->fields[ $label ];
				/* Wrap in quotes if cell contains separator */
				if ( strpos( $this->fields[ $label ], $separator ) !== false ) {
					$value = '"' . $this->fields[ $label ] . '"';
				}
				$csv .= $value . $separator;
			} else {
				$csv .= $separator;
			}
		}
		/* delete last separator and return */
		return substr( $csv, 0, -1 );
	}

	/**
	 * Returns HTML for the fields for an entry.
	 * @param item
	 */
	public function to_html() {
		$html = '<button type="button" class="toggle-row msfp-toggle-entry" data-id="' . $this->id . '"><span class="screen-reader-text">Show more details</span></button>';
		$html .= '<div class="msfp-entry-fields">';
		foreach ( $this->fields_struct as $section => $fields ) {
			$html .= '<h3>' . $section . '</h3>';
			foreach ( $fields as $field ) {
				foreach ( $field as $label => $value ) {
					$html .= '<p><strong>' . $label . ':</strong> ' . $value . '</p>';
				}
			}
		}
		$html .= '</div>';
		return $html;
	}

	/**
	 * Calculates how complete the form is filled by dividing
	 * the entrys field cound by the total field count.
	 */
	public function pct_complete( $form ) {
		$fieldcount = (float) count( $this->labels( $form ) ) != 0 ? (float) count( $this->labels( $form ) ) : count( $this->fields );
		return round( count( $this->fields ) / $fieldcount  * 100 );
	}


	/**
	 * Gets the label of a CSV column for a block. Recursive unwrapping if block is conditional.
	 * @return String
	 */
	private function get_block_label( $block ) {
		switch ( $block['type'] ) {
			case 'text':
			case 'textarea':
			case 'email':
			case 'date':
			case 'select':
				return $block['label'];
			case 'radio':
				return $block['elements'][0]['value'];
			case 'conditional':
				return $this->get_block_label( $block['block'] );
			default:
				break;
		}
	}

	/**
	 * Gets all the form labels for CSV column names.
	 * @return array of form labels
	 */
	public function labels( $form ) {
		$labels = [];
		foreach ( $form['steps'] as $step ) {
			if (array_key_exists('parts', $step)) {
				foreach ( $step['parts'] as $part ) {
					if (array_key_exists('blocks', $part)) {						
						foreach ( $part['blocks'] as $block ) {
							array_push( $labels, $this->get_block_label( $block ) );
						}
					}
				}
			}
		}
		return $labels;
	}
}
