<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of class-mondula-multistep-forms-block-submit
 *
 * @author alex
 */
class Multi_Step_Form_Plus_Block_Conditional extends Mondula_Form_Wizard_Block {
	/* The block Object to wrap and make conditional */
	private $_block;
	/* The block to be filled in order to show this block */
	private $_precondition_block_id;
	/* The value to compare the above blocks value against */
	private $_precondition_value;
	/* Less, greater or equal */
	private $_precondition_operator;
	/* To show or to hide on met condition */
	private $_visible;

	protected static $type = 'fw-conditional';

	public function __construct( $block, $pre_block_id, $pre_value, $pre_op, $visible ) {
		$this->_block = $block;
		$this->_precondition_block_id = $pre_block_id;
		$this->_precondition_value = $pre_value;
		$this->_precondition_operator = $pre_op;
		$this->_visible = $visible;
	}

	public function get_required() {
		return null;
	}

	public function render( $ids ) {
		?>
		<div class="fw-step-block msfp-block-conditional"
		data-visible="<?php echo $this->_visible; ?>"
		data-prec-block-id="<?php echo $this->_precondition_block_id; ?>"
		data-prec-value="<?php echo $this->_precondition_value; ?>"
		data-prec-op="<?php echo $this->_precondition_operator; ?>">
			<?php
			$this->_block->render( $ids );
			?>
		</div>
		<?php
	}

	public function as_aa() {
		return array(
			'type' => 'conditional',
			'block' => $this->_block->as_aa(),
			'prec_block_id' => $this->_precondition_block_id,
			'prec_value' => $this->_precondition_value,
			'prec_operator' => $this->_precondition_operator,
			'visible' => $this->_visible,
		);
	}

	public static function from_aa( $aa, $current_version, $serialized_version ) {
		$block = Mondula_Form_Wizard_Block::from_aa( $aa['block'], $current_version, $serialized_version );
		if ( $aa['prec_block_id'] != '' ) {
			$prec_block_id = $aa['prec_block_id'];
			$prec_value = $aa['prec_value'];
			$prec_operator = $aa['prec_operator'];
			$visible = $aa['visible'];

			return new Multi_Step_Form_Plus_Block_Conditional( $block, $prec_block_id, $prec_value, $prec_operator, $visible );
		}
		// unwrap if invalid settings
		return $block;
	}
}
