<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Description of class-mondula-multistep-forms-block-submit
 *
 * @author alex
 */
class Multi_Step_Form_Plus_Block_Registration extends Mondula_Form_Wizard_Block {
	private $_required;
	private $_username;
	private $_password;
	private $_firstname;
	private $_lastname;
	private $_website;
	private $_bio;

	protected static $type = 'fw-registration';

	public function __construct( $required, $password, $firstname, $lastname, $website, $bio ) {
		$this->_required = $required;
		$this->_password = $password;
		$this->_firstname = $firstname;
		$this->_lastname = $lastname;
		$this->_website = $website;
		$this->_bio = $bio;
	}

	public function get_required() {
		return $this->_required;
	}

	public function render( $ids ) {
		$reg_translation = Mondula_Form_Wizard_Admin::get_translation()['registration'];
		?>
		<div class="fw-step-block" data-blockId="<?php echo $ids[0]; ?>" data-type="fw-registration" data-required="<?php echo $this->_required; ?>">
		<?php
		if ( ! is_user_logged_in() ) {
		?>
				<div class="fw-input-container msfp-input-container-username">
					<h3><?php echo $reg_translation['username']; ?></h3>
					<input type="text" class="msfp-registration-input" data-id="username">
					<span class="fa fa-user form-control-feedback" aria-hidden="true"></span>
				</div>
				<div class="fw-input-container msfp-input-container-email">
					<h3>Email</h3>
					<input type="text" class="msfp-registration-input" data-id="email">
					<span class="fa fa-envelope form-control-feedback" aria-hidden="true"></span>
				</div>
					<?php if ( $this->_password === 'true' ) { ?>
						<div class="fw-input-container msfp-input-container-password">
							<h3><?php echo $reg_translation['password']; ?></h3>
							<input type="password" class="msfp-registration-input" data-id="password">
							<span class="fa fa-unlock-alt form-control-feedback" aria-hidden="true"></span>
						</div>
						<!-- <h3><?php //echo $reg_translation['password-confirm']; ?></h3>
						<input type="password" class="msfp-registration-input" data-id="password-confirm">
						<span class="fa fa-unlock-alt form-control-feedback" aria-hidden="true"></span> -->
					<?php } ?>
					<?php if ( $this->_firstname === 'true' ) { ?>
						<div class="fw-input-container msfp-input-container-firstname">
							<h3><?php echo $reg_translation['firstname']; ?></h3>
							<input type="text" class="msfp-registration-input" data-id="firstname">
							<span class="fa fa-pencil form-control-feedback" aria-hidden="true"></span>
						</div>
					<?php } ?>
					<?php if ( $this->_lastname === 'true' ) { ?>
						<div class="fw-input-container msfp-input-container-lastname">
							<h3><?php echo $reg_translation['lastname']; ?></h3>
							<input type="text" class="msfp-registration-input" data-id="lastname">
							<span class="fa fa-pencil form-control-feedback" aria-hidden="true"></span>
						</div>
					<?php } ?>
					<?php if ( $this->_website === 'true' ) { ?>
						<div class="fw-input-container msfp-input-container-website">
							<h3><?php echo $reg_translation['website']; ?></h3>
							<input type="text" class="msfp-registration-input" data-id="website">
							<span class="fa fa-globe form-control-feedback" aria-hidden="true"></span>
						</div>
					<?php } ?>
					<?php if ( $this->_bio === 'true' ) { ?>
						<div class="fw-input-container msfp-input-container-bio">
							<h3><?php echo $reg_translation['bio']; ?></h3>
							<textarea class="msfp-registration-input fw-textarea" data-id="bio"></textarea>
							<span class="fa fa-pencil form-control-feedback" aria-hidden="true"></span>
						</div>
					<?php } ?>
				
		<?php
		} else {
			?>
			<p class="msfp-loggedin"><?php echo $reg_translation['loggedin']; ?></p>
			<?php
		}
		?>
		</div>
		<div class="fw-clearfix"></div>
		<?php
	}

	public function as_aa() {
		return array(
			'type' => 'registration',
			'required' => $this->_required,
			'password' => $this->_password,
			'firstname' => $this->_firstname,
			'lastname' => $this->_lastname,
			'website' => $this->_website,
			'bio' => $this->_bio,
		);
	}

	public static function from_aa( $aa, $current_version, $serialized_version ) {
		$required = $aa['required'];
		$password = $aa['password'];
		$firstname = $aa['firstname'];
		$lastname = $aa['lastname'];
		$website = $aa['website'];
		$bio = $aa['bio'];

		return new Multi_Step_Form_Plus_Block_Registration( $required, $password, $firstname, $lastname, $website, $bio );
	}
}
