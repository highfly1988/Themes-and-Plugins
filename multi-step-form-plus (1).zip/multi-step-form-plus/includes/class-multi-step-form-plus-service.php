<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Description of class-mondula-multistep-forms-wizard-repository
 *
 * @author Lewe Ohlsen <lewe.ohlsen@mondula.com>
 */
class Multi_Step_Form_Plus_Service {

	private $_repository;

	private $_plugin_version;

	public function __construct( Multi_Step_Form_Plus_Repository $repository, $plugin_version ) {
		$this->_repository = $repository;
		$this->_plugin_version = $plugin_version;
	}

	/**
	 * Gets one or multiplke entries by ID.
	 */
	public function get_entries( $ids ) {
		if ( is_array( $ids ) ) {
			$entries = [];
			foreach ( $ids as $id ) {
				array_push( $entries, new Multi_Step_Form_Plus_Entry( $this->_repository->find_entry( $id ) ) );
			}
			return $entries;
		}
		return new Multi_Step_Form_Plus_Entry( $this->_repository->find_entry( $ids ) );
	}

	/**
	 * Finds and returns a form object using its id.
	 */
	public function get_form( $id ) {
		$form_json = $this->_repository->find_form( $id )->json;
		return json_decode( $form_json, true );
	}

	/**
	 * Gets all entries.
	 */
	public function get_all_entries() {
		return $this->_repository->find();
	}

	/**
	 * Searches for entries that contain a given keyword.
	 * @param the search term
	 */
	public function get_by_keyword( $keyword ) {
		return $this->_repository->search( $keyword );
	}

	/**
	 * Saves an entry to the database.
	 * @param form_id the corresponding form id
	 * @param data the form data filled by the user
	 */
	public function save_entry( $form_id, $data ) {
		$row = array();
		$row['date'] = current_time( 'mysql' );
		$row['json'] = json_encode( $data );
		$row['form_id'] = $form_id;
		$row['version'] = $this->_plugin_version;
		// var_dump ( $row );
		return $this->_repository->save( $row );
	}

	/**
	 * Delete an entry from the database.
	 */
	public function delete_entry( $ids ) {
		if ( is_array( $ids )) {
			foreach ( $ids as $id ) {
				$this->_repository->delete( $id );
			}
		} else {
			$this->_repository->delete( $ids );
		}
	}

}
