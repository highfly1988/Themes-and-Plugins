<?php

/**
 * Fired during plugin deactivation
 *
 * @link			 http://mondula.com
 * @since			1.0.0
 *
 * @package		Multi_Step_Form_Plus
 * @subpackage Multi_Step_Form_Plus/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since			1.0.0
 * @package		Multi_Step_Form_Plus
 * @subpackage Multi_Step_Form_Plus/includes
 * @author		 Mondula GmbH <lewe.ohlsen@mondula.com>
 */
class Multi_Step_Form_Plus_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since		1.0.0
	 */
	public static function deactivate() {

	}

}
