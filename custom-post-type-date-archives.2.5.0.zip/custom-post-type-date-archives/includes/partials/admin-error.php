<div class="wrap">
	<h1><?php _e( 'Date Archives', 'custom-post-type-date-archives' ); ?></h1>
	<?php settings_errors(); ?>
	<?php include 'admin-info.php'; ?>
</div>