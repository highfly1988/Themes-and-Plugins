---
title: Genesis Changelog
menuTitle: Changelog
layout: layouts/changelog.njk
permalink: changelog/index.html
tags: docs
---

Browse the full release history for the Genesis Framework.

<p class="notice-small">Linked version numbers will lead to a 404 Not Found page unless you are logged into GitHub and have <a href="{{ '/contribute/genesis-core' | url }}">access to the Genesis GitHub repository</a>.</p>

<!-- The changelog is output in the layouts/changelog.njk template. -->
