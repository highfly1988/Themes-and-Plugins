# AngularJS & ReactJS WordPress Theme
A WordPress theme built with AngularJS as the controller and ReactJS as the view layer.  
Powered by WP-API - [DEMO] (http://roysivan.com/react-angularjs-wordpress-theme)
  
# Install  
Make sure you have WordPress already running, along withe the JSON REST API (WP-API) plugin installed and activated  
* Clone Repo
* Run `npm install`
* Run `bower update`

  
__Thank you to [Jack Lenox](https://twitter.com/jacklenox)__ for starting the ReactJS WordPress theme so I have some code to look at.
