<?php
/**
 * Just show XML full page
 */
?> 

<pre><?php $params->e('xml')?></pre>
