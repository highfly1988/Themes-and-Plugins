<?php

// wish you a nice day, and never come back