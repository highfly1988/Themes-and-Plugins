<?php

die( 'Don\'t try to load this file directly!' );