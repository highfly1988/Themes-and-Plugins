<?php
class BookingUltraProUltimate
{

		
	public function __construct()
	{		
	
		$this->load_core();	
				
	
    }
	
	public function load_core() 
	{	
		
				
				
			
	}
	
	
}
?>