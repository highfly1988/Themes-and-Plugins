/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {
    
    'use strict';

    function append_css_to_head(id, style){
        var oldstyle = $('head').find('#'+id);
        if(oldstyle.length){
            oldstyle.remove();
            $('head').append(style);
        }else{
            $('head').append(style);
        }
    }

	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// Header text color.
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( to ) {
			if ( 'blank' === to ) {
				$( '.site-title, .site-description' ).css( {
					'clip': 'rect(1px, 1px, 1px, 1px)',
					'position': 'absolute'
				} );
			} else {
				$( '.site-title, .site-description' ).css( {
					'clip': 'auto',
					'position': 'relative'
				} );
				$( '.site-title a, .site-description' ).css( {
					'color': to
				} );
			}
		} );
	} );

    wp.customize( 'ciestra_footer_text', function (value) {
        value.bind(function (to) {
            $('.site-info').html(to);
        });
    });

	wp.customize( 'ciestra_first_color', function (value) {
		value.bind( function (to) {
            var id = 'customize-preview-first-color',
                css = '<style id="'+id+'">' +
						'blockquote:before,'+
						'.navigation.pagination .page-numbers.prev:hover:after,'+
						'.navigation.pagination .page-numbers.next:hover:after,'+
						'.testimonials-wrapper .entry-content:before,'+
						'.has-primary-background-color'+
						'{'+
							'background-color: '+to+';'+
						'}'+
						'.button,'+
						'button,'+
						'input[type="button"],'+
						'input[type="reset"],'+
						'input[type="submit"],'+
						'a.more-link:after,'+
						'.main-navigation ul ul a:before,'+
						'.navigation.pagination .page-numbers:after,'+
						'.wp-block-file .wp-block-file__button,'+
						'.wp-block-button__link'+
						'{'+
							'background: '+to+';'+
						'}'+
						'a.more-link,'+
						'a.more-link:focus,'+
						'a.more-link:active,'+
						'.theme-social-menu li a:hover,'+
						'.main-navigation ul ul .current_page_item > a .menu-text,'+
						'.main-navigation ul ul .current-menu-item > a .menu-text,'+
						'.main-navigation ul ul .current_page_ancestor > a .menu-text,'+
						'.main-navigation ul ul .current-menu-ancestor > a .menu-text,'+
						'.main-navigation a:hover,'+
						'.main-navigation .current_page_item > a,'+
						'.main-navigation .current-menu-item > a,'+
						'.main-navigation .current_page_ancestor > a,'+
						'.main-navigation .current-menu-ancestor > a,'+
						'.dropdown-toggle:hover, .dropdown-toggle:focus,'+
						'.navigation.post-navigation .nav-links .nav-previous a:hover .post-title,'+
						'.navigation.post-navigation .nav-links .nav-next a:hover .post-title,'+
						'.search-form .search-submit:hover,'+
						'.entry-meta > span.featured,'+
						'.entry-meta > span.featured .fa,'+
						'.comments-area .comment-list .comment .comment-meta .fn a:hover,'+
						'.comments-area .comment-list .comment .comment-meta .fn a:focus,'+
						'.fp-page-header-wrapper .front-page-nav-menus .front-page-contacts-container ul li a:hover,'+
						'.fp-page-header-wrapper .front-page-nav-menus .front-page-contacts-container ul li a:focus,'+
						'.fp-page-header-wrapper .front-page-nav-menus .front-page-socials li a:hover,'+
						'.wp-block-button.is-style-outline .wp-block-button__link,'+
						'.has-primary-color'+
						'{'+
							'color: '+to+';'+
						'}'+
						'input[type="text"]:focus,'+
						'input[type="email"]:focus,'+
						'input[type="url"]:focus,'+
						'input[type="password"]:focus,'+
						'input[type="search"]:focus,'+
						'input[type="number"]:focus,'+
						'input[type="tel"]:focus,'+
						'input[type="range"]:focus,'+
						'input[type="date"]:focus,'+
						'input[type="month"]:focus,'+
						'input[type="week"]:focus,'+
						'input[type="time"]:focus,'+
						'input[type="datetime"]:focus,'+
						'input[type="datetime-local"]:focus,'+
						'input[type="color"]:focus,'+
						'textarea:focus,'+
						'select:focus'+
						'{'+
							'border-color: '+to+';'+
						'}'+
						'.slick-prev:hover:after,'+
						'.slick-next:hover:after,'+
						'.entry-content .elementor-slick-slider .slick-prev:hover:after,'+
						'.entry-content .elementor-slick-slider .slick-next:hover:after'+
						'{'+
							'background-color: '+to+';'+
						'}'+
						'.elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-description-wrapper .mphb-view-details-button,'+
						'.slick-prev:after,'+
						'.slick-next:after,'+
						'.entry-content .elementor-slick-slider .slick-prev:after,'+
						'.entry-content .elementor-slick-slider .slick-next:after'+
						'{'+
							'background: '+to+';'+
						'}'+
						'.slick-dots .slick-active button:after, .slick-dots li:hover button:after {'+
							'background: '+to+';'+
							'-webkit-box-shadow: 0 0 0 4px '+to+'40;'+
							'box-shadow: 0 0 0 4px '+to+'40;'+
						'}'+

						'.elementor-widget-button .elementor-button,'+
						'.elementor-widget-button.elementor-button-info .elementor-button:hover'+
						'{'+
							'background-color: '+to+' !important;'+
						'}.mphb-calendar .datepick-ctrl a,'+
						'.datepick-popup .datepick-ctrl a,'+
						'.datepick-popup .mphb-datepick-popup .datepick-month td .datepick-today,'+
						'.mphb-view-details-button,'+
						'.mphb-service-title > a:hover'+
						'{'+
							'color: '+to+';'+
						'}'+
						'.mphb-view-details-button:after'+
						'{'+
							'background: '+to+';'+
						'}'+
						'.mphb-calendar.mphb-datepick .datepick-month td .datepick-selected,'+
						'.datepick-popup .mphb-datepick-popup .datepick-month td .datepick-selected,'+
						'.datepick-popup .mphb-datepick-popup .datepick-month td a.datepick-highlight,'+
						'.mphb-calendar.mphb-datepick .datepick-month td .mphb-booked-date,'+
						'body .mphb-flexslider.flexslider ul.flex-direction-nav a:hover,'+
						'body .flexslider ul.flex-direction-nav a:hover'+
						'{'+
							'background-color: '+to+';'+
						'}'+
						'body .mphb-flexslider.flexslider ol.flex-control-nav li a.flex-active, body .mphb-flexslider.flexslider ol.flex-control-nav li a:hover,'+
						'body .flexslider ol.flex-control-nav li a.flex-active,'+
						'body .flexslider ol.flex-control-nav li a:hover {'+
							'background: '+to+' !important;'+
							'-webkit-box-shadow: 0 0 0 4px '+to+'80;'+
							'box-shadow: 0 0 0 4px '+to+'80;'+
						'}'+
						'input[type="text"].mphb-datepick.is-datepick:focus, input[type="text"].mphb-datepick.is-datepick:active'+
						'{'+
							'background-image: url("../images/calendar_passive.svg");'+
						'}'+
						'select:active, select:focus {'+
							'background-image: url("../images/arrow_passive.svg");'+
						'}'+
                    '</style>';

            append_css_to_head(id, css);					
        })
    });

    wp.customize( 'ciestra_second_color', function (value) {
        value.bind( function (to) {
            var id = 'customize-preview-second-color',
                css = '<style id="'+id+'">' +
					'code, kbd, tt, var,'+
					'a.more-link:hover:after'+
					'{'+
						'background: '+to+';'+
					'}'+
					'.button:hover,'+
					'button:hover,'+
					'input[type="button"]:hover,'+
					'input[type="reset"]:hover,'+
					'input[type="submit"]:hover,'+
					'.wp-block-button.is-style-outline .wp-block-button__link:hover,'+
					'.wp-block-button.is-style-outline .wp-block-button__link:focus'+
					'{'+
						'border-color: '+to+';'+
						'background: '+to+';'+
					'}'+
					'.button:active, .button:focus,'+
					'button:active,'+
					'button:focus,'+
					'input[type="button"]:active,'+
					'input[type="button"]:focus,'+
					'input[type="reset"]:active,'+
					'input[type="reset"]:focus,'+
					'input[type="submit"]:active,'+
					'input[type="submit"]:focus'+
					'{'+
						'border-color: '+to+';'+
					'}'+
					'a.more-link:hover,'+
					'a,'+
					'a:hover,'+
					'a:focus,'+
					'a:active,'+
					'.hentry .entry-title a:hover,'+
					'.entry-meta a:hover'+
					'{'+
						'color: '+to+';'+
					'}'+
					'.wp-block-file .wp-block-file__button:hover, .wp-block-file .wp-block-file__button:focus,'+
					'.wp-block-button__link:hover,'+
					'.wp-block-button__link:focus {'+
						'border-color: '+to+' !important;'+
						'background: '+to+' !important;'+
					'}'+
					'.elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-description-wrapper .mphb-view-details-button:hover'+
					'{'+
						'background: '+to+';'+
					'}'+
					'.elementor-widget-button .elementor-button:hover,'+
					'.elementor-widget-button.elementor-button-info .elementor-button'+
					'{'+
						'background-color: '+to+' !important;'+
					'}'+
					'.mphb-view-details-button:hover:after, .mphb-view-details-button:focus:after'+
					'{'+
						'background: '+to+';'+
					'}'+
					'.mphb-view-details-button:hover, .mphb-view-details-button:focus'+
					'{'+
						'color: '+to+';'+
					'}'+
                    '</style>';

            append_css_to_head(id, css);
        })
    });

    wp.customize( 'ciestra_third_color', function (value) {
        value.bind( function (to) {
            var id = 'customize-preview-third-color',
                css = '<style id="'+id+'">' +
				'.navigation.pagination .page-numbers.prev:after,'+
				'.navigation.pagination .page-numbers.next:after'+
				'{'+
					'background-color: '+to+';'+
				'}'+
				'.navigation.post-navigation .nav-links .nav-previous a:hover img,'+
				'.navigation.post-navigation .nav-links .nav-next a:hover img {'+
					'-webkit-box-shadow: 10px 10px 0 '+to+';'+
					'box-shadow: 10px 10px 0 '+to+';'+
				'}'+
				'.navigation.post-navigation .nav-links .nav-previous img,'+
				'.navigation.post-navigation .nav-links .nav-next img'+
				'{'+
					'-webkit-box-shadow: 20px 20px 0 '+to+';'+
					'box-shadow: 20px 20px 0 '+to+';'+
				'}'+
				'.widget-area .widget,'+
				'.hentry .post-thumbnail img {'+
					'-webkit-box-shadow: 10px 10px 0 '+to+';'+
					'box-shadow: 10px 10px 0 '+to+';'+
				'}'+
				'.fp-page-header-wrapper .fp-entry-header-wrapper:before'+
				'{'+
					'background: '+to+';'+
				'}'+
				'@media screen and(max-width: 991px){'+
            		'.front-page-widget-area{'+
                    	'background: '+to+';'+
                	'}'+
            	'}'+
				'@media (min-width: 768px) {'+
					'.hentry .post-thumbnail img {'+
						'-webkit-box-shadow: 20px 20px 0 '+to+';'+
						'box-shadow: 20px 20px 0 '+to+';'+
					'}'+
				'}'+
				'@media (min-width: 992px) {'+
					'.hentry .post-thumbnail img {'+
						'-webkit-box-shadow: 40px 40px 0 '+to+';'+
						'box-shadow: 40px 40px 0 '+to+';'+
					'}'+
				'}'+
				'@media (min-width: 992px) {'+
					'.hentry a.post-thumbnail:hover img {'+
						'-webkit-box-shadow: 20px 20px 0 '+to+';'+
						'box-shadow: 20px 20px 0 '+to+';'+
					'}'+
				'}'+
				'.slick-prev:after,'+
				'.slick-next:after,'+
				'.entry-content .elementor-slick-slider .slick-prev:after,'+
				'.entry-content .elementor-slick-slider .slick-next:after'+
				'{'+
					'background-color: '+to+';'+
				'}'+
				'.elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-images-wrapper > *:after,'+
				'.amenities-slider .type-cptp-amenity .post-thumbnail:after,'+
				'.recent-posts-widget .post .thumbnail-wrapper .post-thumbnail:after'+
				'{'+
					'background: '+to+';'+
				'}'+
				'@media (min-width: 992px) {'+
					'.single-room-type .mphb-reservation-form {'+
						'-webkit-box-shadow: 10px 10px 0 '+to+';'+
						'box-shadow: 10px 10px 0 '+to+';'+
					'}'+
				'}'+
				'.room-images-wrapper > * {'+
					'-webkit-box-shadow: 40px 40px 0 '+to+';'+
					'box-shadow: 40px 40px 0 '+to+';'+
				'}'+
				'body .mphb-flexslider.flexslider ul.flex-direction-nav a,'+
				'body .flexslider ul.flex-direction-nav a'+
				'{'+
					'background-color: '+to+';'+
				'}'+
            '</style>';
            append_css_to_head(id, css);
        })
    });


} )( jQuery );
