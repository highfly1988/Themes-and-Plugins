<?php
/**
 * The sidebar containing front page widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ciestra
 */

if ( ! is_active_sidebar( 'sidebar-3' ) ) {
    return;
}

?>

<aside id="front-page-sidebar" class="front-page-widget-area">
    <?php dynamic_sidebar( 'sidebar-3' ); ?>
</aside><!-- #secondary -->
