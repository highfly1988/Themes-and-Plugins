<?php
/**
 * ciestra Theme Customizer
 *
 * @package ciestra
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function ciestra_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'ciestra_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'ciestra_customize_partial_blogdescription',
		) );
	}

    $wp_customize->add_panel('ciestra_theme_options', array(
        'title' => esc_html__('Theme Options', 'ciestra')
    ));
    $wp_customize->add_section('ciestra_blog_options', array(
        'title' => esc_html__('Blog Options', 'ciestra'),
        'panel' => 'ciestra_theme_options'
    ));
    $wp_customize->add_setting('ciestra_blog_layout', array(
        'default' => 'no-sidebar',
        'sanitize_callback' => 'ciestra_sanitize_select'
    ));
    $wp_customize->add_control('ciestra_blog_layout', array(
        'label' => esc_html__('Blog Layout', 'ciestra'),
        'description' => esc_html__('Layout will be applied to blog and post archive pages', 'ciestra'),
        'type' => 'select',
        'section' => 'ciestra_blog_options',
        'settings' => 'ciestra_blog_layout',
        'choices' => array(
            'no-sidebar' => esc_html__('No Sidebar', 'ciestra'),
            'with-sidebar' => esc_html__('With Sidebar', 'ciestra')
        )
    ));


    /**
     * FOOTER OPTIONS
     */
    $wp_customize->add_section('ciestra_footer_options', array(
        'title' => esc_html__('Footer Options', 'ciestra'),
        'panel' => 'ciestra_theme_options'
    ));

    $wp_customize->add_setting('ciestra_show_footer_text', array(
        'default' => true,
        'transport' => 'refresh',
        'type' => 'theme_mod',
        'sanitize_callback' => 'ciestra_sanitize_checkbox'
    ));
    $wp_customize->add_control('ciestra_show_footer_text', array(
            'label' => esc_html__('Show Footer Text?', 'ciestra'),
            'section' => 'ciestra_footer_options',
            'type' => 'checkbox',
            'settings' => 'ciestra_show_footer_text'
        )
    );

    $wp_customize->add_setting('ciestra_footer_text', array(
        'default' => esc_html_x('%2$s &copy; %1$s All Rights Reserved.', 'Default footer text. %1$s - current year, %2$s - site title.', 'ciestra'),
        'transport' => 'postMessage',
        'type' => 'theme_mod',
        'sanitize_callback' => 'ciestra_sanitize_text'
    ));
    $wp_customize->add_control('ciestra_footer_text', array(
            'label' => esc_html__('Footer Text', 'ciestra'),
            'description' => esc_html__('Use %1$s to insert the current year and %2$s - the site title. Doesn`t work for Live Preview.', 'ciestra'),
            'section' => 'ciestra_footer_options',
            'type' => 'textarea',
            'settings' => 'ciestra_footer_text'
        )
    );

    /**
     * SIDEBAR OPTIONS
     */
    $wp_customize->add_section('ciestra_sidebar_options', array(
        'title' => esc_html__('Sidebar Options', 'ciestra'),
        'panel' => 'ciestra_theme_options'
    ));

    $wp_customize->add_setting('ciestra_widget_image', array(
        'default'           => get_template_directory_uri().'/images/wave_line.svg',
        'transport'         => 'refresh',
        'sanitize_callback' => 'ciestra_sanitize_image'
    ));
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ciestra_widget_image', array(
        'label'             => esc_html__('Widget Title Image', 'ciestra'),
        'section'           => 'ciestra_sidebar_options',
        'settings'          => 'ciestra_widget_image',
    )));

    /**
     * COLOR SETTINGS
     */

    $wp_customize->add_setting('ciestra_first_color', array(
        'default' => CIESTRA_FIRST_COLOR,
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ciestra_first_color', array(
        'label' => esc_html__('First Color', 'ciestra'),
        'section' => 'colors',
    )));

    $wp_customize->add_setting('ciestra_second_color', array(
        'default' => CIESTRA_SECOND_COLOR,
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ciestra_second_color', array(
        'label' => esc_html__('Second Color', 'ciestra'),
        'section' => 'colors',
    )));

    $wp_customize->add_setting('ciestra_third_color', array(
        'default' => CIESTRA_THIRD_COLOR,
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ciestra_third_color', array(
        'label' => esc_html__('Third Color', 'ciestra'),
        'section' => 'colors',
    )));

}
add_action( 'customize_register', 'ciestra_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function ciestra_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function ciestra_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function ciestra_customize_preview_js() {
	wp_enqueue_script( 'ciestra-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), ciestra_get_theme_version(), true );
}
add_action( 'customize_preview_init', 'ciestra_customize_preview_js' );

function ciestra_sanitize_select( $input, $setting ){

    //input must be a slug: lowercase alphanumeric characters, dashes and underscores are allowed only
    $input = sanitize_key($input);

    //get the list of possible select options
    $choices = $setting->manager->get_control( $setting->id )->choices;

    //return input if valid or return default option
    return ( array_key_exists( $input, $choices ) ? $input : $setting->default );

}

function ciestra_sanitize_checkbox( $input ){
    if ($input == 1) {
        return 1;
    } else {
        return '';
    }
}

function ciestra_sanitize_image( $input ) {
    return esc_url_raw( ciestra_validate_image( $input ) );
}

function ciestra_validate_image( $input ){
    // Array of valid image file types
    // The array includes image mime types
    // that are included in wp_get_mime_types()
    $mimes = array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png' => 'image/png',
        'svg' => 'image/svg+xml',
    );
    // Return an array with file extension
    // and mime_type
    $file = wp_check_filetype($input, $mimes);
    // If $input has a valid mime_type,
    // return it; otherwise, return
    // the default.
    return ($file['ext'] ? $input : false);
}

function ciestra_sanitize_text($txt){
    return wp_kses_post($txt);
}

function ciestra_generate_customizer_css(){

    $css = '';

    $color = get_theme_mod('ciestra_first_color', CIESTRA_FIRST_COLOR);
    if( $color !== CIESTRA_FIRST_COLOR ){

        $css .= '
            blockquote:before,
            .navigation.pagination .page-numbers.prev:hover:after, 
            .navigation.pagination .page-numbers.next:hover:after,
            .testimonials-wrapper .entry-content:before,
            .has-primary-background-color
            {
                background-color: '.$color.';
            }
            .button,
            button,
            input[type="button"],
            input[type="reset"],
            input[type="submit"],
            a.more-link:after,
            .main-navigation ul ul a:before,
            .navigation.pagination .page-numbers:after,
            .wp-block-file .wp-block-file__button,
            .wp-block-button__link  
            {
                background: '.$color.';
            }
            a.more-link,
            a.more-link:focus, 
            a.more-link:active,
            .theme-social-menu li a:hover,
            .main-navigation ul ul .current_page_item > a .menu-text,
            .main-navigation ul ul .current-menu-item > a .menu-text,
            .main-navigation ul ul .current_page_ancestor > a .menu-text,
            .main-navigation ul ul .current-menu-ancestor > a .menu-text,
            .main-navigation a:hover,
            .main-navigation .current_page_item > a,
            .main-navigation .current-menu-item > a,
            .main-navigation .current_page_ancestor > a,
            .main-navigation .current-menu-ancestor > a,
            .dropdown-toggle:hover, .dropdown-toggle:focus,
            .navigation.post-navigation .nav-links .nav-previous a:hover .post-title, 
            .navigation.post-navigation .nav-links .nav-next a:hover .post-title,
            .search-form .search-submit:hover,
            .entry-meta > span.featured,
            .entry-meta > span.featured .fa,
            .comments-area .comment-list .comment .comment-meta .fn a:hover, 
            .comments-area .comment-list .comment .comment-meta .fn a:focus,
            .fp-page-header-wrapper .front-page-nav-menus .front-page-contacts-container ul li a:hover, 
            .fp-page-header-wrapper .front-page-nav-menus .front-page-contacts-container ul li a:focus,
            .fp-page-header-wrapper .front-page-nav-menus .front-page-socials li a:hover,
            .wp-block-button.is-style-outline .wp-block-button__link,
            .has-primary-color
            {
                color: '.$color.';
            }
            input[type="text"]:focus,
            input[type="email"]:focus,
            input[type="url"]:focus,
            input[type="password"]:focus,
            input[type="search"]:focus,
            input[type="number"]:focus,
            input[type="tel"]:focus,
            input[type="range"]:focus,
            input[type="date"]:focus,
            input[type="month"]:focus,
            input[type="week"]:focus,
            input[type="time"]:focus,
            input[type="datetime"]:focus,
            input[type="datetime-local"]:focus,
            input[type="color"]:focus,
            textarea:focus,
            select:focus
            {
                border-color: '.$color.';
            }
            select:active, select:focus {
                background-image: url("'.get_template_directory_uri().'/images/arrow_passive.svg");
            }
            
        ';

    }

    $color = get_theme_mod('ciestra_second_color', CIESTRA_SECOND_COLOR);
    if( $color !== CIESTRA_SECOND_COLOR ){

        $css .= '
            code, kbd, tt, var,
            a.more-link:hover:after 
            {
                background: '.$color.';
            }
            .button:hover,
            button:hover,
            input[type="button"]:hover,
            input[type="reset"]:hover,
            input[type="submit"]:hover,
            .wp-block-button.is-style-outline .wp-block-button__link:hover, 
            .wp-block-button.is-style-outline .wp-block-button__link:focus
            {
                border-color: '.$color.';
                background: '.$color.';
            }
            .button:active, .button:focus,
            button:active,
            button:focus,
            input[type="button"]:active,
            input[type="button"]:focus,
            input[type="reset"]:active,
            input[type="reset"]:focus,
            input[type="submit"]:active,
            input[type="submit"]:focus
            {
                border-color: '.$color.';
            }            
            a.more-link:hover,
            a,
            a:hover,
            a:focus,
            a:active,
            .hentry .entry-title a:hover,
            .entry-meta a:hover 
            {
                color: '.$color.';
            }
            
            .wp-block-file .wp-block-file__button:hover, .wp-block-file .wp-block-file__button:focus,
            .wp-block-button__link:hover,
            .wp-block-button__link:focus {
                border-color: '.$color.' !important;
                background: '.$color.' !important;
            }
        
        ';

    }

    $color = get_theme_mod('ciestra_third_color', CIESTRA_THIRD_COLOR);
    if( $color !== CIESTRA_THIRD_COLOR ){

        $css .= '
            .navigation.pagination .page-numbers.prev:after, 
            .navigation.pagination .page-numbers.next:after
            {
                background-color: '.$color.';
            }
            .navigation.post-navigation .nav-links .nav-previous a:hover img, 
            .navigation.post-navigation .nav-links .nav-next a:hover img {
                -webkit-box-shadow: 10px 10px 0 '.$color.'; 
                box-shadow: 10px 10px 0 '.$color.';
            }
            .navigation.post-navigation .nav-links .nav-previous img, 
            .navigation.post-navigation .nav-links .nav-next img
            {
                -webkit-box-shadow: 20px 20px 0 '.$color.'; 
                box-shadow: 20px 20px 0 '.$color.';
            }
            .widget-area .widget,
            .hentry .post-thumbnail img {
                -webkit-box-shadow: 10px 10px 0 '.$color.'; 
                box-shadow: 10px 10px 0 '.$color.';
            }            
            .fp-page-header-wrapper .fp-entry-header-wrapper:before 
            {
                background: '.$color.';
            }
            @media (max-width: 991px){
                .front-page-widget-area{
                    background: '.$color.';
                }
            }
            .front-page-widget-area
            @media (min-width: 768px) {
                .hentry .post-thumbnail img {
                    -webkit-box-shadow: 20px 20px 0 '.$color.';
                    box-shadow: 20px 20px 0 '.$color.';
                }
            }
            
            @media (min-width: 992px) {
                .hentry .post-thumbnail img {
                    -webkit-box-shadow: 40px 40px 0 '.$color.';
                    box-shadow: 40px 40px 0 '.$color.';
                }
            }
            
            @media (min-width: 992px) {
                .hentry a.post-thumbnail:hover img {
                    -webkit-box-shadow: 20px 20px 0 '.$color.';
                    box-shadow: 20px 20px 0 '.$color.';
                }
            }
            
        ';

    }

    $default_image= esc_url_raw(get_template_directory_uri().'/images/wave_line.svg');
    $image = get_theme_mod('ciestra_widget_image',$default_image);

    if($image != $default_image){
        if($image == false){
            $css .= '
                .widget .widget-title::after {
                    display: none;
                }
            ';
        }else{
            $css .= '
                .widget .widget-title::after {
                    background: url("'.$image.'") center no-repeat;
                    background-size: contain;
                }
            ';
        }
    }


    if($css == ''){
        return false;
    }else{
        return $css;
    }

}


function ciestra_generate_elementor_customizer_css(){

    $css = '';

    $color = get_theme_mod('ciestra_first_color', CIESTRA_FIRST_COLOR);
    if( $color !== CIESTRA_FIRST_COLOR ){

        $css .= '
            .slick-prev:hover:after,
            .slick-next:hover:after,
            .entry-content .elementor-slick-slider .slick-prev:hover:after,
            .entry-content .elementor-slick-slider .slick-next:hover:after
            {
                background-color: '.$color.';
            }
            .elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-description-wrapper .mphb-view-details-button,
            .slick-prev:after,
            .slick-next:after,
            .entry-content .elementor-slick-slider .slick-prev:after,
            .entry-content .elementor-slick-slider .slick-next:after
            {
                background: '.$color.';
            }
            .slick-dots .slick-active button:after, .slick-dots li:hover button:after {
                background: '.$color.';
                -webkit-box-shadow: 0 0 0 4px '.$color.'40;
                box-shadow: 0 0 0 4px '.$color.'40;
            }
            
            .elementor-widget-button .elementor-button,
            .elementor-widget-button.elementor-button-info .elementor-button:hover 
            {
                background-color: '.$color.' !important;
            }
            
        ';

    }

    $color = get_theme_mod('ciestra_second_color', CIESTRA_SECOND_COLOR);
    if( $color !== CIESTRA_SECOND_COLOR ){

        $css .= '
            .elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-description-wrapper .mphb-view-details-button:hover
            {
                background: '.$color.';
            }
            .elementor-widget-button .elementor-button:hover,
            .elementor-widget-button.elementor-button-info .elementor-button
            {
                background-color: '.$color.' !important;
            }
        
        ';

    }

    $color = get_theme_mod('ciestra_third_color', CIESTRA_THIRD_COLOR);
    if( $color !== CIESTRA_THIRD_COLOR ){

        $css .= '
            .slick-prev:after,
            .slick-next:after,
            .entry-content .elementor-slick-slider .slick-prev:after,
            .entry-content .elementor-slick-slider .slick-next:after
            {
                background-color: '.$color.';
            }
            .elementor-widget .mphb_sc_rooms-wrapper .type-mphb_room_type .room-images-wrapper > *:after,
            .amenities-slider .type-cptp-amenity .post-thumbnail:after,
            .recent-posts-widget .post .thumbnail-wrapper .post-thumbnail:after 
            {
                background: '.$color.';
            }            
            
        ';

    }


    if($css == ''){
        return false;
    }else{
        return $css;
    }

}

function ciestra_generate_mphb_customizer_styles(){

    $css = '';

    $color = get_theme_mod('ciestra_first_color', CIESTRA_FIRST_COLOR);
    if( $color !== CIESTRA_FIRST_COLOR ){

        $css .= '
            .mphb-calendar .datepick-ctrl a,
            .datepick-popup .datepick-ctrl a,
            .datepick-popup .mphb-datepick-popup .datepick-month td .datepick-today,
            .mphb-view-details-button,
            .mphb-service-title > a:hover 
            {
                color: '.$color.';
            }
            .mphb-view-details-button:after
            {
                background: '.$color.';
            }            
            .mphb-calendar.mphb-datepick .datepick-month td .datepick-selected,
            .datepick-popup .mphb-datepick-popup .datepick-month td .datepick-selected,
            .datepick-popup .mphb-datepick-popup .datepick-month td a.datepick-highlight,
            .mphb-calendar.mphb-datepick .datepick-month td .mphb-booked-date,
            body .mphb-flexslider.flexslider ul.flex-direction-nav a:hover,
            body .flexslider ul.flex-direction-nav a:hover 
            {
                background-color: '.$color.';
            }
            body .mphb-flexslider.flexslider ol.flex-control-nav li a.flex-active, body .mphb-flexslider.flexslider ol.flex-control-nav li a:hover,
            body .flexslider ol.flex-control-nav li a.flex-active,
            body .flexslider ol.flex-control-nav li a:hover {
                background: '.$color.' !important;
                -webkit-box-shadow: 0 0 0 4px '.$color.'80;
                box-shadow: 0 0 0 4px '.$color.'80;
            }
            input[type="text"].mphb-datepick.is-datepick:focus, 
            input[type="text"].mphb-datepick.is-datepick:active 
            {
                background-image: url("'.get_template_directory_uri().'/images/calendar_passive.svg");
            }
            
        ';

    }

    $color = get_theme_mod('ciestra_second_color', CIESTRA_SECOND_COLOR);
    if( $color !== CIESTRA_SECOND_COLOR ){

        $css .= '
            .mphb-view-details-button:hover:after, .mphb-view-details-button:focus:after
            {
                background: '.$color.';
            }
            .mphb-view-details-button:hover, .mphb-view-details-button:focus
            {
                color: '.$color.';
            }
        
        ';

    }

    $color = get_theme_mod('ciestra_third_color', CIESTRA_THIRD_COLOR);
    if( $color !== CIESTRA_THIRD_COLOR ){

        $css .= '
            @media (min-width: 992px) {
                .single-room-type .mphb-reservation-form {
                    -webkit-box-shadow: 10px 10px 0 '.$color.';
                    box-shadow: 10px 10px 0 '.$color.';
                }
            }
            .room-images-wrapper > * {
                -webkit-box-shadow: 40px 40px 0 '.$color.';
                box-shadow: 40px 40px 0 '.$color.';
            }
        
            body .mphb-flexslider.flexslider ul.flex-direction-nav a,
            body .flexslider ul.flex-direction-nav a 
            {
                background-color: '.$color.';
            }        
            
        ';

    }

    if($css == ''){
        return false;
    }else{
        return $css;
    }

}

function ciestra_customizer_css(){

    if(ciestra_generate_customizer_css() != false){
        wp_add_inline_style('ciestra-style', ciestra_generate_customizer_css());
    }

    if(ciestra_generate_elementor_customizer_css() != false){
        wp_add_inline_style('ciestra-elementor-widgets', ciestra_generate_elementor_customizer_css());
    }

}
add_action('wp_enqueue_scripts', 'ciestra_customizer_css');

function ciestra_generate_customizer_editor_css(){

    $css = '';

    $color = get_theme_mod('ciestra_first_color', CIESTRA_FIRST_COLOR);
    if( $color !== CIESTRA_FIRST_COLOR ){

        $css .= '
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block blockquote:before,
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .has-primary-background-color
            {
                background-color: '.$color.';
            }            
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-file .wp-block-file__button,
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button__link
            {
                background: '.$color.';
            }
            {
                background: '.$color.';
                -webkit-box-shadow: 0 0 0 4px '.$color.'40;
                box-shadow: 0 0 0 4px '.$color.'40;
            }
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button.is-style-outline .wp-block-button__link,
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .has-primary-color
            {
                color: '.$color.';
            }
            
        ';

    }

    $color = get_theme_mod('ciestra_second_color', CIESTRA_SECOND_COLOR);
    if( $color !== CIESTRA_SECOND_COLOR ){

        $css .= '
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-file .wp-block-file__button:hover, .wp-block-file .wp-block-file__button:focus,
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button__link:hover,
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button__link:focus
            {
                border-color: '.$color.' !important;
                background: '.$color.' !important;
            }
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button.is-style-outline .wp-block-button__link:hover, 
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block .wp-block-button.is-style-outline .wp-block-button__link:focus
            {
                border-color: '.$color.';
                background: '.$color.';
            }
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block a:hover, 
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block a:focus, 
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block a:active, 
            .editor-styles-wrapper .editor-block-list__layout .editor-block-list__block a
            {
                color: '.$color.';
            }
        
        ';

    }

    if($css == ''){
        return false;
    }else{
        return $css;
    }

}

function ciestra_customizer_editor_css(){

    if(ciestra_generate_customizer_editor_css() != false){

        wp_enqueue_style('ciestra-editor-style', get_template_directory_uri() . '/css/customizer-editor.css', false, ciestra_get_theme_version(), 'all');
        wp_add_inline_style('ciestra-editor-style', ciestra_generate_customizer_editor_css());

    }

}
add_action('enqueue_block_editor_assets', 'ciestra_customizer_editor_css');