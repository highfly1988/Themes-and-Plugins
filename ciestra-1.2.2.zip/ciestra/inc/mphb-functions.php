<?php

function ciestra_mphb_scripts(){

    wp_enqueue_style('ciestra-mphb-style', get_template_directory_uri() . '/css/motopress-hotel-booking.css', array(), ciestra_get_theme_version());

    if(ciestra_generate_mphb_customizer_styles() != false){
        wp_add_inline_style('ciestra-mphb-style', ciestra_generate_mphb_customizer_styles());
    }

}

add_action( 'wp_enqueue_scripts', 'ciestra_mphb_scripts' );


add_filter('mphb_loop_room_type_gallery_main_slider_flexslider_options', 'ciestra_mphb_room_gallery_slider_settings');
function ciestra_mphb_room_gallery_slider_settings($atts){
    $atts['controlNav'] = true;
    return $atts;
}

add_filter('mphb_loop_room_type_gallery_use_nav_slider', 'ciestra_remove_mphb_nav_gallery');
function ciestra_remove_mphb_nav_gallery(){
    return false;
}

add_filter( 'mphb_loop_room_type_gallery_main_slider_image_size', function ($size){
    return 'ciestra-square';
});

add_filter( 'mphb_loop_room_type_thumbnail_size', function ($size){
    return 'ciestra-square';
});

add_filter( 'mphb_single_room_type_gallery_image_size', function ($size){
    return 'ciestra-room-gallery';
});

add_filter( 'mphb_loop_room_type_gallery_nav_slider_image_size', function ($size){
    return 'ciestra-room-gallery';
});
add_action('mphb_sc_rooms_render_gallery', 'ciestra_mphb_loop_room_images_wrapper_open', 5);
add_action('mphb_sc_rooms_render_image', 'ciestra_mphb_loop_room_images_wrapper_open', 5);
add_action('mphb_sc_search_results_render_gallery', 'ciestra_mphb_loop_room_images_wrapper_open', 5);
add_action('mphb_sc_search_results_render_image', 'ciestra_mphb_loop_room_images_wrapper_open', 5);
function ciestra_mphb_loop_room_images_wrapper_open(){
    ?>
    <div class="room-images-wrapper">
    <?php
}

add_action('mphb_sc_rooms_render_gallery', 'ciestra_mphb_loop_room_images_wrapper_close', 15);
add_action('mphb_sc_rooms_render_image', 'ciestra_mphb_loop_room_images_wrapper_close', 15);
add_action('mphb_sc_search_results_render_gallery', 'ciestra_mphb_loop_room_images_wrapper_close', 15);
add_action('mphb_sc_search_results_render_image', 'ciestra_mphb_loop_room_images_wrapper_close', 15);
function ciestra_mphb_loop_room_images_wrapper_close(){
    ?>
    </div>
    <?php
}

add_action('mphb_sc_rooms_render_gallery', 'ciestra_mphb_loop_room_info_wrapper_open', 15);
add_action('mphb_sc_rooms_render_image', 'ciestra_mphb_loop_room_info_wrapper_open', 15);
add_action('mphb_sc_search_results_render_gallery', 'ciestra_mphb_loop_room_info_wrapper_open', 15);
add_action('mphb_sc_search_results_render_image', 'ciestra_mphb_loop_room_info_wrapper_open', 15);
function ciestra_mphb_loop_room_info_wrapper_open(){
    ?>
    <div class="room-description-wrapper">
    <?php
}

add_action('mphb_sc_rooms_item_bottom', 'ciestra_mphb_loop_room_info_wrapper_close');
add_action('mphb_sc_search_results_room_bottom', 'ciestra_mphb_loop_room_info_wrapper_close');
function ciestra_mphb_loop_room_info_wrapper_close(){
    ?>
    </div>
    <?php
}

add_filter( 'mphb_single_room_type_gallery_columns', 'ciestra_single_room_type_gallery_columns' );
function ciestra_single_room_type_gallery_columns(){
    return 3;
}

add_action('mphb_render_single_room_type_before_reservation_form', 'ciestra_mphb_render_single_room_type_before_reservation_form', 5);
function ciestra_mphb_render_single_room_type_before_reservation_form(){
    ?>
    <div id="ciestra-mphb-reservation-form" class="mphb-reservation-form">
    <?php
}

add_action('mphb_render_single_room_type_after_reservation_form', 'ciestra_mphb_render_single_room_type_after_reservation_form', 5);
function ciestra_mphb_render_single_room_type_after_reservation_form(){
    ?>
    </div>
    <?php
}

remove_action('mphb_sc_services_service_details', array('\MPHB\Views\LoopServiceView', 'renderPrice'), 40);
remove_action( 'mphb_sc_services_service_details', array( '\MPHB\Views\LoopServiceView', 'renderExcerpt' ), 30 );

add_action( 'mphb_sc_services_service_details', 'ciestra_replace_service_excerpt', 30 );
function ciestra_replace_service_excerpt(){
    the_content(sprintf(
        wp_kses(
        /* translators: %s: Name of current post. Only visible to screen readers */
            __( 'Read more<span class="screen-reader-text"> "%s"</span>', 'ciestra' ),
            array(
                'span' => array(
                    'class' => array(),
                ),
            )
        ),
        get_the_title()
    ) );
}

add_action( 'mphb_render_loop_service_before_featured_image', 'ciestra_loop_service_featured_image_link_open', 15 );
function ciestra_loop_service_featured_image_link_open(){
    ?>
    <a href="<?php the_permalink(); ?>" class="post-thumbnail">
    <?php
}
add_action( 'mphb_render_loop_service_after_featured_image', 'ciestra_loop_service_featured_image_link_close', 5 );
function ciestra_loop_service_featured_image_link_close(){
    ?>
    </a>
    <?php
}

add_action('mphb_render_single_room_type_metas', 'ciestra_before_single_room_type_reservation_form', 45);
function ciestra_before_single_room_type_reservation_form(){
    ?>
    <div class="sticky-reservation-form">
    <?php
}

add_action('mphb_render_single_room_type_metas', 'ciestra_after_single_room_type_reservation_form', 55);
function ciestra_after_single_room_type_reservation_form(){
    ?>
    </div>
    <?php
}

function ciestra_mphbr_list_comments_args_filter($args){

    $args['callback'] = 'ciestra_custom_comment';
    $args['avatar_size'] = 60;

    return $args;

}
add_filter('mphbr_list_comments_args', 'ciestra_mphbr_list_comments_args_filter');