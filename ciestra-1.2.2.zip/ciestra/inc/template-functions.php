<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package ciestra
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function ciestra_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'ciestra_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function ciestra_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}
add_action( 'wp_head', 'ciestra_pingback_header' );

function is_blog_with_sidebar(){
    if( 'post' != get_post_type()){
        return true;
    }

    if(get_theme_mod('ciestra_blog_layout', 'no-sidebar') === 'with-sidebar'){
        return true;
    }else{
        return false;
    }
}

add_filter('ciestra_blog_class', 'ciestra_blog_class_filter');
function ciestra_blog_class_filter($classes){

    if(!is_blog_with_sidebar()){
        $classes[] = 'boxed';
    }

    return $classes;
}


function ciestra_the_blog_class(){
    $classes = apply_filters('ciestra_blog_class', array());
    echo esc_attr(implode(' ', $classes));
}

function ciestra_custom_comment($comment, $args, $depth){
    ?>
        <li id="comment-<?php comment_ID(); ?>" <?php comment_class(empty( $args['has_children'] ) ? '' :'parent') ?>>
			<article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
				<footer class="comment-meta">
					<div class="comment-author vcard">
						<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
						<?php
							/* translators: %s: comment author link */
							printf( __( '%s <span class="says">says:</span>' , 'ciestra' ),
								sprintf( '<b class="fn">%s</b>', get_comment_author_link( $comment ) )
							);
						?>
					</div><!-- .comment-author -->

					<div class="comment-metadata">
						<a href="<?php echo esc_url( get_comment_link( $comment, $args ) ); ?>">
							<time datetime="<?php comment_time( 'c' ); ?>">
								<?php
									/* translators: 1: comment date, 2: comment time */
									printf( __( '%1$s at %2$s', 'ciestra' ), get_comment_date( '', $comment ), get_comment_time() );
								?>
							</time>
						</a>
						<?php edit_comment_link( esc_html__( 'Edit', 'ciestra' ), '<span class="edit-link">', '</span>' ); ?>
					</div><!-- .comment-metadata -->

					<?php if ( '0' == $comment->comment_approved ) : ?>
					<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'ciestra' ); ?></p>
					<?php endif; ?>
				</footer><!-- .comment-meta -->

                <div class="comment-body-wrapper">
                    <div class="comment-content">
                        <?php comment_text(); ?>
                    </div><!-- .comment-content -->

                    <?php
                    comment_reply_link( array_merge( $args, array(
                        'add_below' => 'div-comment',
                        'depth'     => $depth,
                        'max_depth' => $args['max_depth'],
                        'before'    => '<div class="reply">',
                        'after'     => '</div>'
                    ) ) );
                    ?>
                </div>
			</article><!-- .comment-body -->
			<?php
}

