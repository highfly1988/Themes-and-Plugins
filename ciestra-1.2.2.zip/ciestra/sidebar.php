<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ciestra
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}

if( ( is_home() || (is_archive() && 'post' === get_post_type()) ) && !is_blog_with_sidebar() ){
    return;
}

?>

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
