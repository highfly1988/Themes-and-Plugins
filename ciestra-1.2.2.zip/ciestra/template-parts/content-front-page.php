<?php
/**
 *
 * Template part for displaying page content in template-front-page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ciestra
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <div class="fp-page-header-wrapper">
        <div class="front-page-nav-menus">
        <?php
        if(has_nav_menu('menu-5')){
            wp_nav_menu(array(
               'theme_location' => 'menu-5',
                'menu_id'        => 'front-page-contacts',
                'menu_class'     => 'front-page-contacts',
                'container_class' => 'front-page-contacts-container',
                'link_before'    => '<span class="menu-text">',
                'link_after'     => '</span>'

            ));
        }

        if(has_nav_menu('menu-4')){
            wp_nav_menu(array(
                'theme_location' => 'menu-4',
                'menu_id'        => 'front-page-socials',
                'menu_class'     => 'front-page-socials theme-social-menu',
                'container_class' => 'front-page-socials-container',
                'link_before'    => '<span class="menu-text">',
                'link_after'     => '</span>'
            ));
        }
        ?>
        </div>
        <div class="fp-entry-header-wrapper">
            <div class="fp-entry-header">
                <header class="entry-header">
                    <?php
                        echo '<div class="page-subtitle">';
                        the_excerpt();
                        echo '</div>';
                        the_title( '<h1 class="entry-title">', '</h1>' );
                    ?>
                </header><!-- .entry-header -->

                <?php
                    ciestra_post_thumbnail();
                ?>
            </div>
            <?php
                get_sidebar('front-page');
            ?>

        </div>


    </div>

    <div class="entry-content">
        <?php
        the_content();
        ?>
    </div><!-- .entry-content -->

    <?php if ( get_edit_post_link() ) : ?>
        <footer class="entry-footer">
            <?php
            edit_post_link(
                sprintf(
                    wp_kses(
                    /* translators: %s: Name of current post. Only visible to screen readers */
                        __( 'Edit <span class="screen-reader-text">%s</span>', 'ciestra' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    ),
                    get_the_title()
                ),
                '<span class="edit-link">',
                '</span>'
            );
            ?>
        </footer><!-- .entry-footer -->
    <?php endif; ?>
</article><!-- #post-<?php the_ID(); ?> -->
