<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package ciestra
 */

get_header();
?>

	<div id="primary" class="content-area boxed">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
                    <span class="error-code"><?php echo esc_html__('404', 'ciestra')?></span>
					<h1 class="page-title"><?php esc_html_e( 'Page Not Found', 'ciestra' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><?php esc_html_e( 'Unfortunately the page you were looking for could not be found.', 'ciestra' ); ?></p>

					<?php
					get_search_form();
					?>
                    <a href="<?php echo home_url();?>" class="button"><?php echo esc_html__('Back to Home', 'ciestra');?></a>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
