=== Ciestra ===
Contributors: MotoPress
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 4.6
Tested up to: 5.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Rank your website higher in the local competition with Ciestra - the best Resort WordPress Theme. It offers more than you expect: absolutely intuitive visual property and website editing for non-techs, the top-rated WordPress booking system built in, flawless mobile experience for bookings, easy SEO tools and even auto sync to external OTAs.

== Installation ==
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now. Click Activate.
3. Install required plugins.
4. If you create a new website, you may import sample data in Appearance > Import Demo Data.

== Copyright ==
Ciestra WordPress Theme, Copyright (C) 2019, MotoPress
Ciestra is distributed under the terms of the GNU GPL.

== Changelog ==

= 1.2.2, Apr 15 2019 =
* Hotel Booking plugin updated to version 3.3.0.
  * Improved compatibility with WPML plugin.
  * Fixed the bug appeared while calculating the subtotal amount in Price Breakdown when a discount code is applied.
  * Added Hotel Booking Extensions page. Developers may opt-out of displaying this page via "mphb_show_extension_links" filter.
  * Booking Calendar improvements:
    * Tooltip extended with the customer data: full name, email, phone, guests number, imported bookings info.
    * Added a popup option to display the detailed booking information.
  * Bookings table improvements:
    * Added a column with booked accommodations.
    * Added the ability to filter bookings by accommodation type.
    * Added the ability to search bookings by First Name, Last Name, Check-in Date, Check-out Date, Phone, Price, etc.
  * Added a Service option that enables to specify the number of times guest would like to order this service.

= 1.2.1, Feb 13 2019 =
* Minor bugfixes and improvements.

= 1.2.0, Feb 12 2019 =
* Hotel Booking plugin updated to version 3.1.0.
  * Added new blocks to Gutenberg.
  * Added option to switch to the new block editor for Accommodation Types and Services in plugin settings.
* Added option to set the Price Breakdown to be unfolded by default.
* Improved design of Accommodation titles in Price Breakdown for better user experience.
* Added styles for Hotel Booking Reviews addon.
* Added the ability to change copyright text in footer.
* Added the ability to change primary theme colors.

= 1.1.0, Jan 14 2019 =
* Added theme support for WordPress 5.0 (Gutenberg).
* Hotel Booking plugin updated to version 3.0.3.

= 1.0.0, Sep 18 2018 =
* Hotel Booking plugin updated to version 3.0.0:
  * Introducing attributes. By using the attributes you are able to define extra accommodation data such as location and type and use these attributes in the search availability form as advanced search filters.
  * Improved the way to display the booking rules in the availability calendar.
  * Added the new payment method to pay on arrival.
  * Added the ability to create fixed amount coupon codes.
  * Added the availability to send multiple emails to notify the administrator and other staff about new booking.
  * Fixed the bug appeared in the Braintree payment method if a few plugins for making payment are set up.
  * Added the ability to set the default country on the checkout page.

= 0.1.0, Aug 20 2018 =
* Initial release.

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)