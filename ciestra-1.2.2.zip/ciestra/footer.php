<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package ciestra
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
        <div class="wrapper">
            <?php

            get_sidebar('footer');

            if(has_nav_menu('menu-3')){
                wp_nav_menu(array(
                    'theme_location' => 'menu-3',
                    'menu_id'        => 'socials-menu',
                    'menu_class'     => 'theme-social-menu',
                    'container_class'     => 'socials-menu-container',
                    'link_before'    => '<span class="menu-text">',
                    'link_after'     => '</span>',
                    'depth'          => 1
                ));
            }
            if(has_nav_menu('menu-2')){
                wp_nav_menu(array(
                    'theme_location' => 'menu-2',
                    'menu_id'        => 'footer-menu',
                    'menu_class'     => 'footer-menu',
                    'link_before'    => '<span class="menu-text">',
                    'link_after'     => '</span>',
                    'depth'          => 1
                ));
            }

            if(boolval(get_theme_mod('ciestra_show_footer_text', true))):
            ?>
                <div class="site-info">
                    <?php
                        $dateObj = new DateTime;
                        $year    = $dateObj->format( "Y" );
                        $site_info = sprintf( esc_html__( '%2$s &copy; %1$s All Rights Reserved.', 'ciestra' ), $year, get_bloginfo( 'name' ) );
                        printf(
                            get_theme_mod( 'ciestra_footer_text',
                                apply_filters('ciestra_site_info', $site_info)
                            ),
                            $year,
                            get_bloginfo( 'name' )
                        );
                    ?>
                </div><!-- .site-info -->
            <?php
            endif;
            ?>
        </div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
