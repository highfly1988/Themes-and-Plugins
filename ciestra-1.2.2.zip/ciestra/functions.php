<?php
/**
 * ciestra functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package ciestra
 */

if ( ! function_exists( 'ciestra_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function ciestra_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on ciestra, use a find and replace
		 * to change 'ciestra' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ciestra', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );


		set_post_thumbnail_size( 891);

		add_image_size('ciestra-thumbnail-cropped', 891, 636, true);
		add_image_size('ciestra-square', 891, 891, true);
		add_image_size('ciestra-room-gallery', 235, 167, true);

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'ciestra' ),
			'menu-2' => esc_html__( 'Footer', 'ciestra' ),
			'menu-3' => esc_html__( 'Footer (Socials)', 'ciestra' ),
			'menu-4' => esc_html__( 'Front Page Socials', 'ciestra' ),
			'menu-5' => esc_html__( 'Front Page Contacts', 'ciestra' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );


		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

        // Add page support excerpt.
        add_post_type_support( 'page', 'excerpt' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 30,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
            'header-text' => array( 'site-title' ),
		) );

		add_theme_support('cptp-testimonial');
		add_theme_support('cptp-amenity');

        /*
        * New block editor support
        */

        add_theme_support('editor-styles');

        add_editor_style( array( 'css/editor-style.css', ciestra_fonts_url() ) );

        add_theme_support( 'responsive-embeds' );

        add_theme_support( 'align-wide' );

        add_theme_support( 'editor-color-palette', array(
            array(
                'name' => __( 'Primary', 'ciestra' ),
                'slug' => 'primary',
                'color' => get_theme_mod('ciestra_first_color', CIESTRA_FIRST_COLOR),
            ),
            array(
                'name' => __( 'Secondary', 'ciestra' ),
                'slug' => 'secondary',
                'color' => '#4f4f4f',
            ),
            array(
                'name' => __( 'Dark green', 'ciestra' ),
                'slug' => 'dark-green',
                'color' => '#00a43e',
            ),
            array(
                'name' => __( 'Light blue', 'ciestra' ),
                'slug' => 'light-blue',
                'color' => '#edf6fc',
            ),
            array(
                'name' => __( 'Light gray', 'ciestra' ),
                'slug' => 'light-gray',
                'color' => '#f2f2f2',
            ),
            array(
                'name' => __( 'Beige', 'ciestra' ),
                'slug' => 'beige',
                'color' => '#f8f8f8',
            ),
            array(
                'name' => __( 'Black', 'ciestra' ),
                'slug' => 'black',
                'color' => '#37383c',
            ),
            array(
                'name' => __( 'White', 'ciestra' ),
                'slug' => 'white',
                'color' => '#fff',
            ),
        ) );
	}
endif;
add_action( 'after_setup_theme', 'ciestra_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 */
if ( ! isset( $content_width ) ) {
    $content_width = apply_filters( 'ciestra_content_width', 746 );
}
function ciestra_adjust_content_width() {
    global $content_width;

    if(is_page_template('template-page-wide.php') || is_page_template('template-front-page.php')){
        $content_width = 1130;
    }

}
add_action( 'template_redirect', 'ciestra_adjust_content_width');


function ciestra_get_theme_version() {
    $theme_info = wp_get_theme( get_template() );

    return $theme_info->get( 'Version' );
}

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ciestra_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'ciestra' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'ciestra' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Sidebar', 'ciestra' ),
        'id'            => 'sidebar-2',
        'description'   => esc_html__( 'Add widgets here.', 'ciestra' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Front Page Top Sidebar', 'ciestra' ),
        'id'            => 'sidebar-3',
        'description'   => esc_html__( 'Add widgets here.', 'ciestra' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'ciestra_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function ciestra_scripts() {

    wp_enqueue_style( 'ciestra-fonts', ciestra_fonts_url(), array(), null );

	wp_enqueue_style( 'ciestra-style', get_stylesheet_uri(), array(), ciestra_get_theme_version() );

    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.7.0');

	wp_enqueue_script('ciestra-scripts', get_template_directory_uri() . '/js/functions.js', array('jquery'), ciestra_get_theme_version(), true );
	wp_enqueue_script( 'ciestra-navigation', get_template_directory_uri() . '/js/navigation.js', array(), ciestra_get_theme_version(), true );

	wp_enqueue_script( 'ciestra-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), ciestra_get_theme_version(), true );

	if(defined('ELEMENTOR_VERSION')){
        wp_enqueue_style('ciestra-elementor-widgets', get_template_directory_uri() . '/css/elementor-widgets.css', array(), ciestra_get_theme_version());
    }

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ciestra_scripts' );

define('CIESTRA_FIRST_COLOR', '#00ca4c');
define('CIESTRA_SECOND_COLOR', '#00a43e');
define('CIESTRA_THIRD_COLOR', '#edf6fc');

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load MP Hotel Booking Compatibility file.
 */

if( class_exists('HotelBookingPlugin') ){
    require get_template_directory() . '/inc/mphb-functions.php';
}

/**
 * Load TGM
 */

require get_template_directory() . '/inc/tgm-init.php';

/**
 * Load demo-import
 */

require get_template_directory() . '/inc/demo-import.php';

if ( ! function_exists( 'ciestra_fonts_url' ) ) :
    /**
     * Register Google fonts for Ciestra.
     *
     * Create your own ciestra_fonts_url() function to override in a child theme.
     *
     * @since Ciestra 1.0.0
     *
     * @return string Google fonts URL for the theme.
     */
    function ciestra_fonts_url() {
        $fonts_url     = '';
        $font_families = array();
        /**
         * Translators: If there are characters in your language that are not
         * supported by Roboto, translate this to 'off'. Do not translate
         * into your own language.
         */
        $roboto = esc_html_x( 'on', 'Roboto font: on or off', 'ciestra' );
        if ( 'off' !== $roboto) {
            $font_families[] = 'Roboto:300,400,400i,500,700,700i,900';
        }

        $query_args    = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext,cyrillic' ),
        );
        if ( $font_families ) {
            $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
        }

        return esc_url_raw( $fonts_url );
    }
endif;


/**
 * Filters the title of the default page template displayed in the drop-down.
 */
function ciestra_default_page_template_title() {
    return esc_html__( 'Without Sidebar', 'ciestra' );
}

add_filter( 'default_page_template_title', 'ciestra_default_page_template_title' );

/**
 * Modifies tag cloud widget arguments to have all tags in the widget same font size.
 *
 */
function ciestra_widget_tag_cloud_args( $args ) {
    $args['largest']  = 0.75;
    $args['smallest'] = 0.75;
    $args['unit']     = 'rem';

    return $args;
}
add_filter( 'widget_tag_cloud_args', 'ciestra_widget_tag_cloud_args' );


function ciestra_remove_post_type_support(){
    remove_post_type_support( 'cptp-testimonial', 'thumbnail' );
    remove_post_type_support( 'cptp-testimonial', 'page-attributes' );
}
add_action('init', 'ciestra_remove_post_type_support');