<?php
/**
 * Email sender object (From, Reply-To).
 *
 * @since 5.0.0
 */

class BP_Email_Sender extends BP_Email_Participant {}
