<?php
/**
 * Index file
 *
 * @package Astra
 * @since Astra 1.6.10
 */

/* Silence is golden, and we agree. */
