jQuery(document).ready(function(){
	jQuery('.wb_ps-up-pro-link').parent().attr('target','_blank');
});