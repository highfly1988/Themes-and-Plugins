#######################################################

 Magic 360™
 WordPress module version v6.8.39 [v1.6.91:v4.6.12]

 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2020 Magic Toolbox

#######################################################

INSTALLATION:

1. Upload the zip file via your WordPress admin area.

2. Activate Magic 360 plugin in the Plugins menu of WordPress.

3. Magic 360 demo version is ready to use!

4. To upgrade your version of Magic 360 (which removes the "Please upgrade" text), buy Magic 360 and overwrite the wp-content/plugins/magic360/magic360/core/magic360.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magic360/

Or apply for a free license if your site is non-commercial:

http://www.magictoolbox.com/license/#free

