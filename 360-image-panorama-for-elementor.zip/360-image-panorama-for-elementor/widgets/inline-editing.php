<?php
namespace ElementorMosaicGallery\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class Inline_Editing extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'inline-editing-example';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Inline Editing', 'elementor-mosaic-gallery' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-pencil';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.1.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'themeofwp-elements' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'elementor-mosaic-gallery' ),
			]
		);

		$this->add_control(
			'mosaic_gallery',
			[
				'label' => __( 'Add Images', 'elementor-mosaic-gallery' ),
				'type' => Controls_Manager::GALLERY,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'mosaic_gallery', 'none' );

		echo'<!-- navigation mosaicholder --> <div class="mosaicholder"></div>';
		echo'<ul id="mosaicContainer">';
		foreach ( $settings['mosaic_gallery'] as $image ) {
			echo '
				<li class="mosaicgallery-item">
					<a href="' . $image['url'] . '" class="mosaic-gallery-link">
						<img width="150" height="150" src="' . $image['url'] . '">
					</a>
				</li>
				';
		}
		?>
		<h2 <?php echo $this->get_render_attribute_string( 'mosaic_gallery' ); ?>>
			<?php echo $settings['mosaic_gallery']; ?></h2>
		<?php

		echo'</ul>';
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.1.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'mosaic_gallery', 'none' );
		#>
		<h2 {{{ view.getRenderAttributeString( 'title' ) }}}>{{{ settings.mosaic_gallery }}}</h2>
		<?php
	}
}
