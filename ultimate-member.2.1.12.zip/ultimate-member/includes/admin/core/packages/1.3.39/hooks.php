<?php

return array(
	'usermetaquery1339' => 'usermetaquery1339',
);