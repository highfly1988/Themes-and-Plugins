<?php

/*
* Title                   : Pinpoint Booking System WordPress Plugin (PRO)
* Version                 : 2.3.8
* File                    : addons/clickatell/dopbsp-clickatell.php
* File Version            : 1.0
* Created / Last Modified : 10 November 2016
* Author                  : Dot on Paper
* Copyright               : © 2012 Dot on Paper
* Website                 : http://www.dotonpaper.net
* Description             : Clickatell PHP class.
*/

    if (!class_exists('DOPBSPClickatell')){
        class DOPBSPClickatell{
            private $SMSAPI_user     = '';
            private $SMSAPI_password = '';
            private $SMSAPI_id       = '';
            private $SMSAPI_from     = '';
            
            /*
             * Constructor
             */
            function __construct($clickatell_api){
                $this->SMSAPI_user = $clickatell_api->clickatell_username;
                $this->SMSAPI_password = $clickatell_api->clickatell_password;
                $this->SMSAPI_id = $clickatell_api->clickatell_api_id;
                $this->SMSAPI_from = $clickatell_api->clickatell_from;
            }

        /*
         * Send SMS message.
         * 
         * @param phone_prefix (string): phone country prefix
         * @param phone_number (string): phone number
         * @param text (string): SMS text
         * 
         * @return boolean value if SMS was sent ot not
         */
        function send($phone,
                      $text){
                $api_link = array();

                array_push($api_link, 'http://api.clickatell.com/http/sendmsg?');
                array_push($api_link, 'user='.$this->SMSAPI_user);
                array_push($api_link, '&password='.$this->SMSAPI_password);
                array_push($api_link, '&api_id='.$this->SMSAPI_id);
                array_push($api_link, '&from='.$this->SMSAPI_from);
                array_push($api_link, '&to='.$phone);
                array_push($api_link, '&text='.$text);

                $message = file_get_contents(implode('', $api_link));
                
                if ($message == 'ERR: 114, Cannot route message' 
                    || $message == 'ERR: 105, Invalid Destination Address'){
                    return false;
                }
                else{
                    return true;
                }
            }
        }
    }