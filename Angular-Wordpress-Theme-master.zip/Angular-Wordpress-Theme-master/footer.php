		</div><!-- END CONTAINER -->  
		</div><!-- END FLUID CONTAINER -->	
		
		<footer class="container-fluid">
			<div class="container">
				<div class="row-fluid">
					<div class="span5">
					
					</div>
					<div class="span5 offset2">
					
					</div>
				</div>
			</div>
		</footer>  
    <!-- WP FOOTER -->
  	<?php wp_footer(); ?>
	    
</body>
</html>
