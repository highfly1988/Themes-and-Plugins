<?php
	echo pmpro_shortcode_login('');
?>