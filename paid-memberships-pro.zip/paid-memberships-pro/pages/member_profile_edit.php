<?php
	echo pmpro_shortcode_member_profile_edit('');
?>
