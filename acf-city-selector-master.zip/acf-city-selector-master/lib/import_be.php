<?php include( 'cities_be.php' ); ?>
<?php $this->acfcs_errors()->add( 'success_cities_imported_belgium', esc_html__( 'Successfully imported 1166 cities for Belgium.', 'acf-city-selector' ) ); ?>
