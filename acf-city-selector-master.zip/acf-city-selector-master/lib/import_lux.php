<?php include( 'cities_lux.php' ); ?>
<?php $this->acfcs_errors()->add( 'success_cities_imported_luxembourg', esc_html__( 'Successfully imported 12 cities for Luxembourg.', 'acf-city-selector' ) ); ?>
