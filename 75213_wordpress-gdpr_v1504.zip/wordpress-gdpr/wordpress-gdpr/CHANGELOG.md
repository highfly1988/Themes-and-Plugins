# Changelog
======
1.5.0.4
======
- FIX:	Important Cookie Service Management update
- FIX:	Updated GR Translations
		Thanks to Thomas Davliakos
- FIX:	Updated ES Translations
		Thanks to Henry Alcaly

======
1.5.0.3
======
- FIX:	Fix one bug, bigger bug pops up ... 
		https://imgur.com/gallery/pPeBAIJ
- FIX:	Checkboxes style does not get overwritten by themes

======
1.5.0.2
======
- NEW:	When no service categories / services created popup does not work
		Either remove Trigger & Disable popup OR create services
- FIX:	Added Quform to Service Migration (Button)
- FIX:	Quform cookie could not be set

======
1.5.0.1
======
- FIX:	JS Issue 
- FIX:	PHP Notices when no services created

======
1.5.0
======
- NEW:	Interactive Privacy Settings Modal 
		!! Important !!
		Watch the following Video for new features & how to migrate:
		https://www.youtube.com/watch?v=6mxtXaRVhec&feature=youtu.be
			
		Quick Migration:
		1. Update Plugin
		2. Go to Settings > General > Click on Migrate Services
		3. Check Migrated Services
		!! Important !!
- NEW:	Migrate old Integrations to GDPR Services
- NEW:	Own GDPR Services Post type
		- Service Name (e.g. Analytics)
		- Description (e.g. Reason)
		- Code for Head and Body
		- Code for Head and Body
- NEW:	Added template content for Pages when clicking on install pages:
		- Privacy Policy
		- Cookie Policy
		- Terms & Conditions
- NEW:	Completly rewritten public code
- FIX:	Improved Cookie Deleting
- FIX:	Performance Increase
- DEPRECATED: privacy_settings shortcode

======
1.5.0-beta3
======
- NEW:	Added Service Category Description
- FIX:	Privacy Settings Modal CSS issue
- FIX:	Categories not editable

======
1.5.0-beta2
======
- NEW:	Accept / decline all Cookie Services
- NEW:	Migrate Button automatically assigns Services to Categories now
- FIX:	Multiple Bug fixes

======
1.5.0-beta1
======
- FIX:	Privacy Popup could not be opened again
- FIX:	Cookie Length of 4000 was reached
- FIX:	Migrate Services not working because of permission

======
1.4.0.2
======
- FIX:	Autoptimize issue
- FIX:	After decline cookies turn back on issue

======
1.4.0.1
======
!IMPORTANT
- FIX:	Fixes an JS error in 1.4.0 - update important! 

======
1.4.0
======
- NEW:	Privacy Policy Acceptance
		See	Privacy Policy > Show Accept Checkbox
- NEW:	Terms & Conditions Acceptance
		See	Terms & Conditions > Show Accept Checkbox
- NEW:	Popup Close icon can now be styled
- NEW:	Do not show Popup for Robots / Crawlers 

======
1.3.10
======
- NEW:	Video explaining Integrations
		https://www.youtube.com/watch?v=YsseLicaQ78
- FIX:	Yes / No Translations
- FIX:	Request Status 

======
1.3.9
======
- FIX:	Issue on Multisite Activation
- FIX:	WPML string translation issue

======
1.3.8
======
- FIX:	Privacy Center Text has an own CSS Class
- FIX:	Missing Translation strings
- FIX:	Privacy Settings Popup now also gets hidden for non EU users
		where style was set to overlay
- FIX:	Updated POT

======
1.3.7
======
- NEW:	Video how to setup our plugin:
		https://www.youtube.com/watch?v=fO7pa3Kf5Qg&feature=youtu.be
- FIX:	Install pages redirect
- FIX:	Updated POT File

======
1.3.6
======
- FIX:	Issue 500 with certain wp installations

======
1.3.5
======
- NEW:	PixelYourSite now fully supported if Facebook Integration enabled
- FIX:	Performance & Stable issue
- FIX:	Redux Framework check now by Class (if your theme already has it, you do
		not need to install it again)

======
1.3.4
======
- NEW:	Media Credits Page
- NEW:	Added Media Credits & Data Recitifcation to install pages
- FIX:	Updated POT
- FIX:	Updated DE Translations

======
1.3.3
======
- NEW:	Added Data Rectification
- NEW:	Added regular expression check for allowed cookies
		Make sure you add the following custom Cookies to your options:
		"wordpress_test_cookie,wordpress_logged_in_,wordpress_sec"
- FIX:	Pixelyoursite Hook does not get correct Cookies (whyever)
		We now use general _ga cookie to see if tracking cookies are allowed

======
1.3.2
======
- NEW:	Option to exclude pages for the popup appear
- NEW:	Improved Polylang Support
- FIX:	Privacy Settings Modal Flyout option not visible in admin panel
- FIX:	Responsive overlay fix
		Thanks to ahumadomayte
- FIX:	User check 

======
1.3.1
======
- FIX:	Reponsive Overlay fix
- FIX:	Added Z-Index to Privacy Popup when on bottom
- FIX:	CSS Classes

======
1.3.0
======
- NEW:	Faster & More Secure Cookie Checks
- NEW:	Option to add custom technical allowed cookies
		This will be shown as technical required cookies in privacy settings
		See general Settings > Custom Allowed Cookies
- NEW:	Overlay Popup Style (Popup will be centered and background grey)
		See Popup > Popup Style > Overlay
- NEW:	Privacy Settings Popup can now be used even with Cookie Popup on Top 

======
1.2.10
======
- FIX:	Performance Update

======
1.2.9
======
- FIX:	Removed last margin on privacy center items
- FIX:	Updated missing translations & POT File (po file needs to be synced)
- FIX:	Emails for data breach & updated policy now use Single recipients headers

======
1.2.8
======
- NEW:	You can now automatically create all Pages 
		See Settings > General
- NEW:	Create all Pages automatically
- NEW:	Splitted one Checkbox for WooCommerce Acceptances into two:
		One for Checkout
		One for Register Account
- NEW:	Added span element to text after checkboxes
- FIX:	Forget me button not displayed when checkbox active
- FIX:	WooCommerce Registration checkbox hook changed to woocommerce_register_form
- FIX:	Last logged in time in readable format
- FIX:	Popup settings not saved when cookies accepted / declined
- FIX:	Privacy center item not removed when disabled (only by empty page)
- FIX:	Updated Translations

======
1.2.7
======
- NEW:	You can now add as many custom integrations as you want
		See Settings > Integrations > Custom Integrations (at the bottom)
		FAQ: https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/custom-integrations/
- FIX:	PHP notice after send export
- FIX:	Responsive issues on Mobile
- FIX:	Updates Translation POT file

======
1.2.6
======
- NEW:	Added an option to allow all cookies for first time users
		Many big companies do this even after GDPR - lawyers are
		not 100% sure if this compliant - but this allows you to
		track Analytics for example until user explicitly opted out
- NEW:	Added DMCA Page
		See Settings > DMCA
- FIX:	PHP notice

======
1.2.5
======
- NEW:	Option to use GEO IP to show popup only to EU citizens
		See Settings > Expert
- NEW:	Filter for privacy center items:
		apply_filters('wordpress_gdpr_privacy_center_items', $privacyCenterItems);
		-> With this you can change icons, move items on the privacy center page
- FIX:	Privacy Modal in Popup only possible if bar on bottom
- FIX:	Accept all triggers a click change event now

======
1.2.4
======
- NEW:	Privacy Settings Popup Menu
		See on our Demo Website at bottom right
		This can be enabled in Popup > Show Privacy Settings Modal
- NEW:	Added a Data Retention
		User data can be deleted automatically after X days	when user has not logged in. 
		You can check last logged in "GDPR Requests" > Users
- NEW:	Cookie Consent Log for Logged in Users
		This shows you which users has accepted what cookies
		See GDPR Requests > Users
- NEW:	Filters:
		wordpress_gdpr_privacy_settings
- NEW:	Actions:
		wordpress_gdpr_allow_cookies
		wordpress_gdpr_decline_cookies
		wordpress_gdpr_update_cookie
- FIX:	Added Page Options to WPML Keys

======
1.2.3
======
- NEW:	Inform when no user data found (e.g. after deletion)
- FIX:	After forget me clicked, request status did not changed
- FIX:	User data send not correct email for "email"-only requests
- FIX:	Flamingo records deltetion
- FIX:	Updated ALL translation files and POT

======
1.2.2
======
- FIX:	PHP Notice
- FIX:	Updated IT Translations

======
1.2.1
======
- NEW:	Updated german translations
		Thanks to Frank Rausch
- NEW:	Moved Whitelist option to a new "expert"-Section
- NEW:	Updated Slovakian Translations
- FIX:	Removed a small PHP notice causing JS issues
- FIX:	Updated DA Translations

======
1.2.0
======
- NEW:	We revamped the AJAX Cookie Allowance check
		Instead of multiple AJAX calls it now only calls one
- NEW:	If requests allowed without user exist check
		Data (Form entries, Comments, Orders) can now be removed by Email
- NEW:	Added Gravity Forms support for Export & Deletion
- NEW:	Option to use a Cookie Whitelist
		Read more: https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/cookie-whitelist/
- NEW:	Added Romanian Translations
		Big Thanks to Leo Diaconu
- NEW:	Added Swedish Translations
		Big Thanks to Mikael Svensson
- NEW:	Update IT Translations
		THANKS to DDS Lab di Diego Gianluigi Di Salvo
- NEW:	Delete Quform entries by Email or User ID
- NEW:	Delete Gravity Form entries by Email or User ID
- NEW:	Delete FlamingoDB entries by Email or User ID
- NEW:	Delete Formidable entries by Email or User ID
- NEW:	Export Quform entries by Email or User ID
- NEW:	Export Gravity Form entries by Email or User ID
- NEW:	Export FlamingoDB entries by Email or User ID
- NEW:	Export Formidable entries by Email or User ID
- FIX:	Updated POT File
- FIX:	Code Refracturing 
- FIX:	Updated WPML Keys

======
1.1.6
======
- NEW:	Added Support for pixelyoursite.com
		If Facebook Integration not allowed our plugin
		sets "pys_disable_by_gdpr" Filter to true
- NEW:	Added Entry export of Formidable & Quform entries
- NEW:	Removed Settings to remove Formidable & Quform entries
		to Integration Settings Section.
		MAKE sure you reenable settings there.
- FIX:	Updated Cookies for deletion of all services
- FIX:	Added Multiple Delete Cookie Functions
- FIX:	Updated Flamingo Enabled Check

======
1.1.5
======
- NEW:	Genernal > Domain text option.
		For GA cookies to be stopped / allowed you need to 
		pass your domain you set in GA there. E.g. ".db-dzine.com"
- NEW:	When click on accepted or declines the checkboxes will be
		checked / unchecked without page refreshing
- NEW:	Formidable support 
		Forget me requests can now also delete formidable entries
		See Settings > Forget Me > Formidable

======
1.1.4
======
- FIX:	Adsense Ads will not be removed when no consent given

======
1.1.3
======
- NEW:	Added Support for Adsense
- NEW:	Quform data can now be deleted
- NEW:	Added more option in Forget me options
		about what will be deleted
- FIX:	Updated NL Translations
		Big Thanks to JP Hoey

======
1.1.2
======
- NEW:	Added Piwik Integration
- NEW:	Added Slovakian Translation
- NEW:	Added an option to enable Mailster checkbox only
		This way you can use disable our Checkbox for Mailters,
		but still use the unsubscribe link
- NEW:	Added an option to export data as HTML instead of JSON
- FIX:	Updated POT File (Translations)

======
1.1.1
======
- NEW:	When mailster integration enabled the privacy center link
		to Unsubscribe directly links to mailster unsubscribe page
- FIX:	Cookie policy in Popup not shown

======
1.1.0
======
- NEW:	Added Support for WP 4.9.6
		Some comment & info about WP 4.9.6 & GDPR:
		https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/wordpress-4-9-6-gdpr/
- NEW:	Added an option to allow all cookies when a user is logged in
- FIX:	Call to undefined function wp_delete_user
- FIX:	Testing WP 4.9.6
- FIX:	Updated Slovenian Translations
- FIX:	Moved Settings to an own Menu item for 4.9.6 compatibility

======
1.0.10
======
- NEW:	Added Hungarian Translations
- NEW:	Added Tag Manger Body Tag option (need for browsers with JS disallowed)
- FIX:	Fixed an issue with non closing a tag

======
1.0.9
======
- NEW:	Added Recaptcha Option
		See settings > General
- NEW:	Added Slowenian Translations
- NEW:	Added FAQ for Quforms
		https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/quform/
- FIX:	Fixed an issue where Privacy Center was no more available when
		WooCommerce integration activated

======
1.0.8
======
- FIX:	Small Misspelling issue
- FIX:	Updates Translation Template

======
1.0.7
======
- NEW:	Added Flamingo DB Support
		https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/cf7/
- NEW:	Added Mailster Support
		https://plugins.db-dzine.com/wordpress-gdpr/documentation/faq/mailster/
- NEW:	Added WooCommerce to Privacy Settings
		explaining that 2 cookies are neccessary 
		for order processing
- NEW:	Integrations Tutorials: 
		https://plugins.db-dzine.com/wordpress-gdpr/documentation/topics/integrations/
- NEW:	Filter for Neccessary Cookies: wordpress_gdpr_necessary_cookies
- FIX:	Updated Translations template

======
1.0.6
======
- NEW:	Added Facebook Pixel Code Support
- FIX:	If options disabled still show settings

======
1.0.5
======
- NEW:	Send out Privacy Policy Update Emails
		Settings > Privacy Policy Update
- NEW:	Decline Cookies in Popup
		This will be saved in a cookie
- NEW:	Added Privacy Settings to popup
- NEW:	Requests can be created even when user 
		does not exists in WP. This allows offline
		or other systems data to send manually.
		Settings > FORM > Disable User Exist Check
- NEW:	Added a manually done button to requests
- FIX:	Adjusted all Popup Texts
		Reset this section in plugin settings
- FIX:	Moved Data Breach Email button to settings page
- FIX:	Added Redirect after Action was taken

======
1.0.4
======
- NEW:	Added BuddyPress Support
- NEW:	Added Cloudflare Support

======
1.0.3
======
- NEW:	Close Cookie Popup Button
- NEW:	If logged in as admin -> cookies allowed
		This prevents logged out loop
- NEW:	Redux Framework Cookie blocked

======
1.0.2
======
- NEW:	Added Disclaimer Page
- NEW:	Added Terms and Conditions Page
- FIX:	Integrations will be accepted when cookies allowed
- FIX:	Updated Translations

======
1.0.1
======
- NEW:	Added Imprint Page (necessary for Germany)
- NEW:	Added Machine Translations:
		de_DE
		da_DK
		fr_FR
		it_IT
		nl_NL
		pl_PL
		pt_PT
		es_ES
- FIX:	WPML Keys
- FIX:	Ajax check only if enabled in admin panel

======
1.0.0
======
- Inital release