<?php
$l['number'] 						= 'Referencia';
$l['date'] 							= 'Fecha';
$l['due'] 							= 'Facha de vencimiento';
$l['to'] 							= 'Facturación a';
$l['from'] 							= 'Nuestra información ';
$l['product'] 						= 'Producto';
$l['amount'] 						= 'Cantidad';
$l['price'] 						= 'Precio';
$l['discount'] 						= 'Descuento';
$l['vat'] 							= 'Impuestos';
$l['total'] 						= 'Total de';
$l['page'] 							= 'Página';
$l['page_of'] 						= 'de';
?>