<?php
/**
 * Field Settings
 *
 * @since 2.5
 */
class WPUF_Form_Builder_Field_Settings_Pro extends WPUF_Form_Builder_Field_Settings {

    /**
     * Pro field settings
     *
     * @since 2.5
     *
     * @return array
     */
    public static function get_field_settings() {
        return array();
    }
}
