<?php


namespace Twilio\Exceptions;


class TwimlException extends TwilioException {

}