Do not edit templates in the plugin folder, since all your changes will be lost after plugin update.

Read the following article to learn how to edit default templates or create a custom one:

https://getshortcodes.com/docs/posts/#built-in-templates
