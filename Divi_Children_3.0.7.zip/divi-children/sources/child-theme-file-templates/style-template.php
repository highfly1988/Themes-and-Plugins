/*
Theme Name:  <?php echo $theme_name, "\n"; ?>
Theme URI:   <?php echo $theme_uri, "\n"; ?>
Version:     <?php echo $theme_version, "\n"; ?>
Description: <?php echo $theme_description, "\n"; ?>
Author:      <?php echo $theme_authorname, "\n"; ?>
Author URI:  <?php echo $theme_authoruri, "\n"; ?>
Template:    Divi
*/

/*- Add any CSS custom code for this child theme below this line -*/