<?php

include( DCE_PATH . '/child-includes/templates/single.php' );

?>