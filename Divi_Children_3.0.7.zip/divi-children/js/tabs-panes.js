jQuery(document).ready(function($) {

	$( "#dch-tabs" ).tabs();
	
});


