<?php
define('bup_pro_url','https://bookingultrapro.com/');
