
var $ = jQuery;

jQuery(document).ready(function($) {


		$('.color-picker').wpColorPicker();
	
	
});