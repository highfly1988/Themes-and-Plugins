=== WP VR - 360 Panorama and Virtual Tour Creator For WordPress ===
Contributors: rextheme, coderexco
Tags: virtual tour, real estate tour, panorama, panorama viewer, virtual tour, 360 panorama, interactive tour, 360, streetview, virtual reality, 360 video, virtual, vr, interactive, 360-degree, equirectangular, google streetview, panoramas
Donate link: https://rextheme.com/wp-vr-360-panorama-and-virtual-tour-creator-for-wordpress/
Requires at least: 5.0
Tested up to: 5.6.0
Requires PHP: 7.0.0
Stable tag: 7.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Let site visitors take a virtual tour and get them excited!! Let them experience a glimpse of a live tour of your place.

== Description ==
Create amazing virtual tours on your own easily using WP VR. Let visitors take a tour of your place remotely, and get them more excited.

With WP VR, you can create a virtual tour where visitors can navigate a 360 view of your location, switch between several scenes, get information on items on the location, zoom in and out to get a better view, and get an overall idea about how your place may look in reality.

Simply provide a 360 panoramic image, and this plugin will transform it into a realistic virtual tour.

>WPVR is fully compatible with Gutenberg Block Editor, Elementor Page Builder, and Oxygen Builder.

 [Demo Virtual Tour (Pro)](https://rextheme.com/wpvr/#demo-tour) | [Documentation](https://rextheme.com/docs/wp-vr/) | [Premium Version](https://rextheme.com/wpvr/)

 == Why Use WPVR? ==
WPVR gives you all the features needed to create a quality virtual tour without any hassle.

https://www.youtube.com/watch?v=SWsv-bplne8

**Simple Interface Optimized To Create Virtual Tours Easily** 

The plugin has a simple interface, designed to let you create a virtual tour real quick, without any expertise.

>In fact, you can create a simple virtual tour in less than 5 mins!!

On top of that, you can customize the tour with more amazing features such as auto-rotation effect and scene fade animation when transmitting between scenes.

You can also display images or videos on hotspots, allow Gyroscope mode on mobile devices, and many more, to make the tour more attractive and engaging.

The best part is, you will get a tour preview at the back-end so that you can see what you are creating on the go.

>Read detailed [documentation](https://rextheme.com/docs/wp-vr/) and [video tutorials](https://www.youtube.com/playlist?list=PLelDqLncNWcUndi1NkXJh2BH62OYmIayt) for assistance.

**Create An Interactive Realistic Tour With Multiple Scenes**

You can add multiple 360-degree images in a virtual tour and connect them through scene type hotspots.

Viewers can click on the hotspots to move back and forth between the images.

You can also set multiple info type hotspots on each scene to show additional information about each 360 degree image or scene.

> You can connect up to 5 scenes, and add 5 hotspots per scene on a virtual tour. To be able to add unlimited scenes and hotspots, [click here](https://rextheme.com/wpvr)

**Interactive Hotspots To Create More Attraction**

WP VR comes with over 900+ custom icons for hotspots, that you can choose from. And you can assign a color and add a blinking/ripple animation to the custom icons to make the hotspots more catchy.

Also, WP VR allows you to add custom icons on your own using custom CSS.

You can set texts, image/GIF source, and video embedding links on hotspots. You can set these either in the On-Hover Content field or the On-Click Content field.

Viewers can view these contents by clicking on the hotspot or hovering over the hotspot.

>Contact our reliable [support team](https://rextheme.com/open-ticket) to help you out anytime.

**Embed Virtual Tours On Your Website Without Hassle**

Once you create a tour, it’s really easy to embed it on your website.

Simply use the WPVR Gutenberg block, WP VR Elementor Widget, WP VR Oxygen Element, or Shortcodes to embed the tour on any page or post on your website.

***Gutenberg Block Support***

On the Gutenberg block editor, it has the WP VR block under the common blocks. It is used to embed the virtual tour. Provide the tour ID and assign your desired width and height, and the tour will be embedded.

***Elementor Widget Support***

The Elementor page builder will have a WP VR widget under the general widgets. Drag and drop the widget onto the page. Provide the tour ID and set your required width and height to get a live preview.

***Oxygen Element Support***

The Oxygen builder will have a WP VR element Choose your tour from the list, set your desired Width and height, and Apply Params to embed the tour.

***Shortcode Support***

On Classic Editor, you can easily embed virtual tours using Shortcodes. Set your tour ID, width, height, and your tour will be embedded.

**Disable WordPress Large Image Handler To Upload High-Quality Images**

WordPress has a default large image handler that handles images with a size of more than 2560 by 1280 pixels and creates optimized versions of them.

So if you upload a very high-quality image, it will be converted to a lower resolution image.

WP VR allows you to disable this large image handler so you can create virtual tours with extremely high-resolution images.

**Control Editors and Authors from Accessing Tours**

Control the Editors and Authors of your site from accessing the virtual tours on your site.

==Who Should Use WP VR?==

- Real Estate Industry
- Educational Institutes (Schools and colleges)
- Hotels and Resorts
- Restaurants
- Travel/Tourism
- Museums
- Art Galleries
- Showrooms/Stores
- Bars/Pubs.

And many more.

To have more control over creating a virtual tour, learn about the [Premium version](https://rextheme.com/wpvr/).

==FEATURES==

* Developed with a Mobile-First approach
* 360 Degree Video Support (Self-hosted, Youtube and Vimeo Videos)
* Gutenberg Block Support
* Elementor Widget Support
* Shortcode Support
* Oxygen Builder Support
* Live Preview of Tour On The Back-end
* Tour Preview Image
* Tour Autoload Feature
* Scene Fade Animation
* Auto Rotation with Speed Control
* Auto Rotation Direction, Pause and Stop control
* Basic Control Buttons (Zoom In, Zoom Out, and Fullscreen)
* Mouse Drag Navigation on Virtual Tour
* Zoom In and Out with Mouse Scroll on Virtual Tour
* Zoom In and Out with ‘+’ and ‘-’ keyboard buttons
* Add Multiple Scenes and Hotspots
* Scene Type Hotspot to Connect Scenes
* Info Type Hotspots to Give Information
* On Hover and On-Click Content Option for Hotspots
* Embed Texts, Videos, Images, GIFs, and Website Links on Hotspots
* Hotspot Customization with Custom CSS
* Full-width Tour Tag
* Radius Tag for VR Border Radius
* Multi-Site Support
* WP User Role Support (Editors and Authors)
* Disable FontAwesome Option
* Disable WordPress Default Large Image Handler
* Control Plugin Assets To Load on Specific Pages/posts Only
* Enable notice for Mobile Visitors
* Mobile Media Resize Option
* Plugin Rollback Support
* Support From the Support Forum

==PREMIUM FEATURES==

* All Free Features
* Unlimited Scenes and Hotspots (Limited to 5 in The Free Version)
* 360 Video Autoplay and Loop
* Google Street View Embed Support
* Gyroscope Support on Mobile Devices
* Auto Enable Gyroscope for Mobile Devices
* Custom & Responsive Scene Gallery
* Scene Titles on Each Scene
* Scene Description (Author) & URL on Each Scene
* Scene Titles & Thumbnails on Scene Gallery
* Tour Background Music Support
* Background Music Autoplay, Loop, & Pause Control
* Set Your Company Logo on The Virtual Tour
* Set Company Description on The Logo
* Home Button to Go to The Default Scene
* On-Screen Compass for Tours
* Disable or Enable Keyboard Movement Control
* Disable or Enable Keyboard Zoom Control
* Disable or Enable Mouse Drag Control
* Disable or Enable Mouse Scroll Zoom
* Fluent Forms Integration on Hotspots
* Fill-up and Submit Booking/Contact Forms
* WooCommerce Product Integration on Hotspots
* Add To Cart Feature for WooCommerce Products on Hotspots
* Advanced Control Buttons (Move Up, Down, Left, & Right)
* Customize Icons of Each Control Button (900+ Premium Icons)
* Customize Colors of Each Control Button (RGB, HSL, & HEX)
* Enable or Disable Each Control Button
* Custom Default Scene Face for Each Scene
* Default Scene Face For Target Scene
* Partial Panorama (Mobile Panorama) Support
* Scene Boundary Control (Horizontal & Vertical)
* Set Vertical Offset of Each Scene
* Limit Vertical Scene Grab for Each Scene
* Limit Horizontal Scene Grab for Each Scene
* Control Max, Min, and Default Zoom for Each Scene
* Customize Each Hotspot Icon (900+ Premium Icons)
* Color Picker for Hotspots (RGB, HSL, & HEX)
* Tour Export and Import (For WP VR Only)
* Duplicate Tour with One Click
* Priority Support

[Upgrade to Pro](https://rextheme.com/docs/wp-vr/how-to-upgrade-to-pro/)

>  We have many more amazing features planned. Take look at [our development roadmap.](https://app.productstash.io/roadmaps/5f0b43d9a54eda00221d5516/public)

**Upcoming Features**

– Flat Image Support
- Cubemap Image Support
- Multi-Resolution Panorama Support
- Floor Plan


## Privacy Policy
WP VR uses [Appsero](https://appsero.com) SDK to collect some telemetry data upon user's confirmation. This helps us to troubleshoot problems faster & make product improvements.

Appsero SDK **does not gather any data by default.** The SDK only starts gathering basic telemetry data **when a user allows it via the admin notice**. We collect the data to ensure great user experience for all our users.

Integrating Appsero SDK **DOES NOT IMMEDIATELY** start gathering data, **without confirmation from users in any case.**

Learn more how [Appsero collects and uses this data](https://appsero.com/privacy-policy/).

== Frequently Asked Questions ==

=1. Why Do I Need WP VR?=

You can easily create a Virtual Tour of your place using WP VR to build a virtual presence of your business.

Simply provide a 360 degree panoramic photo and this plugin will create a virtual tour that your visitors can navigate easily.

Allow your prospects to have a realistic tour of your facility before they decide to purchase your service and increase your conversion rate.

=2. How to Install and Activate WP VR?=

Once you have downloaded the file,  go to your dashboard. Under Plugins, select Add New, and upload the file. Then Install and activate the plugin.

Once activated, on the left side under your dashboard, you will find the option WP VR at the bottom.

=3. What Kind of Images Should I Use To Create A Virtual Tour?=

To make a perfect equirectangular image, you need to use a 360-degree panoramic photo of the area you want to preview.

However, you can also capture panorama images with your smartphone and use them to create a partial panorama tour.

=5. Can I Customize The Hotspot Icons?=

Yes. You can create a custom class on your theme, stating whatever style you want. Then you can input the class name on the Hotspot Custom Class section in a hotspot, and the content displayed will be customized according to the style you set.

=6. Can I Create A 360 Degree Video Tour With WP VR?=

Yes, with WP VR, you can create a 360 Degree video tour.

You can either upload the video to create a tour or set a link to a Youtube/Vimeo 360 degree video.

=7. How To Embed A Virtual Tour Using Gutenberg Block Editor?=

Under common blocks, you will find a block called WP VR. Select the block and on the dynamic toolbar on the right, you will get the options to add ID, Height, and Width.

Collect the ID from the virtual tour you created. Assign height and width as you desire.

=8. The Tour Is Not Loading On The Webpage.=

Go to your WordPress Dashboard > WPVR > Get Started > Settings.

Check the Enable Script Control option status.

If the Enable Script Control option is turned On, turn it off and reload the tour page.

If you wish to use this feature, you have to set the URLs of all the pages on your site with a virtual tour in the List of Allowed Pages To Load WPVR Scripts field.

=9. What To Do If I Get “THE FILE (image link) COULD NOT BE ACCESSED” Error?=

Sometimes when you add a tour on your site, you might face this issue that rather than loading the tour it will give the error “THE FILE (…) COULD NOT BE ACCESSED.”

This error shows up when you are running a website under “HTTPS” (secured with SSL certificate) whereas your image link is under “HTTP” (unsecured).

To solve this issue, go to your WordPress Dashboard > Settings > General. Here make sure you have “https” added to both “WordPress Address (URL)” and “Site Address (URL)”. That’s it. Your virtual tour will load with no issues.

=10. Can I make The Virtual Tour Full-width?=

Yes, you can publish the tours as full-width of your page/post.

For Gutenberg, Elementor, and Oxygen builder, set fullwidth on the Width field. For shortcodes, set width = “fullwidth”.

=11. What If I Use An Optimization or Caching Plugin?=

If you use any Optimization or Caching plugins, then you need to exclude WP VR from its optimization function.

Simply add “/plugins/wpvr” to the exclusion field (or use the location where you store plugins).

== Screenshots ==
1. Gutenberg Block
2. Block ID selection
3. General settings window
4. Scene setting
5. Hotspot setting
6. Hotspot setting
7. Preview window
8. Preview window
9. Elementor setup
10. Front view
11. Front view with customized hotspot icon
12. Front view with gallery

== Changelog ==

= 1.0 =
* Hotspot custom icon support.
* On screen control available.

= 1.0.1 =
* Default scene can be selected from the scene tab.
* Default height and width given for shortcodes.

= 2.0.0 =
* Gutenberg block support
* Bug fix.

= 2.1.0 =
* Save draft fixed.
* Error handling fixed.
* Video support added.
* Slider revolution conflict fix.
* Auto rotation
* Rotation pause and stop control

= 2.1.1 =
* Dynamic Font-Awesome icon added for hotspots.
* Dynamic color picker added for hotspot color.
* Custom panorama compass support.
* Default zoom level.
* Maximum and minimum zoom range.
* Customize each scene's default face on load.
* Scene grab control and custom boundary for each scene.

= 2.2.0 =
* Scene title and author tag support.
* Elementor widget support.

= 2.3.0 =
* Elementor widget support for free.
* Mozilla Firefox bug fix.
* CDN load fix.
* Block input dropdown added.
* Hotspot based scene face added.

= 2.4.0 =
* Font-awesome icon load fix.
* Plugin conflict fix.
* Rextheme link removed from premium version.

= 2.5.0 =
* Gyroscope support on the premium version.
* Appsero error fix.
* Gutenberg block column layout fix.

= 2.6.0 =
* Duplicate tour.
* Blink animation automated.
* Language issue fixed.

= 2.7.0 =
* Post memory limit fix.

= 2.8.0 =
* Dynamic error reporting added.

= 2.9.0 =
* Tour selector updated on VR block.

= 3.0.0 =
* File import & export system added.
* Fullwidth tag added.
* Placeholder color changed.

= 3.1.0 =
* Custom scene gallery.
* Border radius tag added.
* Modified preview window.

= 3.2.0 =
* Custom scene gallery conflict and a bug fix for iPhone and iPad.

= 3.3.0 =
* Placeholder change.

= 3.4.0 =
* Repeater delete confirmation fix.

= 3.4.1 =
* Gallery carousal fix

= 3.4.2 =
* Gallery carousal design fix
* CSS and js restricted

= 3.4.3 =
* Autorotation error fix
* Ziparchive class error fix

= 3.4.4 =
* Rotation fix on default scene face
* Rotation fix on hotspot to target scene face
* Plugin library update

= 3.4.5 =
* Wordpress.com hosting support fixed

= 3.4.6 =
* Custom control feature for pro version
* WordPress 5.3 bug fix

= 3.4.7 =
* Google street view embed

= 3.4.8 =
* Company logo on pro version
* Made preview load more efficient

= 3.4.9 =
* JS & CSS load optimized

= 3.5.0 =
* Front-end error fix

= 3.6.0 =
* js optimization removed

= 3.7.0 =
* Partial Panorama for the pro version

= 3.8.0 =
* Load box design changed

= 3.9.0 =
* Gallery toggle fix

= 4.0.0 =
* User role support added

= 4.1.0 =
* 360 video autoplay and loop
* Mouse scroll support added

= 4.2.0 =
* Keyboard control switch added
* Font-Awesome conflict fix

= 4.3.0 =
* Draggable switch added
* Setting title capitalized

= 4.4.0 =
* Draggable error fix
* Control plugin scripts and styles to load them on specific pages only.

= 4.5.0 =
* Library updated
* Fixed default icon issue on android.

= 4.6.0 =
* Gyroscope Support fix for custom control

= 4.7.0 =
* Gyroscope conflict fix with default control
* WordPress high resolution image upload
* Input type error handled

= 4.8.0 =
* Script & Style file control modified

= 4.9.0 =
* Scene title field added for gallery content

= 5.0.0 =
* Home button added to return to the default scene

= 5.1.0 (26-03-2020) =
* Auto device based gyro enable added

= 5.2.0 (02-04-2020) =
* Author URL field added

= 5.3.0 (16-04-2020) =
* Keyboard zoom control added
* Logo style modified

= 5.4.0 (27-04-2020) =
* Device Orientation control fix

= 5.5.0 (12-05-2020) =
* Custom control conflict fixed
* On click container fixed
* Self hosted video pause on the cross button

= 5.6.0 (15-06-2020) =
* VR background music support

= 5.7.0 (20-7-2020) =
* UI updated
* Youtube 360 video autoplay fixed
* Company logo style fixed
* Save draft issue fixed
* Gallery thumbnail size image loaded
* Gallery scene ids replaced with scene title
* Plugin rollback feature added

= 5.8.0 (25-7-2020) =
* Submit restriction to control gyro for SSL
* Add-on compatibility added
* Mobile notice added
* License input type changed to password
* On click content container responsive issue fixed

= 5.9.0 (27-7-2020) =
* Export/import SSL error fixed
* JS error fixed

= 6.0.0 (28-7-2020) =
* Error fix for safari
* JS error fix for optimization

= 6.1.0 (31-7-2020) =
* Style issue fixed for on click content

= 6.2.0 (07-08-2020) =
* Oxygen builder support added
* Multi-site support added
* Dynamic front-end notice added

= 6.3.0 (14-08-2020) =
* Mobile media resizer added
* WordPress 5.5 compatible
* Street View responsive issue fixed

= 6.4.0 (19-08-2020) =
* Media resizer fixed

= 6.5.0 (31-08-2020) =
* Empty needle warning fixed
* Appsero updated

= 6.6.0 (09-09-2020) =
* Preview gallery modified
* Mobile media resizer modified
* Video tab bug fixed
* Allow URL open auto handled

= 6.7.0 (18-09-2020) =
* Import/Export modified
* Mobile media resizer switch added
* Ocean theme conflict fixed

= 6.8.0 (22-10-2020) =
* Display gallery by default on the tour

= 6.9.0 (16-11-2020) =
* Accordion support added for elementor
* Iframe conflict fixed
* Control button overlap issue fixed

= 7.0.0 (19-11-2020) =
* Black Friday banner added

= 7.1.0 (19-11-2020) =
* Black Friday banner modified

= 7.2.0 (09-12-2020) =
* WordPress 5.6 compatibility checked
* VR audio conflict fixed

= 7.2.1 (17-12-2020) =
* VR audio JS error fixed
* Warning message added for video tour
* Tab and accordion issue fixed
* Modified rollback options

= 7.2.2 (21-12-2020) =
* Browser JS conflict fixed
* Dummy functions removed

== Upgrade Notice ==
Please do update the WP VR to the latest version. Each update makes sure your plugin is supporting all tour features.
