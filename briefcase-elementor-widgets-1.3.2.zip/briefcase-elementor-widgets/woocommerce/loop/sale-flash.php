<?php
/**
 * Product loop sale flash
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/sale-flash.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see           https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package       WooCommerce/Templates
 * @version       1.6.4
 */
namespace Briefcase;
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $post, $product;

// Labels come from the woo_dinamyc_field widget

if ( $product_image_labels_new == 'yes') {
	$shop_new_badge_on = true;
}

if ( $product_image_labels_new == 'yes') {
	$new_days = $product_image_labels_new_days;
}

if ( $product_image_labels_featured == 'yes') {
	$shop_hot_badge_on = true;
}

if ( $product_image_labels_outofstock == 'yes') {
	$shop_outofstock_badge_on = true;
}

if ( $product_image_labels_sale == 'yes') {
	$shop_sale_badge_on = true;
}

if ( $product_image_labels_sale_percent == 'yes') {
	$shop_sale_percent_on = true;
}

// New
$postdate    = get_the_time( 'Y-m-d', $post->ID );
$timestamp   = strtotime( $postdate );
$newdays     = apply_filters( 'bew_shop_new_days', $new_days );
$is_new      = ( time() - $timestamp < 60 * 60 * 24 * $newdays ) && $shop_new_badge_on ;
$is_featured = $product->is_featured() && $shop_hot_badge_on;
$is_sale     = $product->is_on_sale() && $shop_sale_badge_on;

if ( ! $product->is_in_stock() || $is_new || $is_featured || $is_sale ) {
	echo '<div class="product-badges">';
}

if ( ! $product->is_in_stock() ) {
	echo '<span class="outofstock">' . esc_html__( 'Out of stock', 'briefcase-elementor-widgets' ) . '</span>';
}

if ( $is_new ) {
	echo '<span class="new">' . esc_html__( 'New', 'briefcase-elementor-widgets' ) . '</span>';
}

// Sale
if ( $is_sale ) {

	$str = esc_html__( 'Sale', 'briefcase-elementor-widgets' );
	
	$helper = new Helper();

	if ( $shop_sale_percent_on && ( $product->is_type( 'simple' ) || $product->is_type( 'external' ) ) ) {
		$str = $helper->get_sale_percentage( $product );
	}

	echo apply_filters( 'woocommerce_sale_flash', '<span class="onsale">' . $str . '</span>', $post, $product );
}

// Featured (Hot)
if ( $is_featured ) {
	echo '<span class="hot">' . esc_html__( 'Hot', 'briefcase-elementor-widgets' ) . '</span>';
}

if ( ! $product->is_in_stock() || $is_new || $is_featured || $is_sale ) {
	echo '</div>';
}

