<?php
/**
 * Image Featured style thumbnail
 *
 * @package Briefcase Elementor Widgets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Display featured image if defined
?>

	<div class="woo-entry-image clr">
		<a href="<?php the_permalink(); ?>" class="woocommerce-LoopProduct-link">
			<?php			
			// Single Image
			echo woocommerce_get_product_thumbnail( $size = $product_image_size); ?>
	    </a>
	</div><!-- .woo-entry-image -->

<?php

