<?php
/**
 * Single Product title
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 1.6.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
} 

global $product;
?>


<h2 class="single-post-title product_title entry-title"><?php echo $product->get_title(); ?></h2>