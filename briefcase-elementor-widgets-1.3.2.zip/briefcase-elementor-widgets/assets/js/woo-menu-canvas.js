var $j = jQuery.noConflict();

$j( window ).on( 'load', function() {
	"use strict";
	// Bew product Add to cart
	bewWooMenuCanvas();
} );

$j( document ).on( 'ready', function() {
	"use strict";
    // Woo menu canvas
    bewWooMenuCanvas();
} );

// Make sure you run this code under Elementor..
$j( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/bew-woo-menu-cart.default', function() {
		"use strict";
	// Bew product Add to cart
	bewWooMenuCanvas();
	});
	} );


/* ==============================================
WOOCOMMERCE MENU CANVAS
============================================== */
function bewWooMenuCanvas() {
	"use strict"

	$j( document ).on( 'click', '.woo-menucart', function( e ) {
		
		e.preventDefault();

		var innerWidth = $j( 'html' ).innerWidth();
		$j( 'html' ).css( 'overflow', 'hidden' );
		var hiddenInnerWidth = $j( 'html' ).innerWidth();
		$j( 'html' ).css( 'margin-right', hiddenInnerWidth - innerWidth );

		$j( 'body' ).addClass( 'menu-canvas-enabled' );
	} );

	$j( '.bew-menu-canvas-overlay, .drawer__btn-close' ).on( 'click', function() {
		$j( 'html' ).css( {
			'overflow': '',
			'margin-right': '' 
		} );

		$j( 'body' ).removeClass( 'menu-canvas-enabled' );
		
	} );
	

}