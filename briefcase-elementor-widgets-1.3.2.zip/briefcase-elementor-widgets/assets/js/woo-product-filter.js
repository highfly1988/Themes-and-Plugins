var $j = jQuery.noConflict();

$j( window ).on( 'load', function() {
	"use strict";
	// Bew product filter
	bewfilter();
} );

// Make sure you run this code under Elementor..
$j( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/bew-woo-grid.default', function() {
		"use strict";
	// Bew product filter
	bewfilter();
	});
	} );
	

/* ==============================================
WOOCOMMERCE PRODUCT FILTER
============================================== */	


function bewfilter() {
	
	
	// product filter
	
		var $portfolio_selectors = $j('.product-filter >li>a');
		var $portfolio = $j('.products-items');
		$portfolio.isotope({
			itemSelector : '.products-item',
			layoutMode : 'fitRows'
		});
		
		$portfolio_selectors.on('click', function(){
			$portfolio_selectors.removeClass('active');
			$j(this).addClass('active');
			var selector = $j(this).attr('data-filter');
			$portfolio.isotope({ filter: selector });
			return false;
		});
	
};