<?php
namespace Briefcase;

use Elementor;
use Elementor\Plugin;
use WP_Query;



class Helper{
	
	function get_bew_active_template($post_id,$post_type){
        $bew_product_template = get_post_meta($post_id, 'bew_post_template', true);

        if(isset($bew_product_template) && $bew_product_template == 'none'){
            return false;
        }

        if(!isset($bew_product_template) || empty($bew_product_template)){
            // apply global template
            $args = array(
                'post_type' => 'elementor_library',
                'meta_query' => array(
                    array(
                        'key' => 'briefcase_template_layout',
                        'value'   => $post_type,
                        'compare' => '='
                    )
                )
            );
            $templates = new WP_Query($args);
            if($templates->found_posts){
                $templates->the_post();
                $bew_tid = get_the_ID();
            }else{
                return false;
            }
            wp_reset_postdata();

        }else{
            // set individual post template
            $bew_tid = $bew_post_template;
        }

        return $bew_tid;
    }

	function get_woo_archive_template(){
			
                $args = array(
                    'post_type' => 'elementor_library',
                    'meta_query' => array(
						'relation'    => 'AND',
                        array(
                            'key' => 'briefcase_template_layout',
                            'value'   => 'woo-shop',
                            'compare' => '='
                        ),
						array(
                            'key' => 'briefcase_template_layout_shop',
                            'value'   => 'on',
                            'compare' => '='
                        ), 
                    )
                );
                $templates = new WP_Query($args);
				
                if($templates->found_posts){
                    $templates->the_post();					
                    $bew_tid = get_the_ID();
					
                }else{
                    return false;
                }
                wp_reset_postdata();
                return $bew_tid;
			
    }
	
	function get_woo_category_template(){	
			
        
            if(is_shop() || is_tax('product_cat') || is_product() || is_singular('elementor_library')|| is_page() || Elementor\Plugin::instance()->editor->is_edit_mode()){
                $args = array(
                    'post_type' => 'elementor_library',
                    'meta_query' => array(
						'relation'    => 'AND',
                        array(
                            'key' => 'briefcase_template_layout',
                            'value'   => 'woo-cat',
                            'compare' => '='
                        ),
						array(
                            'key' => 'briefcase_template_layout_cat',
                            'value'   => 'on',
                            'compare' => '='
                        ), 
                    )
                );
                $templates = new WP_Query($args);

                if($templates->found_posts){
                    $templates->the_post();
                    $bew_tid = get_the_ID();
                }else{
                    return false;
                }				
                wp_reset_postdata();
                return $bew_tid;
					
            }
        
        return false;
    }
	
	public function custom_description() {
		// Custom description callback
			add_filter( 'woocommerce_product_tabs', 'woo_custom_description_tab', 98 );
			function woo_custom_description_tab( $tabs ) {

				$tabs['description']['callback'] = 'woo_custom_description_tab_content';	// Custom description callback

				return $tabs;
			}

			function woo_custom_description_tab_content() {
				global $product, $post;
				$bewglobal = get_post_meta($post->ID, 'briefcase_apply_global', true);
				if (is_product() and $bewglobal == 'off' ) {
				
				echo 'este es custom descrition';
				} else {
					
				echo $product->get_description();
				}
			}
		}

	public static function get_templates() {
		return Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
	}
	
	/**
		 * Get Product Data for the current product
		 *
		 * @since 1.0.0
		 */
	public static function product_data() {
			
			global $product;			
				
			// Show firts product for loop template				
			if(empty($product)){
				// Todo:: Get product from template meta field if available
					$args = array(
						'post_type' => 'product',
						'post_status' => 'publish',
						'posts_per_page' => 1
					);
					$preview_data = get_posts( $args );
					$product_data =  wc_get_product($preview_data[0]->ID);
				
					$product = $product_data; 
							
				
			}
		return $product;
	}
	
	
		/**
		 * Calculate sale percentage
		 *
		 * @param $product
		 *
		 * @return float|int
		 */
		public static function get_sale_percentage( $product ) {
			$percentage    = 0;
			$regular_price = $product->get_regular_price();
			$sale_price    = $product->get_sale_price();

			if ( $product->get_regular_price() ) {
				$percentage = - round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
			}

			return $percentage . '%';
		}
	
	
	 	
}

