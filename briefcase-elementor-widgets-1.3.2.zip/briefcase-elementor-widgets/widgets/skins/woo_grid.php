<?php

namespace Briefcase;

use Elementor;
use Elementor\Plugin;
use Elementor\Post_CSS_File;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow	;
use Elementor\Group_Control_Box_Shadow;
use Briefcase\Woo_Grid\Skins;

/**
 * Woo Grid Module
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class bew_Widget_Woo_Grid extends Widget_Base {
	

	public function get_name() {
		return 'bew-woo-grid';
	}

	public function get_title() {
		return __( 'Woo Grid', 'briefcase-elementor-widgets' );
	}

	public function get_icon() {
		// Upload "eicons.ttf" font via this site: http://bluejamesbond.github.io/CharacterMap/
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'briefcasewp-elements' ];
	}

	public function get_script_depends() {
		return [ 'woo-grid', 'isotope', 'imagesloaded','woo-product-filter' ];
	}
	
	public function is_reload_preview_required() {
		return true;
	}
	
	public static function get_templates() {
		return Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
	}
	
	public static function empty_templates_message() {
		return '<div id="elementor-widget-template-empty-templates">
				<div class="elementor-widget-template-empty-templates-icon"><i class="eicon-nerd"></i></div>
				<div class="elementor-widget-template-empty-templates-title">' . __( 'You Haven’t Saved Templates Yet.', 'elementor-pro' ) . '</div>
				<div class="elementor-widget-template-empty-templates-footer">' . __( 'Want to learn more about Elementor library?', 'elementor-pro' ) . ' <a class="elementor-widget-template-empty-templates-footer-url" href="https://go.elementor.com/docs-library/" target="_blank">' . __( 'Click Here', 'elementor-pro' ) . '</a>
				</div>
				</div>';
	}
	
	protected function _register_skins() {
        
        $this->add_skin( new Skins\Skin_Grid( $this ) );
        
    }

	protected function _register_controls() {
		
		$this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Layout', 'ae-pro' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Layout','ae-pro'),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->end_controls_section();
				
		$this->start_controls_section(
			'section_template',
			[
				'label' => __( 'Template', 'briefcase-elementor-widgets' ),
			]
		);

		$templates = $this->get_templates();

		if ( empty( $templates ) ) {

			$this->add_control(
				'no_templates',
				[
					'label' => false,
					'type' => Controls_Manager::RAW_HTML,
					'raw' => $this->empty_templates_message(),
				]
			);

			return;
		}

		$options = [
			'0' => '— ' . __( 'Select', 'briefcase-elementor-widgets' ) . ' —',
		];

		$types = [];

		foreach ( $templates as $template ) {
			$options[ $template['template_id'] ] = $template['title'] . ' (' . $template['type'] . ')';
			$types[ $template['template_id'] ] = $template['type'];
		}

		$this->add_control(
			'template_id',
			[
				'label' => __( 'Choose Template', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'default' => '0',
				'options' => $options,
				'types' => $types,
				'label_block'  => true,
			]
		);
		
		$button = '<div class="elementor-button elementor-button-default elementor-edit-template-bew" id="bb"><i class="fa fa-pencil"></i> Edit Template</div>';
				
		$this->add_control(
			'field_preview',
			[
				'label'   => esc_html__( 'Code', 'briefcase-elementor-widgets' ),
				'type'    => Controls_Manager::RAW_HTML,
				'separator' => 'none',
				'show_label' => false,
				'raw' => $button,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_woo_grid',
			[
				'label' 		=> __( 'Woo Grid', 'briefcase-elementor-widgets' ),
			]
		);

		$this->add_control(
			'count',
			[
				'label' 		=> __( 'Products Per Page', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'You can enter "-1" to display all posts.', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> '6',
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'columns',
			[
				'label' 		=> __( 'Grid Columns', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '3',
				'options' 		=> [
					'1' 		=> '1',
					'2' 		=> '2',
					'3' 		=> '3',
					'4' 		=> '4',
					'5' 		=> '5',
					'6' 		=> '6',
				],
			]
		);
		
		$this->add_control(
			'mobile_two_col',
			[
				'label' 		=> __( 'Two Columns on mobile devices', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> '',
				'label_on' 		=> __( 'Show', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Hide', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',			
			]
		);

		$this->add_control(
			'grid_style',
			[
				'label' 		=> __( 'Grid Style', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'fit-rows',
				'options' 		=> [
					'fit-rows' 	=> __( 'Fit Rows', 'briefcase-elementor-widgets' ),
					'masonry' 	=> __( 'Masonry', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'grid_equal_heights',
			[
				'label' 		=> __( 'Equal Heights', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'false',
				'options' 		=> [
					'yes' 		=> __( 'Yes', 'briefcase-elementor-widgets' ),
					'false' 	=> __( 'No', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' 		=> __( 'Order', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 			=> __( 'Default', 'briefcase-elementor-widgets' ),
					'DESC' 		=> __( 'DESC', 'briefcase-elementor-widgets' ),
					'ASC' 		=> __( 'ASC', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' 		=> __( 'Order By', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 				=> __( 'Default', 'briefcase-elementor-widgets' ),
					'date' 			=> __( 'Date', 'briefcase-elementor-widgets' ),
					'title' 		=> __( 'Title', 'briefcase-elementor-widgets' ),
					'name' 			=> __( 'Name', 'briefcase-elementor-widgets' ),
					'modified' 		=> __( 'Modified', 'briefcase-elementor-widgets' ),
					'author' 		=> __( 'Author', 'briefcase-elementor-widgets' ),
					'rand' 			=> __( 'Random', 'briefcase-elementor-widgets' ),
					'ID' 			=> __( 'ID', 'briefcase-elementor-widgets' ),					
					'menu_order' 	=> __( 'Menu Order', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'include_categories',
			[
				'label' 		=> __( 'Include Categories', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'Enter the categories slugs seperated by a "comma"', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::TEXT,
				'label_block' 	=> yes,
			]
		);

		$this->add_control(
			'exclude_categories',
			[
				'label' 		=> __( 'Exclude Categories', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'Enter the categories slugs seperated by a "comma"', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::TEXT,
				'label_block' 	=> true,
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section_filter',
            [
                'label' => __( 'Filter', 'briefcase-elementor-widgets' )
            ]
        );
		
		$this->add_control(
			'filter_show',
			[
				'label' 		=> __( 'Show Filter', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> 'yes',
				'label_on' 		=> __( 'Show', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Hide', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',			
			]
		);

		$this->add_responsive_control(
			'filter_align',
			[
				'label' => __( 'Alignment', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .filter-center' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_filter_style',
			[
				'label' 		=> __( 'Filter', 'briefcase-elementor-widgets' ),
				'tab' 			=> Controls_Manager::TAB_STYLE,
				'condition' => [
                    'filter_show' => 'yes',
                ]
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'filter_typo',
				'selector' 		=> '{{WRAPPER}} .filter-center',				
			]
		);
		
		$this->start_controls_tabs( 'tabs_filter_style' );
		
		$this->start_controls_tab(
			'tab_filter_normal',
			[
				'label' => __( 'Normal', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_control(
			'filter_color',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a' => 'background: {{VALUE}};',
				],
				
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_filter_hover',
			[
				'label' => __( 'Hover', 'elementor' ),
			]
		);
		
		$this->add_control(
			'filter_color_hover',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color_hover',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover' => 'background-color: {{VALUE}};',
				],
				
			]
		);

			
		$this->add_control(
			'filter_hover_border_color',
			[
				'label' => __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a:hover' => 'border-color: {{VALUE}};',
				],
				
			]
		);
			

		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'tab_filter_active',
			[
				'label' => __( 'Active', 'elementor' ),
			]
		);
		
		$this->add_control(
			'filter_color_active',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a.active' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color_active',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a.active' => 'background-color: {{VALUE}};',
				],
				
			]
		);

			
		$this->add_control(
			'filter_active_border_color',
			[
				'label' => __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a.active' => 'border-color: {{VALUE}};',
				],
				
			]
		);
				
		$this->end_controls_tab();

		$this->end_controls_tabs();
		
		$this->add_control(
			'filter_color_arrow',
			[
				'label' 		=> __( 'Arrow color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover, {{WRAPPER}} .product-filter li a.active' => '-webkit-box-shadow: 0 -3px 0 0 {{VALUE}} inset;',
					'{{WRAPPER}} .product-filter li a.active:after' => 'border-color: {{VALUE}} transparent transparent transparent;',
				],
				'separator' => 'before',
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'filter_border',
				'label' => __( 'Border', 'briefcase-elementor-widgets' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .product-filter li a',		
				
			]
		);
		
		$this->add_control(
			'filter_border_radius',
			[
				'label' => __( 'Border Radius', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .product-filter li:first-child a' => 'border-radius: {{TOP}}{{UNIT}} 0{{UNIT}} 0{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .product-filter li:last-child a' => 'border-radius: 0{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} 0{{UNIT}};',
				],
				
			]
		);
		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .product-filter',
			]
		);
				
				
		$this->add_responsive_control(
			'filter_padding',
			[
				'label' => __( 'Text Padding', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',	
			]
		);
		
		$this->add_responsive_control(
			'filter_margin',
			[
				'label' => __( 'Filter Margin', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .filter-center' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
					
			]
		);

        $this->end_controls_section();
				
		$this->start_controls_section(
			'section_grid',
			[
				'label' 		=> __( 'Grid', 'briefcase-elementor-widgets' ),
				'tab' 			=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'grid_background_color',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bew-woo-grid .products-items .product .elementor-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
				
				
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'grid_border',
				'label' => __( 'Border', 'briefcase-elementor-widgets' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .bew-woo-grid .products-items .product .elementor-inner',		
				
			]
		);
		
		$this->add_control(
			'grid_border_color',
			[
				'label' 		=> __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bew-woo-grid .products-items .product .elementor-inner' => 'border-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'grid_border_radius',
			[
				'label' => __( 'Border Radius', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .products-items .product .elementor-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					
				],
				
			]
		);
		
		$this->add_responsive_control(
			'grid_padding',
			[
				'label' => __( 'Padding', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .products-items .product' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],					
			]
		);
		
		$this->add_responsive_control(
			'grid_margin',
			[
				'label' => __( 'Margin', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .products-items .product' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],					
			]
		);

        $this->end_controls_section();

	}

	public function get_current_page() {
		return max( 1, get_query_var( 'paged' ), get_query_var( 'page' ) );
	}

	public function get_img_sizes() {
		global $_wp_additional_image_sizes;

		$sizes = array();
	    $get_intermediate_image_sizes = get_intermediate_image_sizes();
	 
	    // Create the full array with sizes and crop info
	    foreach( $get_intermediate_image_sizes as $_size ) {
	        if ( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
	            $sizes[ $_size ]['width'] 	= get_option( $_size . '_size_w' );
	            $sizes[ $_size ]['height'] 	= get_option( $_size . '_size_h' );
	            $sizes[ $_size ]['crop'] 	= (bool) get_option( $_size . '_crop' );
	        } elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
	            $sizes[ $_size ] = array( 
	                'width' 	=> $_wp_additional_image_sizes[ $_size ]['width'],
	                'height' 	=> $_wp_additional_image_sizes[ $_size ]['height'],
	                'crop' 		=> $_wp_additional_image_sizes[ $_size ]['crop'],
	            );
	        }
	    }

	    $image_sizes = array();

		foreach ( $sizes as $size_key => $size_attributes ) {
			$image_sizes[ $size_key ] = ucwords( str_replace( '_', ' ', $size_key ) ) . sprintf( ' - %d x %d', $size_attributes['width'], $size_attributes['height'] );
		}

		$image_sizes['full'] 	= _x( 'Full', 'Image Size Control', 'briefcase-portfolio' );

	    return $image_sizes;
	}
	
	public function get_edit_buttom() {
		
	$settings = $this->get_settings();
		
	$template_id = $this->get_settings( 'template_id' );
	
	}
	
	protected function render() {
		$settings = $this->get_settings();
		
		$template_id = $this->get_settings( 'template_id' );
		
		$templates = $this->get_templates();
		foreach ( $templates as $template ) {
			if ($template['template_id'] == $template_id ){
				$template_id_verification = '1';
			}  ;
			
		}

		$args = array(
	        'post_type'         => 'product',
			'paged' 			=> $this->get_current_page(),
	        'posts_per_page'    => $settings['count'],
	        'order'             => $settings['order'],
	        'orderby'           => $settings['orderby'],
			'no_found_rows' 	=> yes,
			'tax_query' 		=> array(
				'relation' 		=> 'AND',
			),
	    );

	    // Include/Exclude categories
	    $include = $settings['include_categories'];
	    $exclude = $settings['exclude_categories'];

	    // Include category
		if ( ! empty( $include ) ) {

			// Sanitize category and convert to array
			$include = str_replace( ', ', ',', $include );
			$include = explode( ',', $include );

			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $include,
				'operator' => 'IN',
			);

		}

		// Exclude category
		if ( ! empty( $exclude ) ) {

			// Sanitize category and convert to array
			$exclude = str_replace( ', ', ',', $exclude );
			$exclude = explode( ',', $exclude );

			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $exclude,
				'operator' => 'NOT IN',
			);

		}

	    // Build the WordPress query
	    $bew_query = new \WP_Query( $args );

		// Output posts
		if ( $bew_query->have_posts() ) :

			// Vars
			$grid_style 	= $settings['grid_style'];
			$equal_heights 	= $settings['grid_equal_heights'];
			$overlay 		= $settings['overlay'];
			$title   		= $settings['title'];
			$price   		= $settings['price'];
			$button   		= $settings['purchase_button'];
			$text_button   	= $settings['text_button'];
			$price_button   = $settings['price_button'];
			$style_button   = $settings['style_button'];
			$type_button    = $settings['type_button'];
			$excerpt 		= $settings['excerpt'];
			$columns 		= $settings['columns'];
			$cat 			= $settings['cat'];
			$effect 		= $settings['effect_element'];
			$free_label 	= $settings['free_label'];
			$free_price 	= $settings['free_price'];

			$show_filter 	= $settings['filter_show'];
			$mobile_two_col = $settings['mobile_two_col'];

			// Image size
			$img_size 		= $settings['image_size'];
			$img_size 		= $img_size ? $img_size : 'medium';

			// Wrapper classes
			$wrap_classes = array( 'bew-woo-grid', 'woocommerce', 'briefcasewp-row', 'clr' );

			if ( 'masonry' == $grid_style ) {
				$wrap_classes[] = 'bew-masonry';
			}

			if ( 'yes' == $equal_heights ) {
				$wrap_classes[] = 'match-height-grid';
			}

			$wrap_classes = implode( ' ', $wrap_classes ); 
			
			// Categories List
			$args = array( 'type' => 'product', 'taxonomy' => 'product_cat' ); 
			$categories = get_categories( $args ); 
			?>
			
			

		<div class="<?php echo esc_attr( $wrap_classes ); ?>" id="<?php echo $template_id ; ?>">
			<?php
			if ( 'yes' == $show_filter ) { ?>
			<div class="filter-center">
                <ul class="product-filter">
                    <li><a class="active" href="#" data-filter="*">All Products</a></li>
                    <?php foreach ($categories as $cat) { ?>
					<li><a class="<?php echo $cat->name;?>" href="#" data-filter=".<?php echo $cat->name; ?>" ><?php echo $cat->name; ?></a></li>		
			<?php } ?>
                </ul><!--/#portfolio-filter-->
            </div>
			
			<?php } ?>	
			
			<div class="products-items">
				<?php
				// Define counter var to clear floats
				$count = '';

				// Start loop
				while ( $bew_query->have_posts() ) : $bew_query->the_post();

					// Counter
					$count++;
					$countp++;


					// If equal heights
					$details_class = '';
					if ( 'yes' == $equal_heights ) {
						$details_class = ' match-height-content';
					}

					// Meta class
					$meta_class = '';
					if ( 'false' == $comments
						|| 'false' == $cat ) {
						$meta_class = ' bew-center';
					}
					
					// Create new post object.
					$post = new \stdClass();

					// Get post data
					$get_post = get_post();

					// Post Data
					$post->ID           = $get_post->ID;
					$post->permalink    = get_the_permalink( $post->ID );
					$post->title        = $get_post->post_title;

					// Only display carousel item if there is content to show
					if ( has_post_thumbnail()
						|| 'yes' == $title
						|| 'yes' == $excerpt
					) { 
					
					// Inner classes
					if ( 'yes' == $show_filter ) {
					$inner_classes 		= array( 'products-item','bew-grid-entry', 'bew-col', 'clr');					
					} else {					
					$inner_classes 		= array( 'bew-grid-entry', 'bew-col', 'clr' );
					}					
					$inner_classes[] 	= 'c-' . $countp;
					$inner_classes[] 	= 'bew_span_1_of_' . $columns;
					$inner_classes[] 	= 'col-' . $count;
					
					if ( 'yes' == $mobile_two_col ) {
						$inner_classes[] = 'mobile-two-col';
					}
					
					if ( 'masonry' == $grid_style ) {
						$inner_classes[] = 'isotope-entry';
					}
					
					$terms = get_the_terms ( $post->ID, 'product_cat' );
					foreach ( $terms as $term ) {
						$cat_name = $term->name;
						$inner_classes[] 	= $cat_name;
					}
										
					$inner_classes = implode( ' ', $inner_classes );
					
						
					if ($template_id_verification == '1'){
					?>	
						<div id="post-<?php the_ID(); ?>" <?php post_class( $inner_classes ); ?>>
							<?php					
							if ( '1' == $countp ) {					
							echo Elementor\Plugin::instance()->frontend->get_builder_content( $template_id,$with_css = true );
							} else {
							echo Elementor\Plugin::instance()->frontend->get_builder_content( $template_id);	
							}
							?>

						</div>
					<?php
					}
						
				} ?>

					<?php
					// Reset entry counter
					if ( $count == $columns ) {
						$count = '0';
					} ?>

				<?php
				// End entry loop
				endwhile; ?>
			</div>
		</div><!-- .bew-Woo-grid-->

			<?php
			// Reset the post data to prevent conflicts with WP globals
			wp_reset_postdata();

		// If no posts are found display message
		else : ?>

			<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'briefcase-elementor-widgets' ); ?></p>

		<?php
		// End post check
		endif; ?>
		
	<?php
		
	}
	
	public function render_plain_content() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new bew_Widget_Woo_Grid() );