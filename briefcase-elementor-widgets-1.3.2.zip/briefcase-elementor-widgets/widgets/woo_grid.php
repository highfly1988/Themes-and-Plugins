<?php
namespace Briefcase;

use Elementor;
use Elementor\Plugin;
use Elementor\Post_CSS_File;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow	;
use Elementor\Group_Control_Box_Shadow;
use Briefcase\Helper;


/**
 * Woo Grid Module
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class bew_Widget_Woo_Grid extends Widget_Base {
	

	public function get_name() {
		return 'bew-woo-grid';
	}

	public function get_title() {
		return __( 'Woo Grid', 'briefcase-elementor-widgets' );
	}

	public function get_icon() {
		// Upload "eicons.ttf" font via this site: http://bluejamesbond.github.io/CharacterMap/
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'briefcasewp-elements' ];
	}

	public function get_script_depends() {
		return [ 'woo-grid', 'isotope', 'imagesloaded','woo-product-filter' ];
	}
	
	public function is_reload_preview_required() {
		return true;
	}
	
	public static function get_templates() {
		return Elementor\Plugin::instance()->templates_manager->get_source( 'local' )->get_items();
	}
	
	public static function empty_templates_message() {
		return '<div id="elementor-widget-template-empty-templates">
				<div class="elementor-widget-template-empty-templates-icon"><i class="eicon-nerd"></i></div>
				<div class="elementor-widget-template-empty-templates-title">' . __( 'You Haven’t Saved Templates Yet.', 'elementor-pro' ) . '</div>
				<div class="elementor-widget-template-empty-templates-footer">' . __( 'Want to learn more about Elementor library?', 'elementor-pro' ) . ' <a class="elementor-widget-template-empty-templates-footer-url" href="https://go.elementor.com/docs-library/" target="_blank">' . __( 'Click Here', 'elementor-pro' ) . '</a>
				</div>
				</div>';
	}
	
	protected function grid_types(){
		//Check if we are on elementor single product template 
		global $post;
		$bew_template_type = get_post_meta($post->ID, 'briefcase_template_layout', true);	
		
		if ( empty($bew_template_type) ){		
		return [
          'shop' => __('Shop Page', 'briefcase-elementor-widgets'),
		  'current' => __('Current', 'briefcase-elementor-widgets'),
		  'featured' => __('Featured Products', 'briefcase-elementor-widgets'),	
		  'related' => __('Related Products', 'briefcase-elementor-widgets'),
          'upsell'  => __('Upsell Products', 'briefcase-elementor-widgets'),		  
		  'categories' => __('Categories', 'briefcase-elementor-widgets'),
        ];		
		} else{
			
			if ( $bew_template_type == 'woo-product' ){
			return [
			  'shop' => __('Shop Page', 'briefcase-elementor-widgets'),
			  'current' => __('Current', 'briefcase-elementor-widgets'),
			  'featured' => __('Featured Products', 'briefcase-elementor-widgets'),	
			  'related' => __('Related Products', 'briefcase-elementor-widgets'),
			  'upsell'  => __('Upsell Products', 'briefcase-elementor-widgets'),		  
			  'categories' => __('Categories', 'briefcase-elementor-widgets'),
			];
			} else {
			 return [
			  'shop' => __('Shop Page', 'briefcase-elementor-widgets'),
			  'current' => __('Current', 'briefcase-elementor-widgets'),
			  'featured' => __('Featured Products', 'briefcase-elementor-widgets'),	
			  'categories' => __('Categories', 'briefcase-elementor-widgets'),
			];
			}
			
		}				
		
    }
	
	protected function _register_controls() {
		
		$this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Woo Grid', 'briefcase-elementor-widgets' ),                
            ]
        );
		
		$this->add_control(
            'grid_type',
            [
                'label' => __('Woo Grid Type','briefcase-elementor-widgets'),
                'type'  => Controls_Manager::SELECT,
                'options' => $this->grid_types(),
				'label_block'  => true,
                'default' => 'shop'
            ]
        );
		
		
		$templates = $this->get_templates();

		if ( empty( $templates ) ) {

			$this->add_control(
				'no_templates',
				[
					'label' => false,
					'type' => Controls_Manager::RAW_HTML,
					'raw' => $this->empty_templates_message(),
				]
			);
		$empty_templates = "yes";

		}

		$options = [
			'0' => '— ' . __( 'Select', 'briefcase-elementor-widgets' ) . ' —',
		];

		$types = [];

		foreach ( $templates as $template ) {
			$options[ $template['template_id'] ] = $template['title'] . ' (' . $template['type'] . ')';
			$types[ $template['template_id'] ] = $template['type'];
		}

		if ( empty( $empty_templates ) ) {
		$this->add_control(
			'template_id',
			[
				'label' => __( 'Choose Template', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'default' => '0',
				'options' => $options,
				'types' => $types,
				'label_block'  => true,				
			]
		);
		
		$button = '<div class="elementor-button elementor-button-default elementor-edit-template-bew" id="bb"><i class="fa fa-pencil"></i> Edit Template</div>';
				
		$this->add_control(
			'field_preview',
			[
				'label'   => esc_html__( 'Code', 'briefcase-elementor-widgets' ),
				'type'    => Controls_Manager::RAW_HTML,
				'separator' => 'none',
				'show_label' => false,
				'raw' => $button,
			]
		);
		
		$this->add_control(
			'template_desc',
			[
				'label' => __( 'If you don’t have a custom template yet. It will use the default theme template ', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::RAW_HTML,
				
			]
		);
		
		}
		$this->end_controls_section();
				
		
		$this->start_controls_section(
            'section_categories',
            [
                'label' => __( 'Categories', 'briefcase-elementor-widgets' ),
				'condition' => [
                    'grid_type' => 'categories',					
                ]
            ]
        );		

		$this->add_control(
			'source',
			[
				'label' => _x( 'Source', 'Posts Query Control', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' => __( 'Show All', 'elementor-pro' ),
					'by_id' => __( 'Manual Selection', 'briefcase-elementor-widgets' ),
					'by_parent' => __( 'By Parent', 'briefcase-elementor-widgets' ),
				],
				'label_block' => true,
			]
		);

		$categories = get_terms( 'product_cat' );

		$options = [];
		foreach ( $categories as $category ) {
			$options[ $category->term_id ] = $category->name;
		}

		$this->add_control(
			'categories',
			[
				'label' => __( 'Categories', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT2,
				'options' => $options,
				'default' => [],
				'label_block' => true,
				'multiple' => true,
				'condition' => [
					'source' => 'by_id',
				],
			]
		);

		$parent_options = [ '0' => __( 'Only Top Level', 'briefcase-elementor-widgets' ) ] + $options;
		$this->add_control(
			'parent',
			[
				'label' => __( 'Parent', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'default' => '0',
				'options' => $parent_options,
				'condition' => [
					'source' => 'by_parent',
				],
			]
		);

		$this->add_control(
			'hide_empty',
			[
				'label' => __( 'Hide Empty', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => '',
				'label_on' => 'Hide',
				'label_off' => 'Show',
				'return_value' => 'yes',
			]
		);

		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_woo_grid',
			[
				'label' 		=> __( 'Woo Grid Settings', 'briefcase-elementor-widgets' ),
			]
		);

		$this->add_control(
			'count',
			[
				'label' 		=> __( 'Elements Per Page', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'You can enter "-1" to display all elements.', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> '6',
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'columns',
			[
				'label' 		=> __( 'Grid Columns', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '3',
				'options' 		=> [
					'1' 		=> '1',
					'2' 		=> '2',
					'3' 		=> '3',
					'4' 		=> '4',
					'5' 		=> '5',
					'6' 		=> '6',
				],
			]
		);
		
		$this->add_control(
			'mobile_two_col',
			[
				'label' 		=> __( 'Two Columns on mobile devices', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> '',
				'label_on' 		=> __( 'Show', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Hide', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',			
			]
		);

		$this->add_control(
			'grid_style',
			[
				'label' 		=> __( 'Grid Style', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'fit-rows',
				'options' 		=> [
					'fit-rows' 	=> __( 'Fit Rows', 'briefcase-elementor-widgets' ),
					'masonry' 	=> __( 'Masonry', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'grid_equal_heights',
			[
				'label' 		=> __( 'Equal Heights', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'false',
				'options' 		=> [
					'yes' 		=> __( 'Yes', 'briefcase-elementor-widgets' ),
					'false' 	=> __( 'No', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' 		=> __( 'Order', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 			=> __( 'Default', 'briefcase-elementor-widgets' ),
					'DESC' 		=> __( 'DESC', 'briefcase-elementor-widgets' ),
					'ASC' 		=> __( 'ASC', 'briefcase-elementor-widgets' ),
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' 		=> __( 'Order By', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 				=> __( 'Default', 'briefcase-elementor-widgets' ),
					'date' 			=> __( 'Date', 'briefcase-elementor-widgets' ),
					'title' 		=> __( 'Title', 'briefcase-elementor-widgets' ),
					'name' 			=> __( 'Name', 'briefcase-elementor-widgets' ),
					'modified' 		=> __( 'Modified', 'briefcase-elementor-widgets' ),
					'author' 		=> __( 'Author', 'briefcase-elementor-widgets' ),
					'rand' 			=> __( 'Random', 'briefcase-elementor-widgets' ),
					'ID' 			=> __( 'ID', 'briefcase-elementor-widgets' ),					
					'menu_order' 	=> __( 'Menu Order', 'briefcase-elementor-widgets' ),
				],
				'condition' => [
                    'grid_type!' => 'categories',
                ]
			]
		);
		
		$this->add_control(
			'orderby_cat',
			[
				'label' => __( 'Order by', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
					'name' => __( 'Name', 'briefcase-elementor-widgets' ),
					'slug' => __( 'Slug', 'briefcase-elementor-widgets' ),
					'description' => __( 'Description', 'briefcase-elementor-widgets' ),
					'count' => __( 'Count', 'briefcase-elementor-widgets' ),
				],
				'condition' => [
                    'grid_type' => 'categories',
                ]
			]

		);
		
		$categories = get_terms( 'product_cat' );

		$options = [];
		foreach ( $categories as $category ) {
			$options[ $category->term_id ] = $category->name;
		}

		$this->add_control(
			'include_categories',
			[
				'label' 		=> __( 'Include Categories', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'You can select multiples categories', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT2,
				'options' => $options,
				'default' => [],
				'label_block' 	=> true,
				'multiple' => true,
				'condition' => [
                    'grid_type' => [ 'shop', 'featured'],
                ]
			]
		);

		$this->add_control(
			'exclude_categories',
			[
				'label' 		=> __( 'Exclude Categories', 'briefcase-elementor-widgets' ),
				'description' 	=> __( 'You can select multiples categories', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SELECT2,
				'options' => $options,
				'default' => [],
				'label_block' 	=> true,
				'multiple' => true,
				'label_block' 	=> true,
				'condition' => [
                    'grid_type' => [ 'shop', 'featured'],
                ]
			]
		);

		$this->end_controls_section();
		
		if ( empty( $empty_templates ) ) {
		
		$this->start_controls_section(
            'section_filter',
            [
                'label' => __( 'Filter', 'briefcase-elementor-widgets' ),
				'condition' => [
                    'grid_type' => [ 'shop', 'featured'],
                ]
            ]
        );
		
		$this->add_control(
			'filter_show',
			[
				'label' 		=> __( 'Show Filter', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'default' 		=> 'yes',
				'label_on' 		=> __( 'Show', 'briefcase-elementor-widgets' ),
				'label_off' 	=> __( 'Hide', 'briefcase-elementor-widgets' ),
				'return_value' 	=> 'yes',			
			]
		);
		
		$this->add_control(
			'hide_empty_filter',
			[
				'label' => __( 'Hide Empty', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => '',
				'label_on' => 'Hide',
				'label_off' => 'Show',
				'return_value' => '1',
			]
		);
		
		$this->add_control(
			'parent_filter',
			[
				'label' => __( 'Only Top Level', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => '',
				'label_on' => 'yes',
				'label_off' => 'no',
				'return_value' => '0',
				'description' 	=> __( 'Show the top level categories on the filter', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_responsive_control(
			'filter_align',
			[
				'label' => __( 'Alignment', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'briefcase-elementor-widgets' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .filter-center' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();		
		
		$this->start_controls_section(
			'section_filter_style',
			[
				'label' 		=> __( 'Filter', 'briefcase-elementor-widgets' ),
				'tab' 			=> Controls_Manager::TAB_STYLE,
				'condition' => [
                    'filter_show' => 'yes',
					'grid_type' => 'shop',
                ]
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'filter_typo',
				'selector' 		=> '{{WRAPPER}} .filter-center',				
			]
		);
		
		$this->start_controls_tabs( 'tabs_filter_style' );
		
		$this->start_controls_tab(
			'tab_filter_normal',
			[
				'label' => __( 'Normal', 'briefcase-elementor-widgets' ),
			]
		);
		
		$this->add_control(
			'filter_color',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a' => 'background: {{VALUE}};',
				],
				
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_filter_hover',
			[
				'label' => __( 'Hover', 'elementor' ),
			]
		);
		
		$this->add_control(
			'filter_color_hover',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color_hover',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover' => 'background-color: {{VALUE}};',
				],
				
			]
		);

			
		$this->add_control(
			'filter_hover_border_color',
			[
				'label' => __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a:hover' => 'border-color: {{VALUE}};',
				],
				
			]
		);
			

		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'tab_filter_active',
			[
				'label' => __( 'Active', 'elementor' ),
			]
		);
		
		$this->add_control(
			'filter_color_active',
			[
				'label' 		=> __( 'Text Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a.active' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'filter_background_color_active',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a.active' => 'background-color: {{VALUE}};',
				],
				
			]
		);

			
		$this->add_control(
			'filter_active_border_color',
			[
				'label' => __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a.active' => 'border-color: {{VALUE}};',
				],
				
			]
		);
				
		$this->end_controls_tab();

		$this->end_controls_tabs();
		
		$this->add_control(
			'filter_color_arrow',
			[
				'label' 		=> __( 'Arrow color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .product-filter li a:hover, {{WRAPPER}} .product-filter li a.active' => '-webkit-box-shadow: 0 -3px 0 0 {{VALUE}} inset;',
					'{{WRAPPER}} .product-filter li a.active:after' => 'border-color: {{VALUE}} transparent transparent transparent;',
				],
				'separator' => 'before',
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'filter_border',
				'label' => __( 'Border', 'briefcase-elementor-widgets' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .product-filter li a',		
				
			]
		);
		
		$this->add_control(
			'filter_border_radius',
			[
				'label' => __( 'Border Radius', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .product-filter li:first-child a' => 'border-radius: {{TOP}}{{UNIT}} 0{{UNIT}} 0{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .product-filter li:last-child a' => 'border-radius: 0{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} 0{{UNIT}};',
				],
				
			]
		);
		
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .product-filter',
			]
		);
				
				
		$this->add_responsive_control(
			'filter_padding',
			[
				'label' => __( 'Text Padding', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .product-filter li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',	
			]
		);
		
		$this->add_responsive_control(
			'filter_margin',
			[
				'label' => __( 'Filter Margin', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .filter-center' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
					
			]
		);

        $this->end_controls_section();
				
		$this->start_controls_section(
			'section_grid',
			[
				'label' 		=> __( 'Grid', 'briefcase-elementor-widgets' ),
				'tab' 			=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'grid_background_color',
			[
				'label' 		=> __( 'Background Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bew-woo-grid .product .elementor-inner, {{WRAPPER}} .bew-grid-categories .product-category .elementor-inner' => 'background-color: {{VALUE}};',
				],
			]
		);
				
				
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'grid_border',
				'label' => __( 'Border', 'briefcase-elementor-widgets' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .bew-woo-grid .product .elementor-inner, {{WRAPPER}} .bew-grid-categories .product-category .elementor-inner',		
				
			]
		);
		
		$this->add_control(
			'grid_border_color',
			[
				'label' 		=> __( 'Border Color', 'briefcase-elementor-widgets' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .bew-woo-grid .product .elementor-inner, {{WRAPPER}} .bew-grid-categories .product-category .elementor-inner' => 'border-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'grid_border_radius',
			[
				'label' => __( 'Border Radius', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .product .elementor-inner, {{WRAPPER}} .bew-grid-categories .product-category .elementor-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					
				],
				
			]
		);
		
		$this->add_responsive_control(
			'grid_padding',
			[
				'label' => __( 'Padding', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .product, {{WRAPPER}} .bew-grid-categories .product-category' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],					
			]
		);
		
		$this->add_responsive_control(
			'grid_margin',
			[
				'label' => __( 'Margin', 'briefcase-elementor-widgets' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bew-woo-grid .product, {{WRAPPER}} .bew-grid-categories .product-category' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],					
			]
		);

        $this->end_controls_section();
		
		}

	}

	public function get_current_page() {
		return max( 1, get_query_var( 'paged' ), get_query_var( 'page' ) );
	}

	public function get_img_sizes() {
		global $_wp_additional_image_sizes;

		$sizes = array();
	    $get_intermediate_image_sizes = get_intermediate_image_sizes();
	 
	    // Create the full array with sizes and crop info
	    foreach( $get_intermediate_image_sizes as $_size ) {
	        if ( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
	            $sizes[ $_size ]['width'] 	= get_option( $_size . '_size_w' );
	            $sizes[ $_size ]['height'] 	= get_option( $_size . '_size_h' );
	            $sizes[ $_size ]['crop'] 	= (bool) get_option( $_size . '_crop' );
	        } elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
	            $sizes[ $_size ] = array( 
	                'width' 	=> $_wp_additional_image_sizes[ $_size ]['width'],
	                'height' 	=> $_wp_additional_image_sizes[ $_size ]['height'],
	                'crop' 		=> $_wp_additional_image_sizes[ $_size ]['crop'],
	            );
	        }
	    }

	    $image_sizes = array();

		foreach ( $sizes as $size_key => $size_attributes ) {
			$image_sizes[ $size_key ] = ucwords( str_replace( '_', ' ', $size_key ) ) . sprintf( ' - %d x %d', $size_attributes['width'], $size_attributes['height'] );
		}

		$image_sizes['full'] 	= _x( 'Full', 'Image Size Control', 'briefcase-portfolio' );

	    return $image_sizes;
	}
	
	public function get_edit_buttom() {
		
	$settings = $this->get_settings();
		
	$template_id = $this->get_settings( 'template_id' );
	
	}
		
	private function get_shortcode() {
		$settings = $this->get_settings();
					
		$template_id = $this->get_settings( 'template_id' );
		
		$attributes = [
			'number' => $settings['count'],
			'columns' => $settings['columns'],
			'hide_empty' => ( 'yes' === $settings['hide_empty'] ) ? 1 : 0,
			'orderby' => $settings['orderby_cat'],
			'order' => $settings['order'],
		];

		if ( 'by_id' === $settings['source'] ) {
			$attributes['ids'] = implode( ',', $settings['categories'] );
		} elseif ( 'by_parent' === $settings['source'] ) {
			$attributes['parent'] = $settings['parent'];
		}

		$this->add_render_attribute( 'shortcode', $attributes );
			
		$shortcode = sprintf( '[product_categories %s]', $this->get_render_attribute_string( 'shortcode' ) );
		
		return $shortcode;
	}
			
	private function bew_product_categories() {
		
		$settings = $this->get_settings();
		
		$template_id = $this->get_settings( 'template_id' );	
		
		
		if ( '-1' === $settings['count'] ) {
			$number = '';
		} else {
			$number = $settings['count'];
		}
		
		// Get terms and workaround WP bug with parents/pad counts.
		$args = array(
			'orderby'    => $settings['orderby'],
			'order'      => $settings['order'],
			'number'     => $number,
			'hide_empty' => ( 'yes' === $settings['hide_empty'] ) ? 1 : 0,			
			'pad_counts' => true,			
		);
		
		if ( 'by_id' === $settings['source'] ) {
			$args['include'] = implode( ',', $settings['categories'] );
		} elseif ( 'by_parent' === $settings['source'] ) {
			$args['parent'] = $settings['parent'];
		}

		$product_categories = get_terms( 'product_cat', $args );
		
		$columns = absint( $settings['columns'] );

		if ( $product_categories ) {
		echo '<div class="bew-woo-grid woocommerce briefcasewp-row clr">';	
		
			foreach ( $product_categories as $category ) {				
			
			global $bewcategory;		
			$bewcategory = $category;

			// Counter
			$count++;
			$countp++;		
		
			// Inner classes					
				$inner_classes = array( 'bew-product-categories bew-grid-entry bew-col clr' );	
				
				$inner_classes[] 	= 'c-' . $countp;
				$inner_classes[] 	= 'bew_span_1_of_' . $columns;
				$inner_classes[] 	= 'col-' . $count;
							
				if ( 'yes' == $mobile_two_col ) {
					$inner_classes[] = 'mobile-two-col';
				}
				
				if ( 'yes' == $mobile_two_col && ($countp & 1) ) {
					$inner_classes[] = 'mobile-clear';
				}						
																		
				$inner_classes = implode( ' ', $inner_classes );
				
				// Get the current template	
				echo '<div class=" bew-product-category '. esc_attr( $inner_classes ) . '">';	
				
					$withcss =false;
					if(Elementor\Plugin::instance()->editor->is_edit_mode()){
					$withcss = true;
					}
												
					echo Elementor\Plugin::instance()->frontend->get_builder_content( $template_id,$withcss );
					
				echo '</div>';			
			
				// Reset entry counter
					if ( $count == $columns ) {
					$count = '0';
					} 										
			}
			
		echo '</div>';		
		}				
	}
	
	
	function prefix_post_class( $classes ) {
    if ( 'product' == get_post_type() ) {
        $classes = array_diff( $classes, array( 'first', 'last' ) );
    }
    return $classes;
	}
		
		
	protected function get_products_query_args(){
        $helper = new Helper();
		$settings = $this->get_settings();
		
		$grid_type = $this->get_settings( 'grid_type' );
		$count_page = $settings['count'];
						
        switch($grid_type){
			
			case 'shop':
						// Array for shop page layout
						$args = array(
							'post_type'         => 'product',
							'paged' 			=> $this->get_current_page(),
							'posts_per_page'    => $settings['count'],
							'order'             => $settings['order'],
							'orderby'           => $settings['orderby'],
							'no_found_rows' 	=> true,
							'tax_query' 		=> array(
								'relation' 		=> 'AND',
							),
						);

						// Include/Exclude categories
						$include = $settings['include_categories'];
						$exclude = $settings['exclude_categories'];
						
						// Include category
						if ( ! empty( $include ) ) {
					
							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $include,
								'include_children' => false,
								'operator' => 'IN',
							);
						}

						// Exclude category
						if ( ! empty( $exclude ) ) {

							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $exclude,								
								'operator' => 'NOT IN',
							);
							
						}
					break;
					
			case 'current':
						// Array for shop page layout
						$args = array(
							'post_type'         => 'product',
							'paged' 			=> $this->get_current_page(),
							'posts_per_page'    => $settings['count'],
							'order'             => $settings['order'],
							'orderby'           => $settings['orderby'],
							'no_found_rows' 	=> true,
							'tax_query' 		=> array(
								'relation' 		=> 'AND',
							),
						);
						
						if ( is_product_category() ){
							global $wp_query;
							$cat = $wp_query->get_queried_object();
							$cat_id = $cat->term_id;
							$include = $cat_id;
							$include_children = true;
						} else {						
						// Include/Exclude categories
						$include = $settings['include_categories'];
						$include_children = false;
						}
						$exclude = $settings['exclude_categories'];
						
						// Include category
						if ( ! empty( $include ) ) {
					
							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $include,
								'include_children' => $include_children,
								'operator' => 'IN',
							);
						}

						// Exclude category
						if ( ! empty( $exclude ) ) {

							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $exclude,								
								'operator' => 'NOT IN',
							);
							
						}
					break;		
					
			case 'featured':
						// Array for featured products
						$args = array(
							'post_type'         => 'product',
							'paged' 			=> $this->get_current_page(),
							'posts_per_page'    => $settings['count'],							
							'order'             => $settings['order'],
							'orderby'           => $settings['orderby'],
							'no_found_rows' 	=> true,
							'tax_query' 		=> array(
								'relation' 		=> 'AND',
							),
						);

						// Include/Exclude categories
						$include = $settings['include_categories'];
						$exclude = $settings['exclude_categories'];
						
						// Include featured
											
							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_visibility',
								'field'    => 'name',
								'terms'    => 'featured',								
							);
						
						
						// Include category
						if ( ! empty( $include ) ) {
					
							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $include,
								'include_children' => false,
								'operator' => 'IN',
							);
						}

						// Exclude category
						if ( ! empty( $exclude ) ) {

							// Add to query arg
							$args['tax_query'][] = array(
								'taxonomy' => 'product_cat',
								'field'    => 'id',
								'terms'    => $exclude,								
								'operator' => 'NOT IN',
							);
							
						}
					break;		
			
            case 'related' : $product = $helper->product_data();
								
                             if(is_null($product) || $product->post_type != 'product'){
                                 return [];
                             }
                             $related_products = wc_get_related_products($product->get_id(), $count_page, $product->get_upsell_ids());
                             $args = [
                                 'post_type' => 'product',
								 'posts_per_page' => $count_page,
                                 'stock' => 1,
                                 'orderby' =>'date',
                                 'order' => 'DESC',
                                 'post__in' => $related_products
                             ];
                             break;

            case 'upsell'   : $product = $helper->product_data();
                              if(is_null($product) || $product->post_type != 'product'){
                                  return [];
                              }
                              $upsell_products = $product->get_upsell_ids();
                                $args = [
                                    'post_type' => 'product',
                                    'posts_per_page' => $count_page,
                                    'stock' => 1,
                                    'orderby' =>'date',
                                    'order' => 'DESC',
                                    'post__in' => $upsell_products
                                ];
                                break;			
        }
        return $args;
    }
	
	protected function layout_filter(){
		
		$settings = $this->get_settings();
		
		// Include/Exclude categories on filter
						$includef = $settings['include_categories'];
						$excludef = $settings['exclude_categories'];
		// Categories List
					$args = array( 
						'hide_empty'   => $settings['hide_empty_filter'], 
						'order' 	   => $settings['order'],
						'pad_counts'   => true,
						'exclude'      => $excludef,
						'exclude_tree' => $excludef, 
						'include'      => $includef,
						'parent'       => $settings['parent_filter'],
					); 			
					
					$categories = get_terms( 'product_cat', $args );
		
		?>	
		<div class="filter-center">
			<ul class="product-filter">
				<li><a class="active" href="#" data-filter="*">All Products</a></li>
			<?php foreach ($categories as $cat) { ?>
				<li><a class="<?php echo $cat->name;?>" href="#" data-filter=".<?php echo $cat->name; ?>" ><?php echo $cat->name; ?></a></li>		
			<?php } ?>
			</ul><!--/#product-filter-->
		</div>
		<?php
		// Class to initiate isotope filter	
		?>
		<div class="products-items">
		<?php
	
	}
	protected function apply_template($bew_query, $template_id_verification){
		
		$settings = $this->get_settings();
		
		// Vars
		
		$template_id = $this->get_settings( 'template_id' );	
		
		$equal_heights 	= $settings['grid_equal_heights'];
		$title   		= $settings['title'];
		$excerpt 		= $settings['excerpt'];
		$show_filter 	= $settings['filter_show'];
		$mobile_two_col = $settings['mobile_two_col'];
		$grid_style 	= $settings['grid_style'];
		$columns 		= $settings['columns'];
		$cat 			= $settings['cat'];
		
		
		// Default template	for related products		
			if($template_id  == "0"){				
						
				$frontend = Frontend::instance();
				$check_template = $frontend->check_wc_shop_template();	
						
				$template_id = $check_template;						
						
			}
		
		// Define counter var to clear floats
			$count = '';

		// Start loop
				while ( $bew_query->have_posts() ) : $bew_query->the_post();

					// Counter
					$count++;
					$countp++;


					// If equal heights
					$details_class = '';
					if ( 'yes' == $equal_heights ) {
						$details_class = ' match-height-content';
					}

					// Meta class
					$meta_class = '';
					if ( 'false' == $comments
						|| 'false' == $cat ) {
						$meta_class = ' bew-center';
					}
							
					// Create new post object.
						$post = new \stdClass();

					// Get post data
						$get_post = get_post();

					// Post Data
						$post->ID           = $get_post->ID;
						$post->permalink    = get_the_permalink( $post->ID );
						$post->title        = $get_post->post_title;

					// Only display grid item if there is content to show
					if ( has_post_thumbnail()
						|| 'yes' == $title
						|| 'yes' == $excerpt ) { 
							
					// Inner classes												
					
						if ( 'yes' == $show_filter ) {
							$inner_classes 		= array( 'products-item','bew-grid-entry', 'bew-col', 'clr');					
						} else {					
							$inner_classes 		= array( 'bew-grid-entry', 'bew-col', 'clr' );
						}
						
							$inner_classes[] 	= 'c-' . $countp;
							$inner_classes[] 	= 'bew_span_1_of_' . $columns;
							$inner_classes[] 	= 'col-' . $count;
							
						if ( 'yes' == $mobile_two_col ) {
							$inner_classes[] = 'mobile-two-col';
						}
						
						if ( 'yes' == $mobile_two_col && ($countp & 1) ) {
							$inner_classes[] = 'mobile-clear';
						}
							
						if ( 'masonry' == $grid_style ) {
							$inner_classes[] = 'isotope-entry';
						}
							
						$terms = get_the_terms ( $post->ID, 'product_cat' );
						
						foreach ( $terms as $term ) {
							$cat_name = $term->name;
							$inner_classes[] 	= $cat_name;
						}
												
						$inner_classes = implode( ' ', $inner_classes );
							
					// unset firts/last classes
						add_filter( 'post_class', array( $this, 'prefix_post_class' ), 21 );							
						
						
							// Get the current template	
							$withcss =false;
							if(Elementor\Plugin::instance()->editor->is_edit_mode()){
							$withcss = true;
							}
								
							?>	
							<div id="post-<?php the_ID(); ?>" <?php post_class( $inner_classes ); ?>>
							<?php		
												
								echo Elementor\Plugin::instance()->frontend->get_builder_content( $template_id,$withcss );
									
							?>
							</div>
							<?php
					} ?>

					<?php
				// Reset entry counter
					if ( $count == $columns ) {
							$count = '0';
					} ?>

					<?php
				// End entry loop
				endwhile; 	
	}
	
	
	protected function render() {
		$settings = $this->get_settings();
		
		$template_id = $this->get_settings( 'template_id' );
		$grid_type = $this->get_settings( 'grid_type' );
		
		 switch($grid_type){
			
			case 'shop':
			case 'current':
			case 'featured':
			case 'related':
			case 'upsell':
			
				$templates = $this->get_templates();
				$template_id_verification = '0';
				foreach ( $templates as $template ) {
					if ($template['template_id'] == $template_id ){
						$template_id_verification = '1';
					}  ;			
				}
				// Get args for query
				$args = $this->get_products_query_args();		
				
				// Build the WordPress query
				$bew_query = new \WP_Query( $args );

				// Output posts
				if ( $bew_query->have_posts() ) :

					// Vars					
					$show_filter 	= $settings['filter_show'];					

					// Wrapper classes
					$wrap_classes = array( 'bew-woo-grid', 'woocommerce', 'briefcasewp-row', 'clr' );

					if ( 'masonry' == $grid_style ) {
						$wrap_classes[] = 'bew-masonry';
					}
					
					if ( 'related' == $grid_type ) {
						$wrap_classes[] = 'bew-related-products';
					}

					if ( 'yes' == $equal_heights ) {
						$wrap_classes[] = 'match-height-grid';
					}

					$wrap_classes = implode( ' ', $wrap_classes ); 
					
					// Layout Shop Page
					?>
					
					<div class="<?php echo esc_attr( $wrap_classes ); ?>" id="<?php echo $template_id ; ?>">
						<?php
					
					
						// Choose the layout type
						
						if ('shop' == $grid_type) {
							// Filter option
							if ( 'yes' == $show_filter) {
								$this->layout_filter();						 
							} else {
							?>
								<div class="bew-products clr">
							<?php
							}						
							// Apply template module
								$this->apply_template($bew_query,$template_id_verification);
							?>	
							</div>						
							<?php	
						} elseif ('current' == $grid_type) {
												
							?>
								<div class="bew-products bew-current-products clr">
							<?php
													
							// Apply template module
								$this->apply_template($bew_query,$template_id_verification);
							?>	
							</div>						
							<?php	
						
						} elseif ('featured' == $grid_type) {
												
							?>
								<div class="bew-products bew-featured-products clr">
							<?php
													
							// Apply template module
								$this->apply_template($bew_query,$template_id_verification);
							?>	
							</div>						
							<?php	
						
						} elseif ('related' == $grid_type) {
							
							if ($template_id_verification != '1'){
							?>	
								<div class="bew-related-products-default clr">
								<?php
									// Check current shop template
									$frontend = Frontend::instance();
									$check_template = $frontend->check_wc_shop_template();	
															
								if($check_template  == ""){									
								?>								
								<span><?php _e( 'It seems you need to select a template for your related products.', 'briefcase-elementor-widgets' ); ?></span>								
								<?php
								
								} else {							
								
								// Apply template module
								$this->apply_template($bew_query,$template_id_verification);
								
								}
								?>
								</div>						
							<?php
							} else {
								?>
								<div class="bew-related-products clr">
								<?php
								// Apply template module
								$this->apply_template($bew_query,$template_id_verification);
								?>
								</div>						
							<?php
							}
						} else {
							?>
							<div class="bew-products clr">
							<?php
								// Apply template module
								$this->apply_template($bew_query, $template_id_verification);
							?>
							</div>						
							<?php
						}			 
						?>
					
					</div><!-- .bew-Woo-grid-->
					<?php
				
				// Reset the post data to prevent conflicts with WP globals
				wp_reset_postdata();

				// If no posts are found display message
				else : ?>

					<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'briefcase-elementor-widgets' ); ?></p>

				<?php
				// End post check
				endif;
		break;
		
		case 'categories':
			
			// Wrapper category classes
				$wrap_classes_categories = array( 'bew-grid-categories' );
				$wrap_classes_categories = implode( ' ', $wrap_classes_categories );
				
				echo '<div class="'. esc_attr( $wrap_classes_categories ) . '">';
			
					if ( empty($template_id)) {
						
						echo do_shortcode( $this->get_shortcode() );
						
					} else {
						
						// With custom template
						echo $this->bew_product_categories();			
					}
			
				echo '</div>';
			
		break;
		
		}
		?>
			
	<?php
		
	}
	
	public function render_plain_content() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new bew_Widget_Woo_Grid() );